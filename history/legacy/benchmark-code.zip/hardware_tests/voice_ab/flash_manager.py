"""Application-only switching and original-clip restore for the paired study.

Never writes bootloader, partition table, NVS, context or eFuses. Every operation
has a new log. The complete original Flash backup is mandatory and hash locked.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
RUN=ROOT/'artifacts/voice-ab-1000-v1'
LAYOUT={'boot':(0,0x9000),'nvs':(0x9000,0xf000),'phy':(0xf000,0x10000),
        'app':(0x10000,0x190000),'context':(0x190000,0x390000),'clip':(0x390000,0x400000)}

def sha(data): return hashlib.sha256(data).hexdigest()
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')

def tool(label,*args):
    path=RUN/(label+'.log')
    if path.exists(): raise FileExistsError(path)
    command=[sys.executable,'-m','esptool','--chip','esp32c3','--port','COM5','--baud','921600',*map(str,args)]
    with path.open('xb') as log:
        code=subprocess.call(command,stdout=log,stderr=subprocess.STDOUT,cwd=ROOT)
    save(RUN/(label+'.json'),dict(command=command,exit_code=code,at=time.time()))
    if code: raise RuntimeError(f'{label}: esptool exited {code}; log preserved')

def main():
    p=argparse.ArgumentParser();p.add_argument('op',choices=['freeze','switch','restore','verify'])
    p.add_argument('--image',type=Path);p.add_argument('--sha256');p.add_argument('--label',required=True)
    a=p.parse_args(); before=(RUN/'flash-before.bin').read_bytes()
    assert len(before)==0x400000
    frozen=RUN/'backup-sha.json'
    if a.op=='freeze':
        if frozen.exists(): raise FileExistsError(frozen)
        save(frozen,dict(full=sha(before),regions={k:sha(before[s:e]) for k,(s,e) in LAYOUT.items()}))
        for name in ('app','clip'):
            s,e=LAYOUT[name];(RUN/f'original-{name}.bin').write_bytes(before[s:e])
        print(frozen.read_text());return
    assert sha(before)==json.loads(frozen.read_text())['full']
    if a.op=='switch':
        data=a.image.read_bytes()
        assert a.sha256 and sha(data)==a.sha256 and len(data)<=0x180000
        tool(a.label,'write-flash','0x10000',a.image)
        tool(a.label+'-verify','verify-flash','0x10000',a.image)
    elif a.op=='restore':
        for name in ('app','clip'):
            s,e=LAYOUT[name];assert (RUN/f'original-{name}.bin').read_bytes()==before[s:e]
        tool(a.label,'write-flash','0x10000',RUN/'original-app.bin','0x390000',RUN/'original-clip.bin')
        tool(a.label+'-verify','verify-flash','0x10000',RUN/'original-app.bin','0x390000',RUN/'original-clip.bin')
    else:
        path=RUN/(a.label+'.bin');tool(a.label,'read-flash',0,'0x400000',path)
        actual=path.read_bytes();same={k:actual[s:e]==before[s:e] for k,(s,e) in LAYOUT.items()}
        save(RUN/(a.label+'-regions.json'),dict(full=sha(actual),same=same))
        # NVS reserves unique sequence ranges on reboot; compare separately.
        assert all(equal for name,equal in same.items() if name!='nvs'),same

if __name__=='__main__': main()
