"""Audit schedule, capture provenance and lossless archives; never retest hardware."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / 'artifacts/voice-ab-1000-v1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--blocks', type=int, default=20)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert 1 <= args.blocks <= 20 and not args.output.exists()
    manifest = RUN / 'frozen-v3.json'
    plan = read(manifest)
    fingerprint = sha(manifest)
    for path, expected in plan['source_sha256'].items():
        assert sha(ROOT / path) == expected, path
    for item in plan['versions'].values():
        assert sha(ROOT / item['path']) == item['sha256']
    seen = set()
    counts = Counter()
    annotations = Counter()
    endpoint_ids = set()
    capture_buffers = Counter()
    results = []
    context = read(RUN / 'formal-v1/configure-00.json')['context']
    interrupted = {}
    interruption_hashes = {}
    for interruption_path in sorted(RUN.glob('interruption-*.json')):
        interruption = read(interruption_path)
        interruption_hashes[interruption_path.name] = sha(interruption_path)
        original = Path(interruption['original'])
        block_number = int(original.parent.name.removeprefix('block-'))
        preserved = (RUN / interruption['preserved']).resolve()
        assert preserved.is_relative_to(RUN.resolve())
        for record in interruption['records']:
            path = preserved / record['path']
            assert path.stat().st_size == record['bytes'] and sha(path) == record['sha256']
        failed = read(preserved / 'result.json')
        capture = read(preserved / 'external.wasapi.json')
        assert not failed['complete'] and 'infrastructure_error' in failed
        assert not capture['complete'] and capture['discontinuities_after_first'] > 0
        assert failed['case'] == plan['pairs'][failed['pair']]
        assert failed['manifest_sha256'] == fingerprint and block_number not in interrupted
        interrupted[block_number] = failed
    rig_path = RUN/'rig-v1.json'
    if rig_path.exists():
        rig = read(rig_path)
        assert rig['base_manifest_sha256'] == fingerprint
        for name, expected in rig['source_sha256'].items():
            assert sha(ROOT/name) == expected, name
    for number in range(args.blocks):
        name = f'block-{number:02d}'
        folder = RUN / 'formal' / name
        block = plan['blocks'][number]
        version = block['version']
        events = [json.loads(line) for line in (folder / 'events.jsonl').read_text().splitlines()]
        assert events[0]['kind'] == 'block_start' and events[-1]['kind'] == 'block_closed'
        for event in (e for e in events if e['kind'] == 'block_start'):
            assert event['block'] == block and event['manifest_sha256'] == fingerprint
        assert [e['pair'] for e in events if e['kind'] == 'trial_end'] == block['pairs']
        starts = [e['pair'] for e in events if e['kind'] == 'trial_start']
        pauses = [e for e in events if e['kind'] == 'paused']
        expected_starts = list(block['pairs'])
        if number in interrupted:
            failed = interrupted[number]
            assert len(pauses) == 1 and pauses[0]['pair'] == failed['pair']
            assert pauses[0]['error'] == failed['infrastructure_error']
            # One invalid acoustic attempt precedes its resumed formal case.
            expected_starts.insert(expected_starts.index(failed['pair']), failed['pair'])
        else:
            assert not pauses
        assert starts == expected_starts
        assert not any(e['kind'] == 'cleanup_error' for e in events)
        configs = list(RUN.glob(f'formal-v1*/configure-{number:02d}.json'))
        assert configs
        for config_path in configs:
            config = read(config_path)
            assert config['status']['wifi_power_save'] == 'none' and config['status']['wifi']
            assert config['wake']['threshold'] == 550 and config['wake']['input_gain'] == 1
            assert config['audio']['mic_adc_rate'] == 32000 and config['audio']['volume'] == 80
            assert config['context'] == context, 'Test must not write conversation history'
        index = read(RUN / 'recording-archives' / (name + '.json'))
        archive = RUN / 'recording-archives' / (name + '.zip')
        assert sha(archive) == index['zip_sha256']
        cache = read(RUN / 'acoustic-cache' / (name + '.json'))
        assert cache['manifest_sha256'] == fingerprint
        assert cache['archive_index_sha256'] == sha(RUN / 'recording-archives' / (name + '.json'))
        with zipfile.ZipFile(archive) as z:
            assert set(z.namelist()) == set(index['files'])
            for path, item in index['files'].items():
                data = z.read(path)
                assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
        for pair in block['pairs']:
            key = (version, pair)
            assert key not in seen
            seen.add(key)
            case_folder = folder / f'{version}-{pair:03d}'
            result_path = case_folder / 'result.json'
            row = read(result_path)
            assert row['pair'] == pair and row['version'] == version
            assert row['case'] == plan['pairs'][pair] and row['manifest_sha256'] == fingerprint
            assert row['complete'] and 'infrastructure_error' not in row
            assert all(code == 0 for code in row['processes'])
            assert cache['results'][case_folder.name]['result_sha256'] == sha(result_path)
            for metadata, wav in (('external.wasapi.json', 'external.wav'),
                                  ('computer-output.loopback.json', 'computer-output.wav')):
                capture = read(case_folder / metadata)
                assert capture['complete'] and capture['rate'] == 48000
                assert capture['sha256'] == index['files'][f'{case_folder.name}/{wav}']['sha256']
                assert capture['buffer_ms'] in (500,8000)
                if capture['buffer_ms']==8000:
                    stamp = read((case_folder/wav).with_suffix('.rig.json'))
                    assert stamp['rig_sha256']==sha(rig_path)
                    assert stamp['actual_buffer_ms']==8000 and capture['buffer_frames']>=384000
                    assert stamp['injection']['requested_s']==0 and not stamp['injection']['injected']
                    assert stamp['pcm_sha256']==capture['sha256']
                endpoint_ids.add((metadata, capture['device_id']))
                for field in ('discontinuities_after_first', 'timestamp_errors', 'position_gaps',
                              'nonmonotonic_timestamps', 'synthesized_frames'):
                    if capture.get(field, 0):
                        annotations[f'{version}:{metadata}:{field}'] += 1
                if metadata == 'external.wasapi.json':
                    assert capture['mode'] == 'raw'
                    assert all(e['state'] == 0 for e in capture['effects']['items'])
                    capture_buffers[f'{version}:{capture["buffer_ms"]}'] += 1
                counts[metadata] += 1
            for field in ('coverage_error', 'analysis_error'):
                if field in row:
                    annotations[f'{version}:{field}'] += 1
            counts[version] += 1
            results.append(dict(version=version, pair=pair, result_sha256=sha(result_path),
                                evidence=str(result_path.relative_to(ROOT))))
    assert len(seen) == args.blocks * 50
    assert len(endpoint_ids) == 2, 'All trials must use the same two audio endpoints'
    paired = len({pair for version, pair in seen if version == 'A'} &
                 {pair for version, pair in seen if version == 'B'})
    if args.blocks == 20:
        assert counts['A'] == counts['B'] == paired == 500
    output = dict(complete=True, scope='Evidence audit, not a new hardware trial',
                  blocks=args.blocks, trials=len(seen), paired=paired,
                  excluded_infrastructure_attempts=sum(n < args.blocks for n in interrupted),
                  total_attempts=len(seen)+sum(n < args.blocks for n in interrupted),
                  interruption_record_sha256=interruption_hashes,
                  manifest_sha256=fingerprint, counts=dict(counts),
                  capture_buffers_ms=dict(capture_buffers),
                  capture_rig_sha256=sha(rig_path) if rig_path.exists() else None,
                  annotations=dict(annotations), endpoint_ids=sorted(endpoint_ids),
                  context_unchanged=True, archive_bytes_verified=True, results=results)
    with args.output.open('x', encoding='utf8') as f:
        json.dump(output, f, indent=2)
        f.write('\n')
    print(json.dumps({k: v for k, v in output.items() if k != 'results'}))


if __name__ == '__main__':
    main()
