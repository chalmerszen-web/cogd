"""Explicit host-buffer amendment around the frozen native-packet recorders.

Only the capture buffer duration changes. Native format, packet validation,
sample conversion, gain, effects and audio-engine timing are the original code.
Optional reader-stall injection is for the bounded instrument probe only.
"""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / 'artifacts/voice-ab-1000-v1'
sys.path.insert(0, str(ROOT/'tools'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_rig():
    path = RUN/'rig-v1.json'
    rig = json.loads(path.read_text(encoding='utf8'))
    assert sha(RUN/'frozen-v3.json') == rig['base_manifest_sha256']
    for name, expected in rig['source_sha256'].items():
        assert sha(ROOT/name) == expected, name
    return rig


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--backend', choices=('raw','loopback'), required=True)
    p.add_argument('--actual-buffer-ms', type=int, choices=(500,8000), required=True)
    p.add_argument('--inject-stall-s', type=float, default=0)
    a, remaining = p.parse_known_args()
    assert 0 <= a.inject_stall_s <= 4.5
    check_rig()
    core = importlib.import_module('record_wasapi' if a.backend=='raw' else 'record_loopback')
    parse = argparse.ArgumentParser.parse_args
    parsed = []

    def capture_args(parser, *args, **kwargs):
        result = parse(parser, *args, **kwargs)
        result.buffer_ms = a.actual_buffer_ms
        parsed.append(result)
        return result

    argparse.ArgumentParser.parse_args = capture_args
    from soundcard import mediafoundation as mf
    available = mf._Recorder._capture_available_frames
    injection = dict(requested_s=a.inject_stall_s, injected=False)
    first_read = None

    def read_available(recorder):
        nonlocal first_read
        now = time.monotonic()
        if first_read is None:
            first_read = now
        if a.inject_stall_s and not injection['injected'] and now-first_read >= 1:
            injection.update(injected=True, started=now)
            time.sleep(a.inject_stall_s)
            injection['elapsed_s'] = time.monotonic()-now
        return available(recorder)

    mf._Recorder._capture_available_frames = read_available
    sys.argv = [str(Path(core.__file__)), *remaining]
    try:
        core.main()
    finally:
        if parsed:
            args = parsed[-1]
            output = args.output if a.backend=='raw' else args.path
            report = dict(backend=a.backend, actual_buffer_ms=a.actual_buffer_ms,
                rig_sha256=sha(RUN/'rig-v1.json'), wrapper_sha256=sha(Path(__file__)),
                base_recorder_sha256=sha(Path(core.__file__)), injection=injection,
                pcm_sha256=sha(output) if output.exists() else None)
            with output.with_suffix('.rig.json').open('x', encoding='utf8') as f:
                json.dump(report,f,indent=2)
                f.write('\n')
        # Preserve the explicit COM cleanup of the frozen RAW entry point.
        if a.backend=='raw' and mf._com.com_loaded:
            mf._ole32.CoUninitialize()
            mf._com.com_loaded = False


if __name__=='__main__':
    main()
