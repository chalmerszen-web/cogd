"""Descriptive endpoint/resource details alongside the frozen primary summary.

No new pass threshold or composite score. A stale timeout/reason on a negative
trial is excluded from current-wake endpoint counts, using counter deltas.
"""
import argparse
from collections import Counter
import json
from pathlib import Path

from analyze_study import distribution, sha

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / 'artifacts/voice-ab-1000-v1'
SPEECH = ('short', 'pause', 'speech')


def read(path):
    return json.loads(path.read_text(encoding='utf8'))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert not a.output.exists()
    rows = []
    for block in range(20):
        folder = RUN / 'formal' / f'block-{block:02d}'
        cache = read(RUN / 'acoustic-cache' / (folder.name + '.json'))
        for path in sorted(folder.glob('*/result.json')):
            row = read(path)
            assert row['complete']
            item = cache['results'][path.parent.name]
            assert item['result_sha256'] == sha(path)
            row['analysis'] = item['analysis']
            row['block'] = block
            rows.append(row)
    assert len(rows) == 1000
    output = {}
    for version in ('A', 'B'):
        items = [r for r in rows if r['version'] == version]
        assert len(items) == 500
        woke = [r for r in items if r['final']['wakes'] > r['before']['wakes']]
        detail = dict(categories={},
            wake_miss_details=[dict(pair=r['pair'], category=r['case']['category'], keyword=r['case']['keyword'],
                raw_keyword_delta=r['final'].get('keyword',{}).get('raw',0)-r['before'].get('keyword',{}).get('raw',0) if version=='B' else None,
                rejected_keyword_delta=r['final'].get('keyword',{}).get('rejected',0)-r['before'].get('keyword',{}).get('rejected',0) if version=='B' else None,
                background_rms=r.get('pre_silence_rms'), background_flag=r.get('background_flag'))
                for r in items if r['outcome']['wake_miss']],
            endpoint_reasons_current_wake=dict(Counter(str(r['final']['reason']) for r in woke)),
            errors_current_wake=dict(Counter(r['final']['error'] for r in woke)),
            limit_events=sum(r['final']['limited'] - r['before']['limited'] for r in items),
            detection_to_record_ms=distribution([r['final']['record_at']-r['final']['detected_at']
                for r in woke if r['final']['record_at']>=r['final']['detected_at']]),
            record_end_to_cue_end_ms=distribution([r['final']['cue_end_at']-r['final']['end_at']
                for r in woke if r['final']['cue_end_at']>=r['final']['end_at']>0]),
            keyword_raw_events=sum(r['final'].get('keyword',{}).get('raw',0)-r['before'].get('keyword',{}).get('raw',0) for r in items) if version=='B' else None,
            keyword_rejected_events=sum(r['final'].get('keyword',{}).get('rejected',0)-r['before'].get('keyword',{}).get('rejected',0) for r in items) if version=='B' else None,
            keyword_peak_us=max((r['final'].get('keyword',{}).get('max_us',0) for r in items),default=0) if version=='B' else None,
            verifier_peak_us=max((r['final'].get('verify',{}).get('max_us',0) for r in items),default=0) if version=='B' else None,
            verifier_nn_cpu_peak_us=max((r['final'].get('verify',{}).get('nn_cpu_max_us',0) for r in items),default=0) if version=='B' else None,
            verifier_stack_min=min((r['final']['verify']['stack'] for r in items if r['final'].get('verify',{}).get('stack')),default=None))
        for category in ('short','pause','speech','no_command','negative'):
            group = [r for r in items if r['case']['category'] == category]
            clips = [r for r in group if r['outcome']['completed_delta'] > 0]
            timing = [r['analysis']['voice_to_cue_s'] for r in group if r['analysis'].get('voice_to_cue_s') is not None]
            detail['categories'][category] = dict(n=len(group),
                accepted_clips=len(clips),
                limit_events=sum(r['final']['limited']-r['before']['limited'] for r in group),
                clip_ms=distribution([r['audio']['clip_ms'] for r in clips]),
                voice_to_cue_s=distribution(timing),
                negative_voice_to_cue=sum(t<0 for t in timing),
                device_whole_source_verified=sum(r['analysis'].get('device_full_source_verified',False) for r in clips),
                timing_unmeasured=len(group)-len(timing) if category in SPEECH else None)
        output[version] = detail
    pairs = {v:{r['pair']:r for r in rows if r['version']==v} for v in ('A','B')}
    latency_deltas = []
    for pair in range(500):
        x,y = (pairs[v][pair]['analysis'].get('voice_to_cue_s') for v in ('A','B'))
        if x is not None and y is not None:
            latency_deltas.append(dict(pair=pair, A_s=x, B_s=y, B_minus_A_s=y-x))
    result = dict(manifest_sha256=sha(RUN/'frozen-v3.json'),
        scope='Descriptive supplement; no added pass threshold. Clip matching is signal alignment, not speech recognition.',
        timing_limit='Only independently measurable source/cue pairs; missing timing is not counted as zero.',
        versions=output, paired_latency_B_minus_A_s=distribution([r['B_minus_A_s'] for r in latency_deltas]),
        paired_latency=latency_deltas)
    with a.output.open('x',encoding='utf8') as f:
        json.dump(result,f,indent=2)
        f.write('\n')
    print(json.dumps(dict(complete=True,trials=len(rows),paired_latency=len(latency_deltas))))


if __name__=='__main__':
    main()
