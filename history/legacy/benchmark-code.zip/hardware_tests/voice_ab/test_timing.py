"""Pure clock mapping regression tests; no device imports."""
import ast,json,copy
from pathlib import Path
root=Path(__file__).resolve().parents[2]
script=root/'tools/voice_ab_1000.py'
tree=ast.parse(script.read_text());ns={}
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='native_window'],type_ignores=[]),str(script),'exec'),ns)
window=ns['native_window']
b=root/'artifacts/voice-ab-1000-v1'
meta=json.loads((b/'preflight-a/A-000/external.wasapi.json').read_text())
result=json.loads((b/'preflight-a/A-000/result.json').read_text())
start=result['pre_silence_qpc_start']
actual=window(meta,start,start+1)
cases=[]
for ppm in (50,100,200):
 m=dict(complete=True,rate=48000,frames=96000,blocks=[dict(at=i*480,position=i*480,frames=480,written=480,qpc_100ns=round((10+i*.01*(1+ppm/1e6))*1e7)) for i in range(200)])
 w=window(m,10.25,11.25);assert abs(w['qpc_vs_nominal_ppm']-ppm)<.1;cases.append(ppm)
 for kind in ['gap','coverage']:
  bad=copy.deepcopy(m)
  if kind=='gap':bad['blocks'][10]['position']+=1
  try:window(bad,9 if kind=='coverage' else 10.25,11.25)
  except AssertionError:pass
  else:raise AssertionError(kind)
tail=window(meta,meta['blocks'][-1]['qpc_100ns']/1e7,meta['blocks'][-1]['qpc_100ns']/1e7+meta['blocks'][-1]['written']/48000)
assert tail['end']['nominal_tail']
out=dict(passed=True,actual=actual,drift_ppm_cases=cases,true_gap_rejections=3,coverage_rejections=3,nominal_tail_flag=True,device_access=False)
(b/'timing-v2-pure-check.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out))
