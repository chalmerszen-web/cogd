"""Run the frozen acoustic analysis one archived block at a time.

This storage adapter never changes the experiment, its result files, or the
analysis thresholds. Exact WAVs are restored, analyzed, and released only after
the archive verifies. Cached measurements can feed the frozen final summarizer.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import analyze_study as analysis

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / 'artifacts/voice-ab-1000-v1'
MANIFEST = RUN / 'frozen-v3.json'
CACHE = RUN / 'acoustic-cache'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf8'))


def storage(operation, block):
    subprocess.run([sys.executable, '-X', 'utf8',
                    str(Path(__file__).with_name('archive_recordings.py')),
                    operation, '--block', str(block)], check=True)


def identity():
    plan = read(MANIFEST)
    # Include the audio fixtures and imported analysis modules, not just this
    # adapter. All source bytes must still match the preregistered experiment.
    for name, expected in plan['source_sha256'].items():
        assert sha(ROOT / name) == expected, name
    assert sha(analysis.REFERENCE) == analysis.REFERENCE_SHA
    return dict(manifest_sha256=sha(MANIFEST),
                analyzer_sha256=sha(Path(analysis.__file__)),
                reference_sha256=analysis.REFERENCE_SHA)


def cache_block(number, expected):
    assert 0 <= number < 20
    name = f'block-{number:02d}'
    target = CACHE / (name + '.json')
    assert not target.exists(), 'Do not overwrite prior analysis'
    index = RUN / 'recording-archives' / (name + '.json')
    assert index.exists(), 'Archive and verify the closed block first'
    block = RUN / 'formal' / name
    rows = sorted(block.glob('*/result.json'))
    assert len(rows) == 50
    assert all(read(p).get('complete') for p in rows)
    rate, reference = analysis.pcm(analysis.REFERENCE)
    measured = {}
    storage('restore', number)
    try:
        for path in rows:
            row = read(path)
            value = analysis.acoustic(path.parent, row, rate, reference)
            assert value['available'], path
            measured[path.parent.name] = dict(result_sha256=sha(path), analysis=value)
        payload = dict(**expected, archive_index_sha256=sha(index),
                       storage_adapter_sha256=sha(Path(__file__)),
                       block=name, results=measured)
        CACHE.mkdir(exist_ok=True)
        with target.open('x', encoding='utf8') as stream:
            json.dump(payload, stream, indent=2)
            stream.write('\n')
    finally:
        storage('release', number)
    print(json.dumps(dict(block=name, analyzed=len(measured),
        acoustic_timing=sum(v['analysis'].get('voice_to_cue_s') is not None
                            for v in measured.values()))))


def summarize(output, expected):
    caches = {}
    for number in range(20):
        name = f'block-{number:02d}'
        cached = read(CACHE / (name + '.json'))
        assert all(cached[k] == v for k, v in expected.items()), name
        assert cached['archive_index_sha256'] == sha(
            RUN / 'recording-archives' / (name + '.json'))
        assert len(cached['results']) == 50
        caches[name] = cached['results']

    def from_cache(folder, row, reference_rate, reference):
        item = caches[folder.parent.name][folder.name]
        assert item['result_sha256'] == sha(folder / 'result.json')
        return item['analysis']

    # The frozen summary logic receives exactly the measurements produced by
    # its own acoustic() function. No reimplementation of scores or statistics.
    analysis.acoustic = from_cache
    sys.argv = [str(Path(analysis.__file__)), '--root', str(RUN / 'formal'),
                '--manifest', str(MANIFEST), '--output', str(output), '--acoustic']
    analysis.main()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['cache', 'summary'])
    p.add_argument('--block', type=int)
    p.add_argument('--output', type=Path)
    args = p.parse_args()
    expected = identity()
    if args.mode == 'cache':
        assert args.block is not None
        cache_block(args.block, expected)
    else:
        assert args.output is not None
        summarize(args.output, expected)


if __name__ == '__main__':
    main()
