"""Read-only compact progress; never opens serial/audio or changes evidence."""
import json
from pathlib import Path
import shutil
import statistics
import time

ROOT=Path(__file__).resolve().parents[2]
RUN=ROOT/'artifacts/voice-ab-1000-v1'

def main():
    done={'A':set(),'B':set()};outcomes={'A':[],'B':[]};durations=[];started={};errors=[];last=None
    for path in sorted((RUN/'formal').glob('block-*/events.jsonl')):
        version=None
        for line in path.read_text(encoding='utf8').splitlines():
            try:event=json.loads(line)
            except json.JSONDecodeError:continue
            last=event
            if event['kind']=='block_start':version=event['block']['version']
            if event['kind']=='trial_start':started[(version,event['pair'])]=event['at']
            if event['kind']=='trial_end':
                key=(version,event['pair']);done[version].add(event['pair']);outcomes[version].append(event['outcome'])
                if key in started:durations.append(event['at']-started[key])
            if event['kind']=='paused':errors.append(event)
    total=sum(map(len,done.values()));mean=statistics.mean(durations[-50:]) if durations else None
    result=dict(at=time.time(),complete=total,scheduled=1000,paired=len(done['A']&done['B']),
        by_version={v:dict(n=len(done[v]),wake_misses=sum(x['wake_miss'] for x in outcomes[v]),
            false_accepts=sum(x['false_accept'] for x in outcomes[v]),
            no_command_clips=sum(x['no_command_published'] for x in outcomes[v]),
            dma_nonzero=sum(x['dma_delta']!=0 for x in outcomes[v])) for v in done},
        recent_seconds_per_trial=mean,remaining_trial_hours=(1000-total)*mean/3600 if mean else None,
        remaining_time_note='Trial throughput only; excludes switching, recovery and analysis',
        free_disk_gib=shutil.disk_usage(ROOT).free/2**30,pauses=errors,last_event=last)
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
