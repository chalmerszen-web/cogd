"""Summarize all scheduled trials, including misses and missing evidence.

Statistics describe repeated fixtures on one board. Wilson intervals treat
trials as Bernoulli repeats, not independent speakers or deployment accuracy.
"""
import argparse
import csv
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import wave
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from analyze_wake_timing import envelope,align

REFERENCE=ROOT/'artifacts/wake/hilexin550-higher-swoosh-edge/002/external.wav'
REFERENCE_SHA='adfc428f49e087c2a23659fc30cc5cfce22e563bd3261725e06d99ed362821e6'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf8'))
def pcm(path):
    with wave.open(str(path),'rb') as w:
        assert w.getsampwidth()==2 and w.getnchannels()==1
        return w.getframerate(),np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(float)

def cues(rate,samples,reference_rate,reference,start,seconds):
    original=reference[round(start*reference_rate):round((start+seconds)*reference_rate)]
    t=np.interp(np.arange(round(seconds*rate))*reference_rate/rate,np.arange(len(original)),original)
    t-=t.mean();n=len(t);energy=float(t@t)
    if len(samples)<n or not energy:return []
    size=1<<(len(samples)+n-2).bit_length()
    dot=np.fft.irfft(np.fft.rfft(samples,size)*np.fft.rfft(t[::-1],size),size)[n-1:len(samples)]
    sums=np.r_[0,np.cumsum(samples)];squares=np.r_[0,np.cumsum(samples*samples)]
    variance=np.maximum(0,squares[n:]-squares[:-n]-(sums[n:]-sums[:-n])**2/n)
    score=dot/np.sqrt(np.maximum(energy*variance,1));gain=dot/energy
    candidates=np.where((abs(score)>=.8)&(abs(gain)>=.1),abs(score),0)
    found=[]
    while np.max(candidates)>0:
        at=int(np.argmax(candidates));found.append(dict(start_s=at/rate,correlation=float(score[at]),gain=float(gain[at])))
        candidates[max(0,at-n):min(len(candidates),at+n+1)]=0
    return sorted(found,key=lambda r:r['start_s'])

def acoustic(folder,row,ref_rate,ref):
    path=folder/'external.wav'
    if not path.exists():return dict(available=False)
    rate,samples=pcm(path)
    out=dict(available=True,sha256=sha(path),rate=rate,seconds=len(samples)/rate,
        clipped_samples=int(np.count_nonzero(abs(samples)>=32767)),
        dings=cues(rate,samples,ref_rate,ref,2.54,.16),
        endings=cues(rate,samples,ref_rate,ref,4.93,.18),voice_to_cue_s=None)
    utterance=row['case'].get('utterance')
    if not utterance or not (folder/'speech-output.json').exists():return out
    reference,last=envelope(ROOT/utterance);target,_=envelope(path)
    found=align(reference,target,0,len(samples)/rate-len(reference)*.01)
    out.update(source_match=found,last_source_abs40_s=last)
    if found and found['correlation']>=.75 and last is not None and len(out['dings'])==1 and len(out['endings'])==1:
        start=found['start_s'];cue=out['endings'][0]['start_s']
        # Do not force the entire source to precede the cue: negative delays
        # are evidence of premature completion and must not disappear.
        if start>=out['dings'][0]['start_s']+.15:
            out['voice_to_cue_s']=cue-start-last
            out['whole_source_before_cue']=start+len(reference)*.01<=cue
    device=folder/'device.wav'
    if device.exists():
        dr,dp=pcm(device);de,_=envelope(device)
        match=align(reference,de,0,len(dp)/dr-len(reference)*.01)
        out['device_source_match']=match
        out['device_full_source_verified']=bool(match and match['correlation']>=.75)
    return out

def wilson(k,n):
    if not n:return None
    z=1.959963984540054;p=k/n;d=1+z*z/n
    m=(p+z*z/(2*n))/d;s=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return dict(count=k,total=n,rate=p,wilson95=[m-s,m+s])
def distribution(values):
    v=sorted(values)
    if not v:return dict(n=0)
    return dict(n=len(v),minimum=v[0],median=statistics.median(v),p95=v[math.ceil(.95*len(v))-1],maximum=v[-1])

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--manifest',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--acoustic',action='store_true');a=p.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    plan=read(a.manifest);rows=[];reference_rate,reference=0,None
    if a.acoustic:
        assert sha(REFERENCE)==REFERENCE_SHA
        reference_rate,reference=pcm(REFERENCE)
    for path in sorted(a.root.glob('block-*/*/result.json')):
        row=read(path);row['evidence']=str(path.relative_to(ROOT))
        if a.acoustic:row['analysis']=acoustic(path.parent,row,reference_rate,reference)
        rows.append(row)
    groups={v:[r for r in rows if r['version']==v] for v in ('A','B')};summary={}
    metrics=('wake_miss','false_accept','no_command_published','speech_not_played','speech_played_but_no_clip','premature_before_source_file_finished','failed_state')
    for version,items in groups.items():
        complete=[r for r in items if r.get('complete') and 'outcome' in r]
        result=dict(attempted=len(items),complete=len(complete),infrastructure_failures=sum('infrastructure_error' in r for r in items),categories={})
        for category in plan['category_counts']:
            subset=[r for r in complete if r['case']['category']==category]
            result['categories'][category]=dict(n=len(subset),**{m:wilson(sum(bool(r['outcome'].get(m)) for r in subset),len(subset)) for m in metrics},
                clips=wilson(sum(r['outcome']['completed_delta']>0 for r in subset),len(subset)))
        result['voice_to_cue_seconds']=distribution([r['analysis']['voice_to_cue_s'] for r in complete if r.get('analysis',{}).get('voice_to_cue_s') is not None])
        result['source_file_to_record_end_midpoint_seconds']=distribution([statistics.mean(r['outcome']['endpoint_after_source_file_seconds_interval']) for r in complete if r['outcome'].get('endpoint_after_source_file_seconds_interval') is not None])
        samples=[]
        for r in items:
            samples.extend(r[k] for k in ('status_before','status_after') if k in r)
            samples.extend(x['status'] for x in r.get('resources',[]))
        result['resources']={k:distribution([s[k] for s in samples if k in s]) for k in ('free_heap','min_heap','largest_block','stack_watermark','worker_stack','control_stack')}
        result['dma_trials']=sum(r.get('outcome',{}).get('dma_delta',0)!=0 for r in complete)
        result['counter_regression_trials']=sum(any(r.get('final',{}).get(k,0)<r.get('before',{}).get(k,0) for k in ('wakes','completed','empty','dma_lost')) for r in complete)
        result['wake_inference_max_us']=distribution([r['final']['inference_max_us'] for r in complete if 'inference_max_us' in r.get('final',{})])
        result['audio_stack_bytes']=distribution([x['audio']['audio_stack'] for r in complete for x in r.get('resources',[]) if 'audio_stack' in x.get('audio',{})])
        result['adc_clipping_samples']=distribution([r['audio']['record_adc_clipped'] for r in complete if 'record_adc_clipped' in r.get('audio',{})])
        result['external_clipping_trials']=sum(r.get('analysis',{}).get('clipped_samples',0)>0 for r in complete)
        result['automatic_rearm_unknown_trials']=sum(r.get('automatic_rearm_ok') is not True for r in complete)
        result['background_flag_trials']=sum(bool(r.get('background_flag')) for r in complete)
        result['background_unknown_trials']=sum(r.get('pre_silence_rms') is None for r in complete)
        result['background_rms']=distribution([r['pre_silence_rms'] for r in complete if r.get('pre_silence_rms') is not None])
        summary[version]=result
    by={v:{r['pair']:r for r in groups[v] if r.get('complete') and 'outcome' in r} for v in groups};paired={}
    for metric in metrics:
        discord=Counter();differences=[]
        for pair in sorted(set(by['A'])&set(by['B'])):
            if metric=='false_accept' and by['A'][pair]['case']['category']!='negative':continue
            if metric=='wake_miss' and by['A'][pair]['case']['category']=='negative':continue
            if metric=='no_command_published' and by['A'][pair]['case']['category']!='no_command':continue
            if metric in ('speech_not_played','speech_played_but_no_clip','premature_before_source_file_finished') and by['A'][pair]['case']['category'] not in ('short','pause','speech'):continue
            x=int(bool(by['A'][pair]['outcome'].get(metric)));y=int(bool(by['B'][pair]['outcome'].get(metric)))
            discord[f'A{x}B{y}']+=1;differences.append(y-x)
        b=discord['A1B0'];c=discord['A0B1'];n=b+c
        prob=min(1,2*sum(math.comb(n,k) for k in range(min(b,c)+1))/2**n) if n else 1
        paired[metric]=dict(n=len(differences),counts=dict(discord),B_minus_A=statistics.mean(differences) if differences else None,exact_mcnemar_p=prob,
            inference_limit='Repeated known fixtures; not independent speakers. Exploratory multiple metrics, no population superiority claim.')
    out=dict(manifest_sha256=sha(a.manifest),scheduled=plan['total_trials'],summary=summary,paired=paired,
        results=[{k:v for k,v in r.items() if k not in ('states','resources','before','final','audio','status_before','status_after','audio_before','automatic_rearm','rearm')} for r in rows])
    a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
    fields=['version','pair','category','complete','wake_miss','false_accept','completed_delta','empty_delta','speech_not_played',
        'speech_played_but_no_clip','no_command_published','premature_before_source_file_finished','device_error','dma_delta',
        'record_reason','clip_ms','minimum_heap_bytes','voice_to_cue_s','background_rms','background_flag','infrastructure_error','evidence']
    with a.output.with_suffix('.csv').open('x',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in rows:
            data={k:row.get('outcome',{}).get(k) for k in fields}
            data.update(version=row['version'],pair=row['pair'],category=row['case']['category'],complete=row.get('complete'),
                record_reason=row.get('final',{}).get('reason'),clip_ms=row.get('audio',{}).get('clip_ms'),
                minimum_heap_bytes=row.get('status_after',{}).get('min_heap'),voice_to_cue_s=row.get('analysis',{}).get('voice_to_cue_s'),
                background_rms=row.get('pre_silence_rms'),background_flag=row.get('background_flag'),
                infrastructure_error=row.get('infrastructure_error'),evidence=row['evidence'])
            writer.writerow(data)
    print(json.dumps(dict(scheduled=out['scheduled'],summary={v:{k:s[k] for k in ('attempted','complete','infrastructure_failures')} for v,s in summary.items()})))

if __name__=='__main__':main()
