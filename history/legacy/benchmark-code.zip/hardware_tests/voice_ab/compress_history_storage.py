"""Lossless NTFS storage compression of existing project WAVs, with SHA audit.

No deletion, transcoding, renaming, audio-device use, or experimental changes.
Only explicitly enumerated regular WAVs under artifacts/wake are passed to the
Windows compressor; no directory compression policy or OS setting is changed.
"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / 'artifacts/voice-ab-1000-v1'
WAV_ROOT = (ROOT / 'artifacts/wake').resolve()


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def save(path, data):
    with path.open('x', encoding='utf8') as f:
        json.dump(data, f, indent=2)
        f.write('\n')


def main():
    assert WAV_ROOT.is_relative_to(ROOT.resolve())
    folder = RUN / 'history-storage'
    folder.mkdir(exist_ok=False)
    files = sorted(f for f in WAV_ROOT.rglob('*.wav')
                   if f.is_file() and not f.is_symlink())
    assert files and all(f.resolve().is_relative_to(WAV_ROOT) for f in files)
    before = {str(f.relative_to(ROOT)):dict(bytes=f.stat().st_size, sha256=sha(f))
              for f in files}
    start = dict(at=time.time(), free_bytes=shutil.disk_usage(ROOT).free,
                 files=before, method='NTFS compression on enumerated files only')
    save(folder / 'before.json', start)
    compact = shutil.which('compact.exe')
    assert compact
    codes = []
    with (folder / 'compact.log').open('xb') as log:
        for offset in range(0,len(files),32):
            batch = files[offset:offset+32]
            code = subprocess.call([compact,'/C','/I','/Q',*map(str,batch)],
                                   stdout=log,stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
            codes.append(code)
    mismatches = [name for name,item in before.items()
                  if (ROOT/name).stat().st_size != item['bytes'] or sha(ROOT/name) != item['sha256']]
    result = dict(at=time.time(), files=len(files), original_bytes=sum(x['bytes'] for x in before.values()),
                  compact_exit_counts={str(c):codes.count(c) for c in set(codes)},
                  sha_mismatches=mismatches, all_original_bytes_preserved=not mismatches,
                  free_bytes=shutil.disk_usage(ROOT).free, before_sha256=sha(folder/'before.json'))
    save(folder / 'after.json',result)
    print(json.dumps(result))
    assert not mismatches and all(c==0 for c in codes)


if __name__=='__main__':
    main()
