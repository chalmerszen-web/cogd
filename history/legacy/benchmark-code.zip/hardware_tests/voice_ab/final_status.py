"""One bounded post-restore check; never start capture, playback or a cloud request."""
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / 'artifacts/voice-ab-1000-v1'
sys.path.insert(0, str(ROOT / 'tools'))
from hardware_m2 import Device
from serial_link import connect


def main():
    output = RUN / 'final-device-status.json'
    assert not output.exists(), 'Preserve the first final check'
    controller = json.loads((RUN / 'formal-v1-resume2/progress.json').read_text())
    assert controller.get('complete') and controller.get('restored')
    expected = json.loads((RUN / 'formal-v1/configure-00.json').read_text())['context']
    with connect('COM5') as link:
        d = Device(link, output)
        d.report['started'] = time.time()
        try:
            for command in ('agent cancel', 'agent wake off', 'agent mic off', 'agent audio stop'):
                d.run(command)
            status = d.get('status')
            audio = d.get('audio status')
            wake = d.get('wake status')
            context = d.get('context stats')
            light = d.get('light get')
            gpio = d.get('gpio get {"pin":10}')
            control = d.get('control status')
            d.report.update(status=status, audio=audio, wake=wake, context=context,
                            light=light, gpio10=gpio, control=control)
            assert status['version'] == '0.5.1-lean' and not status['busy']
            assert context == expected
            assert not audio['playing'] and not audio['mic_enabled']
            assert not audio.get('capturing', False) and audio['volume'] == 80
            assert not wake['enabled'] and wake['state'] == 'off'
            assert not control['active'] and gpio['mode'] == 'input'
            assert all(light[k] == 0 for k in ('r', 'g', 'b'))
            d.report['passed'] = True
        except BaseException as error:
            d.report['error'] = repr(error)
            raise
        finally:
            d.report['ended'] = time.time()
            d.save()
    d.report['serial_closed'] = not link.is_open
    d.save()
    print(json.dumps(dict(passed=d.report['passed'], serial_closed=d.report['serial_closed'],
                         version=status['version'], context_used=context['used'])))


if __name__ == '__main__':
    main()
