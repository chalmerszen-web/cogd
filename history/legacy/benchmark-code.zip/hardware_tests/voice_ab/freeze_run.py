"""Bind the pre-registered acoustic schedule to the two actual images."""
import hashlib
import json
import argparse
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
RUN=ROOT/'artifacts/voice-ab-1000-v1'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--schedule',type=Path,default=RUN/'manifest.json')
    p.add_argument('--name',default='frozen');p.add_argument('--a-instrument-only',action='store_true');a=p.parse_args()
    target=RUN/(a.name+'.json')
    if target.exists(): raise FileExistsError(target)
    plan=json.loads(a.schedule.read_text())
    expected={'A':'dc0d3b6c762064f728616182d6564cce8f573dda71772c2f4fa517ba8974ee10',
              'B':'d9bd6975088b733d7c2f2976a4698f9c744de34a354a5b5929599df0ff68c953'}
    images={'A':'build-voice-ab-vendor/esp_hi_agent.bin','B':'build-coarse-profile-v1-device/esp_hi_agent.bin'}
    plan['versions']={v:dict(path=p,sha256=sha(ROOT/p),bytes=(ROOT/p).stat().st_size) for v,p in images.items()}
    assert all(plan['versions'][v]['sha256']==expected[v] for v in expected)
    assert (ROOT/'build-voice-ab-vendor/partition_table/partition-table.bin').read_bytes()==(
        ROOT/'build-agent-lean/partition_table/partition-table.bin').read_bytes()
    plan['baseline'] = json.loads((RUN/'baseline-source.json').read_text())
    plan['source_sha256']['hardware_tests/voice_ab/freeze_run.py']=sha(Path(__file__))
    plan['source_sha256']['hardware_tests/voice_ab/flash_manager.py']=sha(ROOT/'hardware_tests/voice_ab/flash_manager.py')
    plan['source_sha256']['hardware_tests/voice_ab/run_study.py']=sha(ROOT/'hardware_tests/voice_ab/run_study.py')
    plan['source_sha256']['hardware_tests/voice_ab/analyze_study.py']=sha(ROOT/'hardware_tests/voice_ab/analyze_study.py')
    plan['build_config_sha256']=sha(RUN/'baseline/sdkconfig')
    plan['vad_vendor_binary_sha256']=sha(ROOT/'_ref/esp-sr/lib/esp32c3/libesp_audio_processor.a')
    plan['fixed_settings']=dict(board='ESP-HI ESP32-C3 COM5',adc_rate=32000,mic_rate=16000,atten_db=12,
        threshold=550,input_gain=1,output_volume=80,pc_gain=.6,wifi_power_save='none',
        endpoint_mic='{0.0.1.00000000}.{bd5300f8-2052-4c06-9331-6788ff0f6d02}',output='头戴式耳机 (Misiom-Shooter)')
    for f,h in plan['source_sha256'].items(): assert sha(ROOT/f)==h,f
    target.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8')
    preflight=dict(plan)
    preflight['total_trials']=10
    preflight['scope']='Instrument preflight only; excluded from the 1000. No outcome-based algorithm tuning.'
    preflight['blocks']=[dict(index=i,group=-1,version=v,pairs=[0,15,25,30,40]) for i,v in enumerate(['A','B'])]
    if a.a_instrument_only:
        preflight['blocks'][0]['pairs']=[40]
        preflight['total_trials']=6
    preflight_path=RUN/(a.name+'-preflight.json')
    preflight_path.write_text(json.dumps(preflight,indent=2)+'\n',encoding='utf8')
    (RUN/(a.name+'-sha.json')).write_text(json.dumps(dict(formal=sha(target),preflight=sha(preflight_path)),indent=2)+'\n')
    print(json.dumps(dict(versions=plan['versions'],manifest_sha256=sha(target))))

if __name__=='__main__': main()
