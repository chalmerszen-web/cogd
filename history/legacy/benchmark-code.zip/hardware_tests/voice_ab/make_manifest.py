"""Freeze 500 mixed paired trials, without audio or device access."""
import argparse,ast,hashlib,json,random
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    path=parser.parse_args().output
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():raise SystemExit('Preserve manifest; explicitly archive draft before freezing')
    fixtures=ROOT/'artifacts/wake/fixtures'
    pairs=[];blocks=[];rng=random.Random(9221);counts=Counter()
    expected=dict(short=15,pause=10,speech=5,no_command=10,negative=10)
    negatives=[v+'-negative'+str(i)+'.wav' for v in ('huihui','kangkang') for i in range(1,5)]+['near-kuai.wav','near-laojin.wav','near-xiaowang.wav','near-light.wav']
    for group in range(10):
        ids=[]
        for category,count in expected.items():
            for _ in range(count):
                i=counts[category];counts[category]+=1
                keyword=['huihui-hilexin.wav','kangkang-hilexin.wav','hilexin-official.wav'][sum(counts.values())%3]
                utterance=None
                if category=='short':utterance=['huihui-short.wav','kangkang-short.wav','quick-hao-trim.wav','quick-haode-trim.wav'][i%4]
                if category in ('pause','speech'):utterance=['huihui','kangkang'][i%2]+'-'+category+'.wav'
                if category=='negative':keyword=negatives[i%len(negatives)]
                ids.append(len(pairs));pairs.append(dict(id=len(pairs),group=group,category=category,keyword=(fixtures/keyword).relative_to(ROOT).as_posix(),utterance=(fixtures/utterance).relative_to(ROOT).as_posix() if utterance else None,gain=.6))
        rng.shuffle(ids)
        assert Counter(pairs[i]['category'] for i in ids)==expected
        for version in (['A','B'] if group%2==0 else ['B','A']):
            blocks.append(dict(index=len(blocks),group=group,version=version,pairs=ids.copy()))
    files={ROOT/'tools/voice_ab_1000.py',Path(__file__)}
    files|={ROOT/c[k] for c in pairs for k in ['keyword','utterance'] if c[k]}
    # Freeze local Python imports and subprocess helper scripts transitively.
    pending=[ROOT/'tools'/x for x in ['serial_link.py','hardware_m2.py','record_speaker.py','record_loopback.py','wake_trial.py','wave_play.py','record_wasapi.py','analyze_wake_timing.py','analyze_wake_cues.py']]
    while pending:
        f=pending.pop()
        if f in files:continue
        files.add(f)
        for node in ast.walk(ast.parse(f.read_text(encoding='utf-8-sig'))):
            names=[node.module] if isinstance(node,ast.ImportFrom) else [v.name for v in node.names] if isinstance(node,ast.Import) else []
            for name in names:
                if name:
                    dep=ROOT/'tools'/(name.split('.')[0]+'.py')
                    if dep.exists() and dep not in files:pending.append(dep)
    hashes={f.resolve().relative_to(ROOT).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
    assert len(pairs)==500 and len(blocks)==20
    plan=dict(seed=9221,total_trials=1000,pairs=pairs,blocks=blocks,category_counts=dict(counts),source_sha256=hashes,versions=dict(A='vendor_baseline image pending supervisor binding',B='d9bd6975088b733d7c2f2976a4698f9c744de34a354a5b5929599df0ff68c953'),scope='Real acoustic; no injected noise or pure-silence subclass; cancel not in design. Image preflight and flash/restore owned by supervisor.')
    path.write_text(json.dumps(plan,indent=2)+'\n')
    print(json.dumps(dict(pairs=500,blocks=20,counts=dict(counts),sources=len(hashes))))
if __name__=='__main__':main()
