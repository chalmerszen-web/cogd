"""Freeze a board-adapted upstream algorithm baseline, without editing the Agent.

The historical optimized binary is compared as released. This A image uses the
pre-lean common Agent sources, vendor WakeNet9s and vendor WebRTC VAD trigger.
It is not an Espressif-distributed ESP-HI firmware or an AFE/VADNet benchmark.
"""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'artifacts/voice-ab-1000-v1/baseline'


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    for name in ('main', 'core', 'plugins', 'platform', 'boards', 'third_party', 'components'):
        shutil.copytree(ROOT / name, OUT / name,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    old = ROOT / 'artifacts/agent-lean-v1/source-before'
    overlays = []
    for path in old.rglob('*'):
        relative = path.relative_to(old)
        if path.is_file() and (OUT / relative).is_file():
            shutil.copy2(path, OUT / relative)
            overlays.append(relative.as_posix())
    for name in ('partitions.csv', 'dependencies.lock', 'sdkconfig.defaults'):
        shutil.copy2(ROOT / name, OUT / name)
    shutil.copy2(ROOT / 'artifacts/wake/coarse-profile-v1/project/sdkconfig', OUT / 'sdkconfig')
    root = ROOT.as_posix()
    (OUT / 'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.22)
set(IDF_TARGET esp32c3 CACHE STRING "Target")
set(EXTRA_COMPONENT_DIRS "''' + root + '''/managed_components")
include($ENV{IDF_PATH}/tools/cmake/project.cmake)
idf_build_set_property(MINIMAL_BUILD ON)
project(esp_hi_agent)
''', encoding='utf8')
    cmake = OUT / 'components/agent_speech/CMakeLists.txt'
    text = cmake.read_text(encoding='utf8').replace(
        'set(sr "${agent_root}/_ref/esp-sr")', f'set(sr "{root}/_ref/esp-sr")').replace(
        '"${agent_root}/tools/pack_wake_model.py"', f'"{root}/tools/pack_wake_model.py"')
    cmake.write_text(text, encoding='utf8')
    backend = OUT / 'components/agent_speech/speech_backend.c'
    text = backend.read_text(encoding='utf8')
    assert text.count('vad=vad_create(vad_creation_mode);') == 1
    text = text.replace('vad=vad_create(vad_creation_mode);',
        'vad=vad_create_with_param(vad_creation_mode,16000,20,128,1000);')
    assert text.count('vad_process(vad,pcm,16000,20)') == 1
    text = text.replace('vad_process(vad,pcm,16000,20)', 'vad_process_with_trigger(vad,pcm)')
    backend.write_text(text, encoding='utf8')
    board = OUT / 'boards/esp_hi/audio_board.c'
    text = board.read_text(encoding='utf8')
    text = text.replace('int16_t filtered=agent_voice_filter(&vad_filter,value);',
                        'int16_t filtered=value; /* Upstream VAD gets board ADC PCM directly. */')
    text = text.replace('audio_work.input.vad[vad_used++]=agent_voice_reject_cue(&cue_filter,filtered);',
                        'audio_work.input.vad[vad_used++]=filtered;')
    old_feed = '''bool voice=endpoint.elapsed_ms>=40 && esp_hi_speech_vad(audio_work.input.vad);
            voice=agent_activity_feed(&activity,audio_work.input.vad,320,false,voice,endpoint.state==AGENT_EP_SPEECH);'''
    assert text.count(old_feed) == 1
    text = text.replace(old_feed, 'bool voice=esp_hi_speech_vad(audio_work.input.vad);')
    board.write_text(text, encoding='utf8')
    shutil.copy2(Path(__file__).with_name('vendor_endpoint.c'), OUT / 'plugins/audio/endpoint.c')
    manifest = dict(overlays=sorted(overlays), sources={
        p.relative_to(OUT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(OUT.rglob('*')) if p.is_file()},
        vendor_commit='efa8d907c6d457cd0f99dae6c6b493412d3078d4',
        label='Official algorithms with ESP-HI board adapter; shared threshold 0.55',
        vad=dict(mode=3, rate=16000, frame_ms=20, min_speech_ms_requested=128, min_noise_ms=1000),
        endpoint=dict(wait_ms=4000, maximum_ms=10000, extra_votes=False, extra_energy_gate=False),
        extra_keyword_gate=False, extra_neural_verifier=False, custom_vad_filters=False)
    (OUT.parent / 'baseline-source.json').write_text(json.dumps(manifest, indent=2), encoding='utf8')
    print(json.dumps(dict(project=str(OUT), files=len(manifest['sources']), overlays=overlays)))


if __name__ == '__main__':
    main()
