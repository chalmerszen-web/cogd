"""Archive and analyze completed blocks without touching the running recorder."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / 'artifacts/voice-ab-1000-v1'


def invoke(script, *args):
    subprocess.run([sys.executable, '-X', 'utf8',
                    str(Path(__file__).with_name(script)), *args], check=True)


def main():
    deadline = time.monotonic() + 8 * 3600
    for number in range(20):
        name = f'block-{number:02d}'
        cache = RUN / 'acoustic-cache' / (name + '.json')
        if cache.exists():
            assert len(json.loads(cache.read_text())['results']) == 50
            continue
        event_path = RUN / 'formal' / name / 'events.jsonl'
        while True:
            events = event_path.read_text().splitlines() if event_path.exists() else []
            try:
                closed = bool(events and json.loads(events[-1])['kind'] == 'block_closed')
            except json.JSONDecodeError:
                closed = False  # Writer may be appending this exact final line.
            if closed:
                break
            assert time.monotonic() < deadline, 'Timed out waiting for closed block'
            time.sleep(5)
        if not (RUN / 'recording-archives' / (name + '.json')).exists():
            invoke('archive_recordings.py', 'archive', '--block', str(number))
        invoke('analyze_archives.py', 'cache', '--block', str(number))
        state = dict(last_block=number, cached=number + 1, at=time.time(),
                     free_disk_gib=shutil.disk_usage(ROOT).free / 2**30)
        temporary = RUN / 'archive-progress.partial'
        temporary.write_text(json.dumps(state, indent=2) + '\n', encoding='utf8')
        temporary.replace(RUN / 'archive-progress.json')
        print(json.dumps(state), flush=True)


if __name__ == '__main__':
    main()
