"""Offline timing-v3 regression and preserved A-v2 quality extraction; no device imports."""
import ast, json, hashlib, copy
from pathlib import Path
root=Path(__file__).resolve().parents[2]
b=root/'artifacts/voice-ab-1000-v1'
p=root/'tools/voice_ab_1000.py'
tree=ast.parse(p.read_text()); ns={}
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ('quality','native_window')],type_ignores=[]),str(p),'exec'),ns)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out=b/'preflight-a-v2/reanalysis.json'
assert not out.exists()
rows=[]
for folder in sorted((b/'preflight-a-v2').glob('A-*')):
 r=read(folder/'result.json'); states=copy.deepcopy(r['states'])
 assert all(states[-1][k]==r['final'][k] for k in ('state','wakes','completed','empty','error','dma_lost'))
 playback=None
 if (folder/'speech-output.json').exists():
  playback=read(folder/'speech-output.json');playback['finished_relative']=playback['finished']-r['host_start']
 q=ns['quality'](r['case'],r['before'],states,playback)
 if r.get('outcome'): assert q==r['outcome']
 meta=read(folder/'external.wasapi.json'); loop=read(folder/'computer-output.loopback.json')
 assert meta['complete'] and loop['complete'] and meta['rate']==loop['rate']==48000
 row=dict(pair=r['pair'],category=r['case']['category'],original_result_sha256=sha(folder/'result.json'),original_complete=r['complete'],outcome=q,capture_complete=True,player_exit_codes=r['processes'])
 try:
  row['pre_silence_clock']=ns['native_window'](meta,r['pre_silence_qpc_start'],r['pre_silence_qpc_start']+1)
  row['pre_silence_rms']=r.get('pre_silence_rms');row['background_flag']=r.get('background_flag')
 except AssertionError as e:
  row.update(coverage_error=repr(e),pre_silence_rms=None,background_flag=None,first_packet_late_seconds=meta['blocks'][0]['qpc_100ns']/1e7-r['pre_silence_qpc_start'])
 rows.append(row)
assert len(rows)==5 and rows[-1]['pair']==40 and rows[-1]['background_flag'] is None
assert .0016<rows[-1]['first_packet_late_seconds']<.0017
# Exercise the actual try blocks with auxiliary failures, preserving quality.
main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
tries=[x for x in ast.walk(main) if isinstance(x,ast.Try) and any(isinstance(n,ast.Constant) and n.value in ('coverage_error','analysis_error') for h in x.handlers for n in ast.walk(h))]
assert len(tries)==2
for t in tries:
 env={'r':{'outcome':{'completed_delta':1}},'playback':True}
 exec(compile(ast.Module(body=[t],type_ignores=[]),str(p),'exec'),env)
 assert env['r']['outcome']=={'completed_delta':1}
 assert 'coverage_error' in env['r'] or 'analysis_error' in env['r']
assert 'time.sleep(.25)' in p.read_text()
report=dict(complete=True,device_access=False,runner_sha256=sha(p),auxiliary_failure_tests=2,cases=rows,scope='Offline existing quality and clock coverage only; original results unchanged')
out.write_text(json.dumps(report,indent=2))
print(json.dumps(dict(passed=True,cases=5,auxiliary_failure_tests=2,negative_gap_seconds=rows[-1]['first_packet_late_seconds'])))
