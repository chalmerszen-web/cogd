"""Use the frozen trial runner with an explicitly recorded capture-buffer shim."""
from pathlib import Path
import subprocess
import sys

from buffered_capture import ROOT, check_rig

sys.path.insert(0,str(ROOT/'tools'))
import voice_ab_1000 as trial


def main():
    rig = check_rig()
    popen = subprocess.Popen
    targets = {(ROOT/'tools/record_wasapi.py').resolve():'raw',
               (ROOT/'tools/record_loopback.py').resolve():'loopback'}

    def capture_dispatch(command, *args, **kwargs):
        if isinstance(command,(list,tuple)):
            command = list(command)
            for at, token in enumerate(command):
                if str(token).endswith('.py') and Path(token).resolve() in targets:
                    backend = targets[Path(token).resolve()]
                    command[at:at+1] = [str(Path(__file__).with_name('buffered_capture.py')),
                        '--backend',backend,'--actual-buffer-ms',str(rig['capture_buffer_ms'])]
                    break
        return popen(command,*args,**kwargs)

    subprocess.Popen = capture_dispatch
    trial.main()


if __name__=='__main__':
    main()
