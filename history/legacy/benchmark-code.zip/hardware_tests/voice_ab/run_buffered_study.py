"""Keep the frozen supervisor/restore path; dispatch the amended recorder shim."""
from pathlib import Path
import subprocess

from buffered_capture import ROOT, check_rig
import run_study as study


def main():
    check_rig()
    call = subprocess.call
    original = (ROOT/'tools/voice_ab_1000.py').resolve()

    def trial_dispatch(command, *args, **kwargs):
        command = list(command)
        for at, token in enumerate(command):
            if str(token).endswith('.py') and Path(token).resolve()==original:
                command[at] = str(Path(__file__).with_name('buffered_trial.py'))
                break
        return call(command,*args,**kwargs)

    subprocess.call = trial_dispatch
    study.main()


if __name__=='__main__':
    main()
