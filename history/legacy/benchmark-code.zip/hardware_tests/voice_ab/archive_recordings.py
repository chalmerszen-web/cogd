"""Lossless storage of closed blocks; validate every byte before removing WAVs.

Raw PCM remains recoverable bit for bit. Results and native-clock metadata stay
in place. Does not touch serial, active blocks, old studies or user documents.
"""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
RUN=(ROOT/'artifacts/voice-ab-1000-v1').resolve()

def digest(data):return hashlib.sha256(data).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')

def main():
    p=argparse.ArgumentParser();p.add_argument('op',choices=['archive','restore','release'])
    p.add_argument('--block',type=int,required=True);a=p.parse_args()
    assert 0<=a.block<20
    block=(RUN/'formal'/f'block-{a.block:02d}').resolve()
    assert block.is_relative_to(RUN/'formal')
    events=[json.loads(s) for s in (block/'events.jsonl').read_text().splitlines()]
    assert events[-1]['kind']=='block_closed'
    assert len([s for s in events if s['kind']=='trial_end'])==50
    folder=RUN/'recording-archives';folder.mkdir(exist_ok=True)
    archive=folder/(block.name+'.zip');index=folder/(block.name+'.json')
    if a.op=='archive':
        assert not archive.exists() and not index.exists()
        files=sorted(block.glob('*/*.wav'));assert files
        manifest={f.relative_to(block).as_posix():dict(bytes=f.stat().st_size,sha256=digest(f.read_bytes())) for f in files}
        temporary=archive.with_suffix('.zip.partial')
        with zipfile.ZipFile(temporary,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
            for f in files:z.write(f,f.relative_to(block).as_posix())
        with zipfile.ZipFile(temporary) as z:
            assert set(z.namelist())==set(manifest)
            for name,item in manifest.items():
                value=z.read(name);assert len(value)==item['bytes'] and digest(value)==item['sha256']
        temporary.rename(archive)
        write(index,dict(block=block.name,zip_sha256=digest(archive.read_bytes()),files=manifest,
            method='ZIP DEFLATE level1, exact original WAV bytes verified after compression; metadata/result files unchanged'))
    info=json.loads(index.read_text());assert digest(archive.read_bytes())==info['zip_sha256']
    with zipfile.ZipFile(archive) as z:
        for name,item in info['files'].items():
            f=(block/name).resolve();assert f.is_relative_to(block) and f.suffix=='.wav'
            value=z.read(name);assert digest(value)==item['sha256'] and len(value)==item['bytes']
            if a.op=='restore':
                if f.exists():assert digest(f.read_bytes())==item['sha256']
                else:
                    with f.open('xb') as out:out.write(value)
                    assert digest(f.read_bytes())==item['sha256']
            elif f.exists():
                assert digest(f.read_bytes())==item['sha256']
                f.unlink()  # This exact WAV has a verified, byte-identical archive.
    print(json.dumps(dict(op=a.op,block=block.name,files=len(info['files']),
        original_bytes=sum(x['bytes'] for x in info['files'].values()),archive_bytes=archive.stat().st_size)))

if __name__=='__main__':main()
