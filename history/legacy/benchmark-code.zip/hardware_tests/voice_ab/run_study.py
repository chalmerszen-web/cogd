"""Run frozen software blocks, restoring the user's app and clip in finally."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
RUN=ROOT/'artifacts/voice-ab-1000-v1'
sys.path.insert(0,str(ROOT/'tools'))
from serial_link import connect
from hardware_m2 import Device

def read(p): return json.loads(p.read_text(encoding='utf8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value): p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')

def configure(path):
    with connect('COM5') as link:
        d=Device(link,path)
        for command in ('agent wake off','agent audio stop','agent mic off'):
            d.run(command)
        d.wait('wake status',lambda s:s['state']=='off',5)
        # Apply only volatile diagnostic settings. No test chat or provisioning.
        for command in ('agent audio volume 80','agent wifi modem 0','agent wake threshold 550','agent wake gain 1'):
            d.run(command)
        status=d.wait('status',lambda s:s['wifi'],30)
        wake=d.get('wake status');audio=d.get('audio status')
        assert status['wifi_power_save']=='none' and not status['busy']
        assert wake['threshold']==550 and wake['input_gain']==1
        assert audio['mic_adc_rate']==32000 and audio['volume']==80
        d.report.update(status=status,wake=wake,audio=audio,context=d.get('context stats'))
        d.save()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',type=Path,default=RUN/'frozen.json')
    p.add_argument('--start-block',type=int,default=0)
    p.add_argument('--stop-block',type=int,default=20)
    p.add_argument('--session',required=True)
    a=p.parse_args();plan=read(a.manifest)
    folder=RUN/a.session;folder.mkdir(exist_ok=False)
    idf=ROOT/'.toolchains/tools/python_env/idf6.1_py3.11_env/Scripts/python.exe'
    audio=ROOT/'.local/loopback-python/Scripts/python.exe'
    manager=ROOT/'hardware_tests/voice_ab/flash_manager.py'
    r=dict(started=time.time(),manifest=str(a.manifest),manifest_sha256=sha(a.manifest),blocks=[],complete=False)
    current=None
    def run(name,command):
        with (folder/(name+'.log')).open('xb') as log:
            code=subprocess.call(list(map(str,command)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        if code: raise RuntimeError(f'{name} exited {code}; see its preserved log')
    try:
        for index in range(a.start_block,a.stop_block):
            block=plan['blocks'][index];version=block['version'];image=plan['versions'][version]
            assert sha(ROOT/image['path'])==image['sha256']
            name=f'{a.session}-block-{index:02d}-{version}'
            if current!=version:
                run(name+'-switch',[idf,manager,'switch','--image',ROOT/image['path'],
                    '--sha256',image['sha256'],'--label',name])
                current=version
                time.sleep(2)
            configure(folder/f'configure-{index:02d}.json')
            entry=dict(index=index,version=version,started=time.time(),complete=False)
            r['blocks'].append(entry);save(folder/'progress.json',r)
            output=RUN/'formal'/f'block-{index:02d}'
            run(name+'-trials',[audio,'-X','utf8',ROOT/'tools/voice_ab_1000.py','--manifest',a.manifest,
                '--output',output,'--block',str(index)])
            entry.update(complete=True,finished=time.time());save(folder/'progress.json',r)
        r['complete']=True
    except BaseException as e:
        r['error']=repr(e);raise
    finally:
        r['finished']=time.time()
        # The child closes COM and audio handles before returning. Stop best
        # effort before putting the original app/clip back, even on failure.
        try:
            with connect('COM5') as link:
                d=Device(link,folder/'stop.json')
                for command in ('agent wake off','agent audio stop','agent mic off'):
                    d.run(command)
                d.wait('wake status',lambda s:s['state']=='off',5)
        except Exception as e:r['stop_error']=repr(e)
        try:
            run('restore',[idf,manager,'restore','--label',a.session+'-restore'])
            run('restore-readback',[idf,manager,'verify','--label',a.session+'-final-flash'])
            r['restored']=True
        except Exception as e:
            r['restore_error']=repr(e);r['restored']=False
        save(folder/'progress.json',r)
        print(json.dumps(r))

if __name__=='__main__': main()
