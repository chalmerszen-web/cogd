"""Measure cue bursts in raw headset recordings; does not claim human listening."""
import argparse
import hashlib
import json
from pathlib import Path
import wave
import numpy as np


def analyze(path):
    with wave.open(str(path), 'rb') as wav:
        assert wav.getsampwidth() == 2 and wav.getnchannels() == 1
        rate = wav.getframerate()
        pcm = np.frombuffer(wav.readframes(wav.getnframes()), dtype='<i2').astype(float)
    hop = rate // 100
    frames = pcm[:len(pcm)//hop*hop].reshape(-1, hop)
    rms = np.sqrt(np.mean(frames**2, axis=1))
    spectrum = abs(np.fft.rfft(frames*np.hanning(hop), 2048))**2
    frequency = np.fft.rfftfreq(2048, 1/rate)
    band = (frequency >= 300) & (frequency <= 2500)
    peaks = frequency[band][np.argmax(spectrum[:, band], axis=1)]
    floor = float(np.percentile(rms, 15))
    # The headset is beside the board's speaker; cues must rise clearly above
    # that recording's noise. No normalization or gain change is performed.
    loud = rms > max(100, floor*10)
    # Bridge one 10-ms dropout inside a cue, without merging separate sounds.
    loud[1:-1] |= loud[:-2] & loud[2:]
    edges = np.diff(np.r_[False, loud, False].astype(int))
    bursts = []
    for first, end in zip(np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)):
        duration = (end-first)*hop/rate
        if not .06 <= duration <= .35:
            continue
        f = peaks[first:end]
        t = np.arange(len(f))*hop/rate
        slope = float(np.polyfit(t, f, 1)[0])
        corr = float(np.corrcoef(t, f)[0, 1]) if np.std(f) else 0
        # Match the first 160 ms of the nominal 180-ms linear chirp. Preserve
        # the complete burst metrics: the board has a measured 20-30 ms tail
        # whose resonant frequencies are not the falling cue fundamental.
        sweep = f[:16]
        sweep_t = np.arange(len(sweep))*hop/rate
        fit = np.polyfit(sweep_t, sweep, 1)
        fit_error = float(np.sqrt(np.mean((sweep-np.polyval(fit, sweep_t))**2)))
        kind = 'unclassified'
        if abs(float(np.median(f))-1320) < 90 and np.std(f) < 120:
            kind = 'ding'
        elif len(sweep) == 16 and -9000 < fit[0] < -6500 and fit_error < 100 and np.mean(sweep[:2]) > 1500:
            kind = 'swoosh'
        bursts.append(dict(kind=kind, start_s=first*hop/rate, end_s=end*hop/rate,
                           duration_s=duration, median_hz=float(np.median(f)),
                           slope_hz_s=slope, frequency_time_correlation=corr,
                           sweep_fit_hz_s=float(fit[0]), sweep_fit_error_hz=fit_error,
                           sweep_window_s=len(sweep)*hop/rate,
                           peak_frame_rms=float(max(rms[first:end]))))
    return dict(source=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                sample_rate=rate, seconds=len(pcm)/rate, background_rms=floor,
                full_scale_samples=int(np.count_nonzero(abs(pcm) >= 32767)), bursts=bursts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = [analyze(path) for path in sorted(args.root.glob('*/external.wav'))]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding='utf8')
    for item in report:
        print(item['source'], [(b['kind'], round(b['start_s'], 2), round(b['duration_s'], 2)) for b in item['bursts']])


if __name__ == '__main__':
    main()
