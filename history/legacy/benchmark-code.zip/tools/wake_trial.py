"""Actual headset -> board microphone -> board cue/clip acoustic test.

The PC supplies prerecorded test speech; wake recognition and endpoint decisions
run on the device. External mic capture is bounded to each trial, local only.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
import wave
from hardware_m2 import Device
from serial_link import connect
from record_speaker import Recorder

def output(path,gain,trace=None,preroll_ms=0):
    command=[sys.executable,str(Path(__file__).with_name('wave_play.py')),str(path),'--gain',str(gain)]
    if trace: command.extend(['--trace',str(trace)])
    if preroll_ms: command.extend(['--preroll-ms',str(preroll_ms)])
    return subprocess.Popen(command,
                            creationflags=subprocess.CREATE_NO_WINDOW)

def export(d,path):
    n=d.get('audio status')['clip_ms']*16
    with wave.open(str(path),'wb') as wav:
        wav.setparams((1,2,16000,0,'NONE','not compressed'))
        for at in range(0,n,256):
            result=d.get(f'audio clip read {at} {min(256,n-at)}')
            assert result['offset']==at
            wav.writeframesraw(bytes.fromhex(result['pcm']))

def main():
    p=argparse.ArgumentParser(); p.add_argument('--voice',default='huihui')
    p.add_argument('--gain',type=float,default=.35); p.add_argument('--name',default='first')
    p.add_argument('--mode',choices=['speech','short','silence','pause','long','negative'],default='speech')
    p.add_argument('--negative',default='negative1')
    p.add_argument('--wake-fixture')
    p.add_argument('--utterance',help='Alternative local WAV fixture after the wake cue')
    args=p.parse_args(); root=Path('artifacts/wake')/args.name; root.mkdir(parents=True,exist_ok=True)
    fixtures=Path('artifacts/wake/fixtures'); process=None
    with connect('COM5') as link:
        link.timeout=.015
        d=Device(link,root/'report.json'); d.report['args']=vars(args); d.report['states']=[]
        try:
            d.run('agent wake off'); d.run('agent mic off')
            d.report['before']=d.get('status'); d.report['context']=d.get('context stats')
            before=d.get('wake status'); d.run('agent wake on')
            ready=d.wait('wake status',lambda s:s['state'] in ('listening','failed','off'),10)
            d.report['ready']=ready
            assert ready['state']=='listening',ready
            d.report['loaded']=d.get('status')
            with Recorder(root/'external.wav',25) as recording:
                time.sleep(.7)
                keyword=args.wake_fixture or ('hiesp-tts.wav' if ready['word']=='Hi ESP' else
                    f'{args.voice}-hilexin.wav' if ready['word']=='嗨乐鑫' else f'{args.voice}-wake.wav')
                source=fixtures/(f'{args.voice}-{args.negative}.wav' if args.mode=='negative' else keyword)
                d.report['wake_fixture']=str(source)
                process=output(source,args.gain,root/'keyword-output.json')
                began=time.monotonic(); spoken=False
                deadline=began+17
                while time.monotonic()<deadline:
                    state=d.get('wake status')
                    d.report['states'].append({'t':round(time.monotonic()-began,3),**state})
                    if state['state']=='recording' and not spoken:
                        if process.poll() is None: process.wait(timeout=4)
                        process=None; spoken=True
                        if args.mode not in ('silence','negative'):
                            utterance=args.mode
                            process=output(fixtures/(args.utterance or f'{args.voice}-{utterance}.wav'),args.gain,root/'speech-output.json')
                            d.report['speech_requested_t']=time.monotonic()-began
                    if state['state']=='cooldown' and state['wakes']>before['wakes']:
                        d.report['source_finished']=process is None or process.poll() is not None
                        break
                    if args.mode=='negative' and time.monotonic()-began>7: break
                    if state['state'] in ('failed','off'): break
                    time.sleep(.04)
                d.report['final_wake']=state; d.report['audio']=d.get('audio status')
                d.report['after']=d.get('status'); d.save(); time.sleep(.7)
            d.run('agent wake off'); d.wait('wake status',lambda s:s['state']=='off',3)
            # Keep the captured evidence even when the endpoint assertion fails.
            # Never export an unchanged clip as if it belonged to this trial.
            if state['completed']>before['completed'] and d.get('audio status')['clip_ready']:
                export(d,root/'device.wav')
            if args.mode=='negative':
                assert state['wakes']==before['wakes'],state
            elif args.mode=='silence':
                assert state['empty']==before['empty']+1 and state['completed']==before['completed'],state
            elif args.mode=='long':
                assert state['reason']==4 and state['samples']==160000 and state['completed']==before['completed']+1,state
            else:
                assert state['completed']==before['completed']+1 and state['error']=='ok' and state['reason']==2,state
                assert d.report.get('source_finished'), 'Endpoint cut off a still-playing speech fixture'
            assert d.report['audio']['mic_overruns']==0,d.report['audio']
            assert state.get('dma_lost',0)==before.get('dma_lost',0),state
            d.report['passed']=True
        finally:
            if process and process.poll() is None: process.terminate(); process.wait(timeout=5)
            try: d.run('agent wake off'); d.run('agent mic off')
            finally: d.save()
    print(json.dumps({k:d.report.get(k) for k in ('passed','ready','final_wake','after')},ensure_ascii=False))

if __name__=='__main__': main()
