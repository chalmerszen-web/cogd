"""Measure source-voice-to-cue delay on a single raw headset recording clock.

Use known local speech fixtures and independently matched completion cues.
Low-correlation, ambiguous and hard-bound cases remain explicit; this does not
claim recognition of arbitrary speech or replace subjective listening.
"""
import argparse
import hashlib
import json
from pathlib import Path
import wave
import numpy as np
from analyze_wake_cues import analyze


def envelope(path):
    with wave.open(str(path), 'rb') as w:
        assert w.getnchannels() == 1 and w.getsampwidth() == 2
        rate = w.getframerate()
        pcm = np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(float)
    assert rate % 100 == 0
    hop = rate//100
    frames = pcm[:len(pcm)//hop*hop].reshape(-1, hop)
    frames = frames - frames.mean(axis=1, keepdims=True)
    spectrum = abs(np.fft.rfft(frames*np.hanning(hop), 2048))**2
    hz = np.fft.rfftfreq(2048, 1/rate)
    energy = np.sqrt(spectrum[:, (hz >= 400) & (hz < 3500)].sum(axis=1))
    active = np.flatnonzero(abs(pcm) > 40)
    return energy, (float(active[-1])/rate if len(active) else None)


def align(reference, target, minimum, maximum):
    n = len(reference)
    if len(target) < n or np.std(reference) == 0:
        return None
    centered = reference-reference.mean()
    dot = np.correlate(target, centered, 'valid')
    sums = np.r_[0, np.cumsum(target)]
    squares = np.r_[0, np.cumsum(target*target)]
    variance = np.maximum(0, squares[n:]-squares[:-n]-(sums[n:]-sums[:-n])**2/n)
    score = dot/np.sqrt(np.maximum(variance*float(centered@centered), 1))
    lo = max(0, int(np.ceil(minimum*100)))
    hi = min(len(score)-1, int(np.floor(maximum*100)))
    if lo > hi:
        return None
    at = lo+int(np.argmax(score[lo:hi+1]))
    return dict(start_s=at*.01, correlation=float(score[at]), search_s=[lo*.01, hi*.01])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('root', type=Path)
    p.add_argument('--cues', type=Path, required=True)
    p.add_argument('--dings',type=Path,help='Independent start-cue matches, instead of the frequency burst detector')
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        p.error('Refusing to replace prior timing evidence')
    source_report = args.root/'report.json'
    run = json.loads(source_report.read_text(encoding='utf8'))
    cues = json.loads(args.cues.read_text(encoding='utf8'))
    matches = {Path(x['source']).resolve(): x for x in cues['results']}
    starts=None
    if args.dings:
        starts={Path(x['source']).resolve():x for x in json.loads(args.dings.read_text(encoding='utf8'))['results']}
    rows = []
    for index, case in enumerate(run['rounds'], 1):
        path = args.root/f'{index:03d}'/'external.wav'
        row = dict(round=index, mode=case['mode'], runtime_passed=case['passed'], measured=False)
        rows.append(row)
        if case['mode'] not in ('speech', 'pause', 'short', 'noise-speech'):
            row['reason'] = 'No ordinary speech endpoint expected'; continue
        cue = matches[path.resolve()]
        assert cue['sha256']==hashlib.sha256(path.read_bytes()).hexdigest(), 'Completion-cue capture mismatch'
        if len(cue['detections']) != 1:
            row['reason'] = 'No unique completion cue'; continue
        source = Path(run.get('fixture_dir','artifacts/wake/fixtures'))/case['utterance']
        reference, last_voice = envelope(source)
        target, _ = envelope(path)
        if starts is None:
            bursts = analyze(path)['bursts']
            dings = [b for b in bursts if b['kind'] == 'ding' and b['peak_frame_rms'] > 1000]
        else:
            start=starts[path.resolve()]
            assert start['sha256']==cue['sha256'] and not start['reference_self_match'], 'Start cue must match the same capture independently'
            dings=start['detections']
        if len(dings) != 1 or last_voice is None:
            row['reason'] = 'No unique start cue or voiced reference'; continue
        finish = cue['detections'][0]['start_s']
        # Search after the start cue and retain the full source, including its
        # trailing silence. Do not select a later incidental word to hide lag.
        found = align(reference, target, dings[0]['start_s']+.15, finish-len(reference)*.01)
        row.update(source=str(source), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                   capture_sha256=cue['sha256'], alignment=found, completion_cue_s=finish,
                   source_last_voiced_s=last_voice, device_reason=case['final']['reason'])
        if found is None:
            row['reason'] = 'Full source cannot be aligned before cue'; continue
        row['measured'] = found['correlation'] >= .75
        row['voice_to_cue_s'] = finish-found['start_s']-last_voice
        row['reason'] = 'Measured fixture timing' if row['measured'] else 'Weak alignment; timing is uncertain'
        # A diagnostic flag, not a replacement for the original runtime verdict.
        row['exceeds_two_seconds'] = row['measured'] and row['voice_to_cue_s'] > 2
    valid = [r['voice_to_cue_s'] for r in rows if r['measured']]
    report = dict(method='10-ms 400–3500-Hz envelope alignment; known source threshold |PCM| > 40; same raw capture clock for speech and cue',
                  run_sha256=hashlib.sha256(source_report.read_bytes()).hexdigest(),
                  cues_sha256=hashlib.sha256(args.cues.read_bytes()).hexdigest(),
                  start_cue_method='independent template' if starts is not None else 'frequency burst detector',
                  start_cues_sha256=hashlib.sha256(args.dings.read_bytes()).hexdigest() if args.dings else None,
                  summary=dict(cases=len(rows), measured=len(valid),
                               delay_min_s=min(valid) if valid else None,
                               delay_median_s=float(np.median(valid)) if valid else None,
                               delay_max_s=max(valid) if valid else None,
                               delayed_rounds=[r['round'] for r in rows if r.get('exceeds_two_seconds')]), results=rows)
    args.output.write_text(json.dumps(report, indent=2), encoding='utf8')
    print(json.dumps(report['summary'], indent=2))


if __name__ == '__main__':
    main()
