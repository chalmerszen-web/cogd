#include "voice.h"
#include <string.h>

/* RBJ biquads, 16 kHz, coefficients normalized by a0 and quantized to Q30.
 * 180-Hz high-pass, 100/200-Hz notches (Q=8), 3400-Hz low-pass.
 * Design equations: https://www.w3.org/TR/audio-eq-cookbook/ .
 * Q8 sample state reduces fixed-point limit cycles; all sums fit int64_t. */
static const int32_t coefficients[4][5]={
    {1021391994,-2042783987,1021391994,-2040230175,971595976},
    {1071113591,-2140575603,1071113591,-2140575603,1068485359},
    {1068502217,-2130416762,1068502217,-2130416762,1063262609},
    {243866057,487732114,243866057,-297066368,198788771}
};
void original_agent_voice_init(agent_voice_t *v) { memset(v,0,sizeof(*v)); }
static int32_t biquad_sample(agent_biquad_t *s,const int32_t *c,int32_t value)
{
    int64_t sum=(int64_t)c[0]*value+(int64_t)c[1]*s->x1+(int64_t)c[2]*s->x2-
        (int64_t)c[3]*s->y1-(int64_t)c[4]*s->y2;
    int64_t next=sum/INT64_C(1073741824);
    /* Four times PCM full scale permits transients without arithmetic overflow. */
    if(next>33554431) next=33554431;
    if(next< -33554432) next=-33554432;
    s->x2=s->x1; s->x1=value; s->y2=s->y1; s->y1=(int32_t)next;
    return (int32_t)next;
}
int16_t original_agent_voice_filter(agent_voice_t *v,int16_t input)
{
    int32_t value=(int32_t)input*256;
    for(unsigned i=0;i<4;++i) value=biquad_sample(&v->stage[i],coefficients[i],value);
    value/=256;
    return (int16_t)(value>32767?32767:value< -32768?-32768:value);
}
int16_t original_agent_voice_reject_cue(agent_biquad_t *state,int16_t input)
{
    /* 1320-Hz notch, Q=8, 16 kHz. Used only for VAD decisions: the raw clip
     * and keyword input retain every sample, including immediate speech. */
    static const int32_t c[5]={1041490845,-1809343540,1041490845,-1809343540,1009239866};
    int32_t value=biquad_sample(state,c,(int32_t)input*256)/256;
    return (int16_t)(value>32767?32767:value< -32768?-32768:value);
}
