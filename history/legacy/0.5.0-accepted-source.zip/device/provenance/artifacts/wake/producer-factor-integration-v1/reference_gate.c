#define agent_voice_init original_agent_voice_init
#define agent_voice_filter original_agent_voice_filter
#define agent_voice_reject_cue original_agent_voice_reject_cue
#include "gate.h"
#include "coefficients.h"
#include <string.h>
static int16_t notch(agent_biquad_t *s,const int32_t *c,int16_t pcm)
{
    int32_t value=(int32_t)pcm*256;
    int64_t sum=(int64_t)c[0]*value+(int64_t)c[1]*s->x1+(int64_t)c[2]*s->x2-
        (int64_t)c[3]*s->y1-(int64_t)c[4]*s->y2;
    int64_t next=sum/INT64_C(1073741824);
    if(next>33554431)next=33554431;
    if(next< -33554432)next=-33554432;
    s->x2=s->x1;s->x1=value;s->y2=s->y1;s->y1=(int32_t)next;
    int32_t out=(int32_t)next/256;
    return (int16_t)(out>32767?32767:out< -32768?-32768:out);
}
void post_tonal_gate_init(post_tonal_gate_t *p) {memset(p,0,sizeof(*p));}
bool post_tonal_gate_sample(post_tonal_gate_t *p,int16_t raw,unsigned *original,unsigned *clean)
{
    int32_t value=agent_voice_reject_cue(&p->cue,agent_voice_filter(&p->voice,raw));
    p->original_sum+=(unsigned)(value<0?-value:value);
    for(unsigned i=0;i<2;++i)value=notch(&p->tones[i],tone_coefficients[i],(int16_t)value);
    p->clean_sum+=(unsigned)(value<0?-value:value);
    if(++p->used<320)return false;
    *original=p->original_sum/320;*clean=p->clean_sum/320;
    p->original_sum=p->clean_sum=p->used=0;return true;
}
