#include "clip.h"
#include "clip_packed.h"
#include "crc.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

agent_err_t ref_agent_clip_open(agent_clip_t *,const agent_flash_ops_t *);
agent_err_t ref_agent_clip_begin_packed(agent_clip_t *,unsigned);
agent_err_t ref_agent_clip_write(agent_clip_t *,const int16_t *,size_t);
agent_err_t ref_agent_clip_finish_at(agent_clip_t *,size_t);
agent_err_t ref_agent_clip_read(agent_clip_t *,size_t,int16_t *,size_t);
agent_err_t ref_agent_clip_flush(agent_clip_t *);

enum { SIZE=0x70000 };
typedef struct {
    unsigned char data[SIZE];
    size_t reads,read_bytes,writes,write_bytes,erases;
    int read_budget,write_budget;
} flash_t;
static flash_t flash[2];
static unsigned char saved[SIZE];
static int16_t pcm[160000],decoded[257];
static agent_clip_t clip[2],snapshot;
static uint32_t rng=782311;
static unsigned valid_cases,corrupt_cases,read_cuts,write_cuts,replay_cases;
static size_t original_reads,candidate_reads;

static unsigned random32(void)
{ rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng; }
static agent_err_t rd(void *ctx,size_t at,void *out,size_t n)
{
    flash_t *f=ctx;assert(at<=SIZE && n<=SIZE-at);++f->reads;f->read_bytes+=n;
    if(f->read_budget==0)return AGENT_ERR_CANCELLED;
    if(f->read_budget>0)--f->read_budget;
    memcpy(out,f->data+at,n);return AGENT_OK;
}
static agent_err_t wr(void *ctx,size_t at,const void *in,size_t n)
{
    flash_t *f=ctx;assert(at<=SIZE && n<=SIZE-at);++f->writes;
    const unsigned char *p=in;
    for(size_t i=0;i<n;++i) {
        if(f->write_budget==0)return AGENT_ERR_STORAGE;
        if(f->write_budget>0)--f->write_budget;
        assert((f->data[at+i]&p[i])==p[i]);f->data[at+i]&=p[i];++f->write_bytes;
    }
    return AGENT_OK;
}
static agent_err_t erase(void *ctx,size_t at,size_t n)
{
    flash_t *f=ctx;assert(at%4096==0 && n==4096 && at<=SIZE-n);
    memset(f->data+at,255,n);++f->erases;return AGENT_OK;
}
static void clear_counts(flash_t *f)
{ f->reads=f->read_bytes=f->writes=f->write_bytes=f->erases=0;f->read_budget=f->write_budget=-1; }
static agent_err_t finish(unsigned i,size_t keep)
{ return i?agent_clip_finish_at(&clip[i],keep):ref_agent_clip_finish_at(&clip[i],keep); }
static void restore(void)
{
    for(unsigned i=0;i<2;++i) {
        memcpy(flash[i].data,saved,SIZE);clear_counts(&flash[i]);
        clip[i]=snapshot;clip[i].flash.ctx=&flash[i];
    }
}
static void start(size_t samples,unsigned schedule)
{
    flash_t *f=&flash[0];memset(f->data,255,SIZE);clear_counts(f);
    agent_flash_ops_t ops={rd,wr,erase,f,SIZE,4096};
    assert(ref_agent_clip_open(&clip[0],&ops)==AGENT_ERR_NOT_FOUND);
    assert(!ref_agent_clip_begin_packed(&clip[0],(unsigned)((samples+15)/16)));
    for(size_t at=0;at<samples;) {
        size_t n=schedule?1+random32()%256:128;if(n>samples-at)n=samples-at;
        assert(!ref_agent_clip_write(&clip[0],pcm+at,n));at+=n;
    }
    snapshot=clip[0];memcpy(saved,f->data,SIZE);restore();
}
static void equal_visible(agent_err_t a,agent_err_t b)
{
    assert(a==b && !memcmp(flash[0].data,flash[1].data,SIZE));
    assert(clip[0].samples==clip[1].samples && clip[0].written==clip[1].written);
    assert(clip[0].crc==clip[1].crc && clip[0].encoded_crc==clip[1].encoded_crc);
    assert(clip[0].ready==clip[1].ready && clip[0].writing==clip[1].writing);
    assert(clip[0].storage_bytes==clip[1].storage_bytes && clip[0].available==clip[1].available);
    assert(!memcmp(&clip[0].pack,&clip[1].pack,sizeof(clip[0].pack)));
    assert(flash[0].writes==flash[1].writes && flash[0].write_bytes==flash[1].write_bytes && flash[0].erases==flash[1].erases);
}
static void read_back(unsigned i,size_t keep)
{
    /* Commit leaves a different private cache cursor; all public seeks agree. */
    for(unsigned step=0;step<12;++step) {
        size_t at=step==0?keep:step==1?0:step==2?keep-1:random32()%(keep+1);
        size_t n=step==0?0:1+random32()%257;if(n>keep-at)n=keep-at;
        agent_err_t e=i?agent_clip_read(&clip[i],at,decoded,n):ref_agent_clip_read(&clip[i],at,decoded,n);
        assert(!e && !memcmp(decoded,pcm+at,n*2));
    }
    assert(agent_clip_read(&clip[i],keep,decoded,1)==AGENT_ERR_LIMIT);
    agent_clip_t reopened;assert(!agent_clip_open(&reopened,&clip[i].flash) && reopened.samples==keep);
    for(size_t at=0;at<keep;) {
        size_t n=keep-at;if(n>257)n=257;
        assert(!agent_clip_read(&reopened,at,decoded,n) && !memcmp(decoded,pcm+at,n*2));at+=n;
    }
}
static void valid(size_t keep)
{
    restore();agent_err_t a=finish(0,keep),b=finish(1,keep);equal_visible(a,b);assert(!a);
    assert(flash[1].reads<=flash[0].reads);
    original_reads+=flash[0].reads;candidate_reads+=flash[1].reads;
    read_back(0,keep);read_back(1,keep);++valid_cases;
}
static void make_pcm(unsigned mode,size_t n)
{
    int32_t value=0;
    for(size_t i=0;i<n;++i) {
        if(mode==0)value=0;
        else if(mode==1)value=(int16_t)random32();
        else if(mode==2)value=i%2?INT16_MAX:INT16_MIN;
        else {
            int radius=mode==3?3:mode==4?20:100;
            value+=((int)(random32()%(unsigned)(2*radius+1))-radius)*16;
            if(value< -30000 || value>30000)value=0;
        }
        pcm[i]=(int16_t)value;
    }
}
static void corrupt(void)
{
    for(unsigned mode=0;mode<2;++mode) {
        make_pcm(mode?1:3,3200);start(3200,0);
        assert(!ref_agent_clip_flush(&clip[0]));snapshot=clip[0];memcpy(saved,flash[0].data,SIZE);
        for(size_t byte=0;byte<snapshot.storage_bytes;++byte) {
            restore();flash[0].data[32+byte]^=1u<<(byte%8);flash[1].data[32+byte]^=1u<<(byte%8);
            agent_err_t a=finish(0,1937),b=finish(1,1937);equal_visible(a,b);
            assert(a==AGENT_ERR_CORRUPT && !clip[1].ready && !clip[1].writing && !flash[1].writes);++corrupt_cases;
        }
        for(unsigned state=0;state<4;++state) {
            restore();
            for(unsigned i=0;i<2;++i) {
                if(state==0)clip[i].crc^=1;
                if(state==1)clip[i].encoded_crc^=1;
                if(state==2)--clip[i].storage_bytes;
                if(state==3)++clip[i].storage_bytes;
            }
            agent_err_t a=finish(0,1937),b=finish(1,1937);equal_visible(a,b);assert(a==AGENT_ERR_CORRUPT);++corrupt_cases;
        }
    }
}
static void faults(void)
{
    make_pcm(1,3200);start(3200,1);size_t reads[2];
    for(unsigned i=0;i<2;++i) { assert(!finish(i,1937));reads[i]=flash[i].reads; }
    for(unsigned i=0;i<2;++i) {
        for(size_t cut=0;cut<reads[i];++cut) {
            restore();flash[i].read_budget=(int)cut;
            assert(finish(i,1937)==AGENT_ERR_CANCELLED && !clip[i].ready && !clip[i].writing);
            assert(clip[i].reader.sample==0 && clip[i].reader.offset==0);
            flash[i].read_budget=-1;agent_clip_t reboot;
            assert(agent_clip_open(&reboot,&clip[i].flash)==AGENT_ERR_NOT_FOUND);++read_cuts;
        }
    }
    /* Includes pending encoded data and every byte of the two header writes. */
    size_t programmed=snapshot.pack.used+32;
    for(size_t cut=0;cut<=programmed;++cut) {
        restore();flash[0].write_budget=flash[1].write_budget=(int)cut;
        agent_err_t a=finish(0,1937),b=finish(1,1937);equal_visible(a,b);
        assert(cut==programmed?!a:a==AGENT_ERR_STORAGE);
        for(unsigned i=0;i<2;++i) {
            agent_clip_t reboot;agent_err_t e=agent_clip_open(&reboot,&clip[i].flash);
            assert(cut==programmed?!e:(e==AGENT_ERR_NOT_FOUND || e==AGENT_ERR_CORRUPT));
        }
        ++write_cuts;
    }
    restore();agent_clip_abort(&clip[1]);assert(agent_clip_finish_at(&clip[1],1937)==AGENT_ERR_ARGUMENT);
    /* No magic full-only exception at equal samples and no out-of-range read. */
    for(size_t keep=0;keep<1600;keep+=127) { restore();equal_visible(finish(0,keep),finish(1,keep)); }
    restore();equal_visible(finish(0,3201),finish(1,3201));
    uint32_t full,prefix;
    assert(agent_packed_checksum_prefix(NULL,3200,1937,&full,&prefix)==AGENT_ERR_ARGUMENT);
    assert(agent_packed_checksum_prefix(&clip[1],3200,0,&full,&prefix)==AGENT_ERR_ARGUMENT);
    assert(agent_packed_checksum_prefix(&clip[1],3200,3201,&full,&prefix)==AGENT_ERR_ARGUMENT);
}
int main(int argc,char **argv)
{
    const size_t totals[]={1600,1601,1937,3200,65537,160000};
    if(argc==1) {
        for(unsigned mode=0;mode<6;++mode)for(unsigned schedule=0;schedule<2;++schedule)
            for(unsigned t=0;t<sizeof(totals)/sizeof(*totals);++t) {
                size_t n=totals[t];make_pcm(mode,n);start(n,schedule);
                const size_t keeps[]={1600,1601,1663,1664,1665,1791,1792,1793,1937,n/2,n-1,n};
                for(unsigned k=0;k<sizeof(keeps)/sizeof(*keeps);++k) {
                    size_t keep=keeps[k];if(keep<1600 || keep>n)continue;
                    bool seen=false;for(unsigned j=0;j<k;++j)if(keeps[j]==keep)seen=true;
                    if(!seen)valid(keep);
                }
            }
        corrupt();faults();
    } else {
        assert(argc==4);FILE *f=fopen(argv[1],"rb");assert(f);
        size_t n=fread(pcm,sizeof(*pcm),160000,f);assert(n>=1600 && fgetc(f)==EOF);assert(!fclose(f));
        size_t keep=(size_t)strtoul(argv[2],NULL,10);assert(keep>=1600 && keep<=n);
        start(n,1);valid(keep);
        f=fopen(argv[3],"wb");assert(f && fwrite(flash[1].data,1,SIZE,f)==SIZE && !fclose(f));++replay_cases;
    }
    printf("{\"passed\":true,\"valid_cases\":%u,\"corruption_cases\":%u,\"read_cancel_sites\":%u,\"write_power_cut_sites\":%u,\"actual_clip_replays\":%u,\"reference_finish_reads\":%zu,\"candidate_finish_reads\":%zu,\"clip_struct_bytes\":%zu}\n",valid_cases,corrupt_cases,read_cuts,write_cuts,replay_cases,original_reads,candidate_reads,sizeof(agent_clip_t));
    return 0;
}
