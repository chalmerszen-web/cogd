#include "tonal.h"
#include "coefficients.h"
static int16_t notch(agent_biquad_t *s,const int32_t *c,int16_t pcm)
{
    int32_t value=(int32_t)pcm*256;
    int64_t sum=(int64_t)c[0]*value+(int64_t)c[1]*s->x1+(int64_t)c[2]*s->x2-
        (int64_t)c[3]*s->y1-(int64_t)c[4]*s->y2;
    int64_t next=sum/INT64_C(1073741824);
    if(next>33554431)next=33554431;
    if(next< -33554432)next=-33554432;
    s->x2=s->x1;s->x1=value;s->y2=s->y1;s->y1=(int32_t)next;
    int32_t out=(int32_t)next/256;
    return (int16_t)(out>32767?32767:out< -32768?-32768:out);
}
int16_t tonal_filter_sample(tonal_filter_t *s,int16_t value)
{
    for(unsigned i=0;i<2;++i)value=notch(&s->tones[i],tone_coefficients[i],value);
    return value;
}
