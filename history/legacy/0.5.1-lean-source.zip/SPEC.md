# ESP-Hi Agent M0 Specification

## 新增同设备对照实验（2026-09-15）

用户要求烧录官方原始算法基线和三天调优版本，完成总计 1000 次实验。
执行 [VOICE_AB_1000_SPEC.md](docs/VOICE_AB_1000_SPEC.md)：500 配对、冻结软件和输入、
保留全部误判，比较唤醒/端点/资源，结束恢复 lean。此项覆盖此前停止重复验收的
限制，但不授权重启训练或改写原失败数据。

状态：2026-09-15 已完成 1000 个完整项（500 配对），另 2 次电脑采集失败单列。
结果与限制见 [VOICE_AB_1000_REPORT.md](docs/VOICE_AB_1000_REPORT.md)。证据全量校验通过；
已恢复 0.5.1-lean，完整 Flash 与实验前相同。此次结束，不新增训练或重复验收。

## 当前工作范围：Agent 精简版（2026-09-15 用户修订）

用户要求结束语音模型的严格研究验收，优先跑通 Agent 业务并开放 GPIO。
以下 LEAN 要求覆盖此前要求继续训练或循环语音验收的安排；历史实验结果保留。

- LEAN-01：语音作为实验功能交付，沿用官方 WakeNet9s 与 ESP-SR WebRTC VAD。
  默认关闭额外关键词/神经 VAD 校验器，不再训练。只有同输入、同采集条件的
  配对结果才可量化“超过官方”；现有资料不足时明确写未证明，不虚构改善比例。
- LEAN-02：复用已有请求缓冲接收 SSE；嵌套乐谱直接解析 JSON 节点，删除重复
  序列化和 2 KiB 临时数组。输入、回答、上下文预算和分区布局保持。
- LEAN-03：增加 device.gpio.get/set（DeepSeek 下划线名称），支持读输入、
  持续输出、10–5000 Hz PWM（两路，千分比占空比）；与现有有界控制计划互通。
  开放未启用的 LCD GPIO4/5/10 和身体接口 GPIO20/21；按钮 GPIO0/1/9 只读。
  这些引脚有原板用途，不能称为空闲无连接。USB、Flash、未知 GPIO11 和已运行的
  灯/音频外设继续由驱动管理。模型先查询能力，再提交参数；不执行生成的 C 代码。
- LEAN-04：直接输出保持到显式更改或重启；控制计划执行后/取消时恢复先前状态。
  计划活动期间直接 GPIO 操作返回 busy；引脚租约和入口锁协调访问。
- LEAN-05：保存修改前源码与完整 Flash；只烧录应用。主机验证解析/权限/冲突/
  恢复、流式缓冲和音频关闭构建；实机验证读写/PWM、取消、DeepSeek 流式和非流式
  工具闭环及内存。有限回归后收尾，不重跑无变化的百轮语音实验。
- LEAN-06：报告当前固件、存储/堆变化及实验限制；不减少 2 MiB 上下文分区或
  128 KiB 历史请求预算，不将本次收尾写成 M0 外网同步/真实断电验收完成。

交付记录见 [AGENT_LEAN_REPORT.md](docs/AGENT_LEAN_REPORT.md)。0.5.1-lean 已安装，
精简/GPIO实现与本地主机/实机检查完成；语音按实验入口收尾。真实DeepSeek流式
状态工具和非流式GPIO计划均有成功闭环，流式多步GPIO另有后续超时失败，保留限制，
不宣称所有云调用或原M4稳定性指标通过。下文为历史阶段记录。

2026-09-14 M4 single-pass tonal metadata candidate is staged under
`artifacts/wake/tonal-metadata-v1/`; requirements and frozen checks are in
[TONAL_METADATA_STUDY.md](docs/TONAL_METADATA_STUDY.md). It must reproduce the
previous post-confirmation veto exactly while preserving original first model
confirmation/raw history. The added 1,000 B metadata comes from the existing
engine lease, not context. Host980 schedules and actual8 runtime checks pass,
but two acoustic endpoints remain late (2.844/2.407s); M4 is not accepted.
The separate exact FFT identity candidate passes24 chip comparisons/6188frames
and reduces isolated whole-frame time1.1555%, still22.9165ms per16ms input.
See [FFT_IDENTITY_STUDY.md](docs/FFT_IDENTITY_STUDY.md). Both experiments restore
full original4MiB99fb and retain original firmware/context; no100 acoustic retry.

Current M4 candidate, installed firmware and remaining acceptance items:
[M4 current state](docs/M4_CURRENT_STATE.md). Historical experiments below retain
their original outcomes; they are not all descriptions of the installed image.

M4 wake-word/VAD recording work is in progress under `docs/WAKE_VAD_SPEC.md`. The extension preserves existing context capacity and partition layout; it does not change prior acceptance statuses.

The activity-weighted candidate7f17e60d... passes20 short/empty cycles but falsely
wakes on3/24 near-word sentences. It is rejected and the verified unweighted
ef92 application is restored, with context/layout preserved. The new option
remains default-off for further diagnostics. M4 is not complete.

Five host-only keyword candidates remain rejected. The latest temporal model
accepts48/72 fitted synthetic validation positives, but20/43 retained positives
with one false acceptance among29 negatives, and2/10 keywords from another
synthetic source family. No learned weights or detector are installed. The
normal ef92 application remains unchanged; full identities and prior failures
are retained in `docs/WAKE_VAD_REPORT.md`.

The subsequent causal VAD student experiment is also host-only. Teacher scores
are diagnostic soft targets, not human speech/quiet labels. It must pass retained
short-word/quiet regression, quantized numerical checks and actual C3 resources
before any integration. Physical corpus collection replaces only the authorized
diagnostic clip, preserving application, NVS, context capacity and prior M0/M3
acceptance states. M4 remains unaccepted.

The controlled raw-logmel/PCAN VAD comparison also fails retained short-word and
known-quiet regression; both new students are rejected. A default-off
`AGENT_CAPTURE_WARM_PDM` build may collect bounded manual diagnostic clips under
the microphone warmup and post-cue output conditions used by wake recording.
Its profile identity, cancellation, PC recorder shutdown and full app rollback
must be verified independently. This capture mode is not a new user workflow
or evidence that keyword/VAD acceptance has passed.
Subsequent adaptation using the verified acquisition and ambient captures keeps
15/15 retained short controls but still accepts all four known quiet failures.
It is also rejected; no learned VAD replacement is installed.

A separately documented development-noise protocol now reclassifies two older
modem-sleep failures as fitting data and keeps two later quiet failures out of
fitting/selection. Fitted-case scores cannot count as acceptance. Two further
models, including one with a verified12-source physical noise corpus, still
accept both unfitted quiet failures and are rejected. The existing source-voice
split and requirement for fresh complete-cycle/C3 verification remain intact.

The separate TEN sparse-band/LPC experiment preserves all44 retained numerical
inputs and the original32 causal decision traces. Constant-weight caching is
bit-exact; omitting a complete DCT/inverse-DCT roundtrip produces only bounded
observed differences and preserves the15 control/four quiet diagnostic decisions.
On C3 the latter improves maximum frame time from44939 to41082us, still above
the16000us period. It remains an isolated rejected integration candidate. The
original whole application partition is restored and all4MiB are verified equal.

The optional neural VAD and keyword-feature checks remain experimental. The
retained32-kHz acquisition checkpoint passes its bounded100-cycle resource run,
while keyword accuracy and complete-cycle acceptance remain open. Current
image identities, failures and rollback evidence are in the M4 report.

Status: IMPLEMENTED; HARDWARE ACCEPTANCE BLOCKED. Source: `deep-research-report.md`, user-approved plan, 2026-09-10. M0 is not marked complete: the user currently cannot change the network or unplug USB for the two remaining hardware prerequisites.

## Requirements

| ID | Requirement | Acceptance |
|---|---|---|
| M0-01 | Project-owned firmware is C11; portable core, static versioned plugins | Host build, ESP32-C3 build, source audit |
| M0-02 | Head only, native USB on GPIO18/19, GPIO8 / four WS2812 | USB console and physical LED test; no body/audio/LCD drivers |
| M0-03 | Provision Wi-Fi and secrets over USB; local input echo requested by user, no device echo or source/log disclosure | Provisioning test, NVS restart, log scan |
| M0-04 | Verified HTTPS to deepseek-flash; explicit thinking disabled; stream and non-stream | Two real API calls and negative certificate test |
| M0-05 | Four allowlisted tools; full JSON/range validation; continuation preserves call IDs | Host policy tests and real natural-language LED call |
| M0-06 | Bounded, incremental SSE and JSON processing | Fragmentation, malformed input, cancellation, size-limit tests |
| M0-07 | Framed CRC WAL, two-bank transactional compaction, stable event IDs | Fault injection, reboot and actual power-loss recovery |
| M0-08 | LOCAL / CLOUD / HYBRID (default), idempotent sync, Lamport LWW, tombstones | C and mock Gateway integration tests |
| M0-09 | DIRECT (default) and GATEWAY, versioned protocol and deterministic mock | Four HTTPS endpoints and tool continuation |
| M0-10 | Responsive local console, bounded network retry/backoff/circuit breaker | Timeout/disconnect tests without watchdog reset |
| M0-11 | Resource telemetry and 100-turn soak | size reports; free/minimum/largest heap and stack watermarks |
| M0-12 | Reproducible build, documentation, evidence and action log | Final reports distinguish PASS / FAIL / NOT RUN |

## Contract and budgets

- One active turn; a portable event/state core and one network worker. Background sync yields to turns.
- Input <= 2048 bytes; HTTP request <= 24576; SSE event <= 6144; tool arguments combined <= 4096; answer <= 8192.
- At most four tools per response and four tool-execution rounds. All arguments are validated before any tool in a response executes.
- Internal tools: `device.status.get`, `device.light.get`, `device.light.set_rgb`, `agent.context.stats`. Wire names replace dots with underscores through an explicit lookup table.
- `agent_err_t` normalizes configuration, busy/cancelled, size/JSON/protocol, network/TLS/auth/rate/server, storage-full/corruption and timeout failures.
- USB commands cover status, Wi-Fi configuration/status, chat (optional non-stream), cancel, light, context mode/stats/sync, route and provisioning. Plain lines mean chat.
- Context event schema `agent.context.event/1`: event_id, device_id, user_id, session_id, device_seq, lamport, type, actor, content, policy, parents.
- LOCAL never syncs; HYBRID keeps bounded history plus durable pending events; CLOUD keeps retry data/cursors and bounded RAM history. Missing Gateway configuration is visible and does not discard pending data.
- Context storage uses a raw 1 MiB partition, two generation-tagged banks, committed frame CRCs and copy-before-commit compaction. Never erase the current bank before its replacement commits. Tail damage recovers; internal damage reports corruption.
- Sequence allocation must survive interrupted appends and compaction. Sync ACK and pull cursor advance only after the corresponding durable state is committed.
- Secrets are development NVS data, never LLM-visible context. No insecure TLS, global Python changes, full-chip erase, security eFuse writes, or automatic production deployment.

## Delivery and defaults

Firmware at repository root. ESP-IDF pinned to v6.1 in project-private toolchains; host tests use existing Ubuntu GCC/CMake. Reference BSP pinned under ignored `_ref/`.

Implement phases A environment/reference; B USB; C kernel; D Wi-Fi; E non-stream; F stream; G tools; H WAL; I sync/mock; J fault/soak. Build and record evidence after each stage.

`ACTIONLOG.md` is append-only. Required reports live under `docs/`; generated raw logs, flash backups, test credentials and certificates live in ignored local directories.

Physical board revision and actual LED observations require separate evidence from firmware definitions. Actual USB power removal is not interchangeable with a software reset. M0 remains incomplete until every required real-hardware acceptance has passed.

## Acceptance snapshot — 2026-09-10

- M0-01–06, M0-11–12: implemented and passed the recorded host/device checks. All 14 owned firmware C units have effective `-std=c11`; final firmware is flashed on COM5. Password and Key entry remains visible by default as requested.
- M0-07: host torn-write/compaction injection and actual Flash compaction/software-reboot recovery passed. Physical USB power-loss recovery is blocked by the user's current inability to unplug.
- M0-08–09: host context/sync and verified mock HTTPS tests passed; all three device modes passed. Actual device Gateway conversation and hybrid sync require mutually reachable device/PC networks, currently unavailable.
- M0-10: hardware DNS, invalid TLS, cancel, input limits and radio disconnection/recovery passed. The mock-dependent device HTTP/status/stream fault matrix remains blocked by the same network prerequisite.
- Final device defaults are DIRECT + HYBRID, with the temporary unreachable Gateway URL cleared. All 1032 pending test events remain durable. See `docs/TEST_REPORT.md` for exact evidence and `docs/BUILD_REPORT.md` for resource sizes.

## M1 audio extension

The user's subsequent request enables the existing speaker and microphone and asks for LLM-designed music. This supersedes the M0 audio exclusion for the new extension only. M0 acceptance evidence and its two external blockers remain unchanged. The user selected device-synthesized short melodies with microphone on/off/level measurement. Firmware 0.2.0 is implemented and flashed; separate requirements and measured audio validation are in `docs/AUDIO_SPEC.md` and `docs/TEST_REPORT.md`.

## M2 control and context assessment

The user authorized implementation of the complete M2 assessment. Status: IMPLEMENTED AND VALIDATED on COM5, firmware 0.3.0-dev. The scope includes longer model-visible context, recall and summaries, GPIO ownership and action chains, recording/replay, storage migration and their acceptance tests. `docs/CONTROL_CONTEXT_SPEC.md` contains the completed checklist and TEST_REPORT links independent M2 host/device evidence, including 100/100 real concurrent turns. This does not close the previously documented external M0 Gateway/power-cut blockers. M2 uses plugin ABI major 2; older ABI 1 plugins are rejected.

M2 supersedes the M0-sized history/request/tool limits for the extension: up to 128 Flash turn descriptors; 64 KiB default / 128 KiB selectable history; measured, streamed DIRECT requests up to 160 KiB in at most 4096-byte writes. The 24 KiB single-record/scratch, 2 KiB dialogue input, 6 KiB SSE, 4 KiB tool arguments and 8 KiB answer limits remain. There are 19 registered tools with audio and 12 without, independent of the four-calls/four-continuations limit.

Current Flash is app 1.5 MiB, ctx 2 MiB (two 1 MiB banks), clip 448 KiB; NVS/PHY/USB are preserved. Migration has passed full-image readback and real boot with every prior pending event retained. Plans have at most 32 steps, eight repeats and a 60-second deadline, with all-or-nothing resource claims and restoration. Clip capture is 0.1–10 seconds, local-only, verified and committed before replay. Human acoustic quality is separate: after changing to PDM DAC defaults at volume 80, the user confirmed clear voice and reduced hiss on the same recording. Noise elimination is not claimed.

The final 100-turn run transmitted up to 65519/131019 history bytes and a 144781-byte request. Minimum measured heap was 49400 bytes; 67 post-warmup concurrent samples had a +40-byte first/last median change and +0.284 bytes/turn slope. Failed pilots remain in the evidence. Explicitly user-approved archival moved only known completed filler test pairs into private host backups; normal retention still preserves pending records. Final configuration is DIRECT + LOCAL, 128 KiB budget, 1190 retained/pending events, 519768 active-bank bytes and the original five-second clip; speaker/mic/plans are idle.

## M3 expressive one-minute music

Status: IMPLEMENTED AND OBJECTIVELY VALIDATED, firmware 0.4.0-dev; subjective music acceptance remains PENDING. User approved the complete M3 plan on 2026-09-11, including autonomous COM5/miniterm release, local headset-microphone recording and real DeepSeek tests. Four bounded voices and roughly one minute of music are implemented; 15 enabled / 10 disabled host suites, acoustic calibration, multiple real candidates, three final full plays, physical image readback and M2 app-only rollback pass. The 100 validated real concurrent turns used two documented segments after a host observer timeout; minimum heap is 49968 bytes and render maximum 1689 us. Legacy scores, control deadlines, context capacity and Flash layout are preserved. Requirements and detailed evidence are in `docs/MUSIC_SPEC.md` and `docs/MUSIC_REPORT.md`. Existing M0 external blockers remain open.

## M4 local wake word and VAD recording

Status: IN PROGRESS, firmware 0.5.0-dev, plugin ABI 4. User requested autonomous headset-based testing of a real wake word, one start ding, immediate local recording and one completion swoosh after speech ends. No transcription or audio upload is part of this stage. Requirements M4-01–08 are in `docs/WAKE_VAD_SPEC.md`; current evidence and retained failures are in `docs/WAKE_VAD_REPORT.md`.

The provisional Chinese wake word is 嗨乐鑫, using the pinned C3 WakeNet9s model. USB commands enable/disable/query listening; listening is off after reboot. Microphone frames and endpoint timing run on the board, independently of the test PC. The single clip remains bounded to 10 seconds and verified before the finish cue. Existing context partition/history budget and all previous pending events remain retained. Keyword near-word confusion, missed acoustic fixtures, noisy endpoint behavior and final continuous-operation acceptance remain open. Successful partial suites must not be presented as completed M4 acceptance.

The September 12 candidate adds default-off `AGENT_VOICE_VERIFY`, an independent
weak speech-presence check which cannot commit unconfirmed noise or extend the
four-second waiting deadline. It prepares before the ding and releases its
11364-byte frontend allocation before rearming WakeNet. Fixed model state is
1464 bytes; live 20-ms input processing has measured at most about 4.1 ms.
Default audio builds now select Wi-Fi power-save NONE at startup after repeated
associated noise comparisons; the actual setting is visible in status. Higher
idle-power use remains unmeasured. The tested candidate, isolated numerical
checks and retained failures are recorded in
`docs/WAKE_VAD_REPORT.md`. No new M0 or M3 acceptance is implied.

The earlier user-confirmed quiet run on image `4c3ef308...` completes 19/20 runtime
cases: all twenty keyword accepts and ten short clips, but one unwanted
5.08-second recording. Only seven short-case completion delays are measurable
(0.998–1.144 seconds); three PC loopback captures report discontinuities and
remain unmeasured. Minimum heap is 49400 bytes, just 248 bytes above the 48-KiB
floor; sixteen comparable rearmed readings are exactly 58328 bytes. Context
capacity and contents are unchanged. This run improves the observed counts but
does not satisfy the quiet-condition or complete M4 acceptance criteria.

The current `ce19f67a...` experiment retains a five-of-eight onset candidate for
at most 320 ms while awaiting strong neural confirmation; it needs 120 ms total
activity and preserves all endpoint deadlines. A 32-input exact C3 comparison
retains all 15 positive controls and fixes one rejected short command without
newly accepting a previously rejected negative. Fresh repeated short-command
testing is still only 5/6, with one weaker response rejected. No fresh quiet
acceptance or current-image long-run completion is claimed. Two real DeepSeek
paths and music/replay/light coexistence pass, with 52936-byte minimum heap.
Physical readback verifies the current app, unchanged layout and every prior
record; normal connection tests add four events, leaving 1522 / 980360 bytes.
Context remains two 1-MiB banks and a 128-KiB model-visible history budget.

The external test microphone now has a verified native 48-kHz WASAPI RAW path,
with per-stream effect and packet metadata. This changes the measurement path,
not the `ce19f67a...` device image. The fresh immediate suite is 4/4; the boundary
suite is 5/8, retaining two unintended recordings and one missed keyword. These
runs have no newly confirmed quiet window. A separate recording cancellation
completes in 141 ms. A periodicity diagnostic overlaps false recordings and weak
short words, so no additional detector gate is adopted. M4 remains in progress;
source identification of the retained quiet failure and final acoustic/stability
acceptance remain outstanding. The device is left with listening/microphone off.

At 2026-09-12 06:02 +08:00, acoustic tuning paused for sound identification.
The user subsequently reported no audible human speech in the presented quiet
015 excerpt. Work resumes with that bounded human observation recorded against
the exact file hash; it does not label other recordings or grant a new quiet
window. Missed-keyword, false-recording, timing and longer-run requirements remain.

The user subsequently directs unattended debugging while sleeping and explicitly
requests no further questions. Continue bounded local recording, known-source
playback and measurement autonomously; report measured room conditions and
uncertainty instead of requiring another human quiet-window reply. Retained
human observations keep their original file/time scope. No remote audio upload
or subjective listening claim is introduced.

An isolated TEN VAD experiment distinguishes the retained quiet015 failure
from 15 exact-trace positive controls when combined with existing activity votes.
It is not in the Agent build. C11 float/quantized inference, reduced frontend
storage and a precomputed LPC transform are compared with upstream references.
Initial chip profiling is too slow for real-time audio; numerical agreement
alone must not promote it to the normal recording path. Context size and the
existing Agent remain the rollback boundary.

The 2026-09-12 fixed-DSP follow-up completes six identical chip inputs and100
allocation cycles, reducing maximum frame cost to49.834 ms at observed160 MHz.
It still fails the16-ms live budget and remains excluded from the Agent. Removing
pitch creates a retained quiet-case regression, so that shortcut is not adopted.
Full physical readback after restoration is byte-identical to the pre-diagnostic
backup, including every context and clip byte. Autonomous work continues without
questions; M4 and earlier external acceptance gaps are not marked complete.

The unattended follow-up at 2026-09-12 08:32 +08:00 completes 20 acoustic
cycles on the unchanged ce19 Agent. All 20 keywords and 10 short commands
succeed, but one of 10 trials without a command produces an unwanted clip:
overall 19/20. Independent recordings contain 20 dings and 11 swooshes,
including the erroneous completion. Ten measured end delays are 1.000–1.799 s.
Minimum heap is 54736 bytes, steady rearmed heap is constant, and context is
unchanged. Conditions are unattended/measured, not a new human quiet label.

Detector-input filters do not solve the retained quiet failure; combining the
speech band and cue notch also loses one known short control. Pinned vendor NS
likewise fails that noise case and takes 87.410 ms per 20-ms diagnostic frame.
Neither is adopted. TEN row staging is also slower and stays disabled. Full
readback after restoring ce19 matches the backup immediately before the NS
probe, including the new replaceable test clip. M4 remains active/unaccepted.

A default-off `AGENT_MIC_OVERSAMPLE` calibration now tests 32-kHz ADC input
followed by a fixed C11 anti-alias filter and 2:1 decimation. Wake/VAD/clip data
remain 16-kHz PCM. The 63-tap filter uses 140 bytes of state, no allocation or
floating point, and adds 0.969 ms group delay. The latest trial returns its
ADC pool to8 KiB; measured scheduling margin still requires verification. The input
rate is visible in audio status. Initial 48-kHz and 32-kHz/100-Hz scheduler
trials lost DMA samples and were rejected before detector-quality acceptance.
An isolated sdkconfig now tests a 1000-Hz scheduler; the root configuration
remains unchanged, and enabling oversampling with its100-Hz setting is rejected
at configure time. Pre-cue model initialization pauses the ADC, and bounded
reads preserve the original 64-ms delivered-audio budget after decimation.
Host response/bounds checks precede acoustic comparison; this candidate is not
accepted until false recording, weak speech, DMA/heap and concurrency checks pass.

The first1000-Hz/10-KiB-pool image passes20 cue cases and8 endpoint/cancel cases,
but still falsely wakes on a near-word and later reaches47152 bytes minimum heap,
below the48-KiB target. Its threshold650 trial also misses a normal keyword.
It is not adopted. The next candidate reduces the ADC pool by2 KiB and network
stack by1 KiB (previous long-context TLS evidence retains3596 bytes at16 KiB),
adds a separate maximum interval between successful ADC reads, and must repeat
resource and acoustic checks. Context capacity and history settings are unchanged.

The compact candidate `cc9a8ae9...` now completes100 mixed acoustic cases with
DMA0,53396-byte minimum heap and no sustained heap decline; two real DeepSeek
paths also pass with2484 bytes remaining network stack. Recognition still fails
19 near-word cases and one genuine wake (80/100 overall), so M4 is not accepted.
The temporary575 threshold is restored to550. Full readback verifies all original
history/configuration and the four authorized diagnostic events appended by chat.
An offline, three-held-out-trace keyword-feature feasibility check is promising
but adds no firmware classifier and provides no deployment/acceptance evidence.

The separate `hardware_tests/keyword_gate` C11 prototype now passes sanitizer
bounds tests and seven-case numeric comparison. Four clean traces generate the
templates; three ADC traces are held out. v2 corrects the probe's zero-based
first-hit index so its window includes the actual hit frame. The normal Agent
remains unchanged while isolated chip timing and live-quality checks are pending.
No recognition/generalization claim follows from those three correct samples.

`AGENT_KEYWORD_VERIFY` is a default-off Hilexin-only integration for diagnosis.
It preserves raw/veto/invalid/incomplete counters and uses atomic USB telemetry.
It allocates no inference-time heap and resets its bounded window on disarm.
The first full-Agent candidate `810a2306...` passes measured time/memory checks
but falsely rejects correct recorded/paused speech. It must not become the
default or be described as an accepted fix. No context or endpoint budget changes.

Across46 live gate trials,32 positive inputs produce26 raw model detections but
only14 accepted wakes; all14 negative cases are rejected. Temporary gain2/4 does
not repair the false-rejection problem. Further frozen-template checks retain
a false accept. Yaoyao shares Kangkang's actual voice resource on this host;
these captures do not establish performance on an independent speaker. The
gate remains disabled at this checkpoint. Restore cc9 and
verify the full original app partition plus unchanged context/configuration;
the18 authorized local corpus captures replace only the single test clip.

The later ADC-calibrated bank `keyword-q12-adc7-v1` uses seven templates totaling
11648 Flash bytes and1672 bytes of state. Paired scoring preserves exact host/chip
distances, with no inference allocation. Bank identity is included in status and
required by its tests. Fresh screen6/6 and examined variants12/12 improve on v2, but
both550/500 prosody runs remain9/12 and a new sentence challenge16/18 retains two
false wakes. A single distance cap would also reject five observed true calls,
so it is not implemented. Keep the gate default-off and M4 unaccepted.

The ADC7 comparison image `1c84431f...` is1282128 bytes and reduces starting
ding amplitude threefold. In six paired fixed-buffer trials, measured start-cue
and pre-speech1320-Hz residue medians fall8.68/8.56dB. Cue-to-input timing is
measured independently: successful recording alone is not first-phoneme evidence.
Twenty cue/short-word cases and eight endpoint/cancel cases pass; two real
DeepSeek paths, legacy music and replay also pass. Loaded minimum52084 and
network-stack margin2480 meet the existing limits. Four authorized chat events
raise context to1530 events/984344 active-bank bytes; history131072 and the
2-MiB raw partition are unchanged. Physical verification and remaining keyword
failures are recorded in the M4 report, independently of M0/M3 acceptance.

Fixture identity must include the actual local voice resource and source-audio
hash, not just its display name. Duplicate resources cannot be counted as
independent speakers; repeat acoustic takes remain useful continuity tests.
Previously named `heldout` directories stay intact as historical evidence, but
their misleading speaker labels are superseded by the September12 provenance
audit in the wake report. New generators enforce this distinction.

The ADC8 diagnostic candidate `ef92f238...` is1283808 bytes, with eight templates
totaling13312 Flash bytes and unchanged1672-byte state. Its100-case continuous run is98/100:
twenty near-word negatives and twenty no-command cases pass, but two genuine
calls are vetoed. All53 completed ordinary endpoints measure0.985–1.116s;
minimum heap50280 and95 constant rearmed-heap measurements meet the resource
targets. Additional24 sentence negatives pass; the paused-Huihui prosody cases
still fail. These results improve the earlier80/100, without completing M4.
Context is1534 events/986336 bytes after two authorized real chat checks;
the2-MiB partition and131072-byte history budget are unchanged.

Experimental VAD optimizations remain separate from the normal application.
Verify numerical behavior, retained short-word/quiet controls, actual C3 frame
time and allocation release independently. Power-of-two int8 weights preserve
the examined control decisions but still exceed the16-ms real-time deadline;
they are a rejected integration candidate. No reduced sampling cadence,
context capacity or retuned threshold is used to conceal that failure.

The September13 wide-spectrum and paired24/48-channel VAD experiments remain
host-only. Preserve each frontend's exact causal clock, feature-only arithmetic,
source split and validation-only checkpoint selection. Four new selected models
retain all15 short controls, but the best spectral variants still accept one of
two unfitted quiet regressions at0.4. Larger capacity does not resolve that error.
None is exported or installed. The normal app/context are unchanged; numerical
checks and inspected regressions do not replace fresh complete acoustic cycles
or the existing C3 latency/loaded-memory acceptance requirements.

The subsequent equal-capacity mean-versus-frame-detail comparison also retains
all15 short controls while accepting one unfitted quiet recording. Keep both
6409-parameter students rejected. An independent, optional binary32 scaling
optimization preserves all44 reference feature/model/state files exactly and
reduces the isolated C3 maximum frame time from41082 to36475us. It still exceeds
16000us and is not installed in the normal Agent. Full4-MiB before/after equality
confirms restored application, configuration, context and retained clip.

Keep optional arithmetic/runtime and integer-width experiments isolated from
the normal Agent. The September13 RVfplib arithmetic and bounded-width variants
reduce the measured six-input maximum to29158 and28102us, respectively, without
changing the recorded probabilities. Both still exceed16000us. Retain exact
primitive/full-trace comparisons, immutable external-source identities and
before/after4-MiB equality; no acoustic or complete-Agent acceptance follows.
Context capacity and the normal ef92 application remain unchanged.

A separate last-layer adaptation may reuse the exact fixed8 CNN/recurrent
backbone while setting only populated pitch slots to normalized zero Hz. Freeze
all preceding weights and update only the final32 weights and bias. Keep complete
16-ms frames, original source/split/teacher identities, integer-head validation
selection and the0.4 cutoff. Removing pitch computation is permitted only after
retained controls/unfitted-noise checks, C integer equivalence and real C3 timing,
allocation and complete acoustic-cycle checks. Host preparation that still
computes pitch before masking is not evidence of a runtime improvement.

The completed33-parameter experiment is rejected: it preserves15/15 retained
short controls but accepts one of two unfitted quiet regressions at0.4.
Validation-selected epoch29 improves teacher BCE slightly, while the worst
unfitted quiet score rises0.414783 to0.417249. No output row is exported or
installed. The unchanged full-pitch reference still passes these retained cases;
its measured28.102-ms maximum remains above the16-ms processing period.

The optional code-placement experiment keeps all44 complete host traces and1410
C3 predictions unchanged. Moving hot code to IRAM costs10240 resident bytes and
reduces the measured maximum28102 to27537us (2.01%), still above16000us.
Reject it for live integration. Normal firmware/context/clip are restored,
with all4MiB byte-identical to the pre-test image. No acoustic acceptance follows.

The isolated binary32-guard experiment must preserve finite/range rejection,
ordered comparison, signed-zero, subnormal, infinity and NaN Boolean results.
Nonnegative finite bound inputs are an explicit helper contract. Preserve all
assertions and numerical operations; floating exception flags are outside this
comparison-only contract. Check both modes under sanitizers and full traces,
then measure C3 timing with hot-code placement disabled and the original layout.


Both guard modes reproduce all44 complete host feature/float/fixed8 state
traces. The C3 enabled variant retains all1410 recorded predictions, costs
40692 dynamically allocated bytes, and reduces maximum28102 to24875us
(11.48%). It still exceeds16000us. Keep the optimization optional and outside
the normal Agent until real-time and complete acoustic/resource checks pass.

An isolated conversion-width fast path must keep signed64 products/accumulators
and use the original float conversion outside signed32 bounds. Fixed cell input
may use exact binary scaling within the proved32766 float-state bound, with the
original roundf/int64 path retained outside. The cell, FFT and IIR numerical
outputs and failure checks remain unchanged; compare boundary values, sustained
recurrence and complete host/C3 traces before measuring any performance claim.


The optional conversion-width experiment preserves all44 complete host
feature/float/fixed8 state traces and all1410 C3 predictions. Each host mode
also passes534690 integer conversions,155704 cell inputs and440000 recurrence
steps. The C3 maximum falls24875 to24491us (1.54%), still above16000us.
Allocation40692, closed heap327108 and stack3904 remain unchanged; maximum
inference8204us. Preserve the expected deadline failure and do not integrate
into the normal Agent. No recording, playback or cloud call occurs.

The next isolated student keeps the full original normalized40 mel bins and
native pitch at every complete16ms frame, including initial zero history.
Freeze Linear123->16/ReLU, one LSTM24 and one output logit (6041 parameters),
zero state per complete clip. Reuse the2354 hash-verified streams and543174
full teacher frames with the same16/four speaker split and declared noise roles.
Seed9221,20 epochs,100 steps, Adam at0.0003, gradient norm1; batches contain
8 synthetic,8 physical,8 ambient and4 declared-noise complete clips. Mask
padding and average each clip's loss before the batch mean. Select only by
equal-three-domain validation teacher BCE. Keep the0.4 causal support gate;
all15 retained short controls and both unfitted quiet cases must pass before
C quantization/export. Static5832 MAC/output excludes frontend/activations
and proves no deadline or full-Agent resource result. M4 remains unaccepted.


The full-native-feature6041-parameter student completes2354 streams/543174
teacher frames and20x100 training steps. Validation alone selects epoch20
(SHA932d95c0..., BCE0.52442280). All52 retained sources/32 causal traces are
checked: it rejects both unfitted quiet sources but misses6 of15 controls,
with minimum control0.239281 and maximum unfitted quiet0.312710 at0.4.
Reject candidate16; no C export or device installation. Full teacher retains
all15 controls/minimum0.436226 and rejects both quiet sources/maximum0.370318.
Keep failed results; M4 remains active/unaccepted.

The explicitly frozen longer-training control uses100 epochs because the
validation minimum occurred at the original20-epoch boundary. Preserve all
numerical settings and require the repeated first20 checkpoints/losses to match
exactly. Data ancestry is explicit; validation alone selects among the fixed100
epochs. Existing retained regressions are known tests, not unseen acceptance.


The fixed100-epoch control reproduces every tensor and loss in the first20
epochs exactly. Validation selects epoch99 (SHA19985eb3..., BCE0.52029964).
Across52 retained sources/32 causal traces, it rejects both unfitted quiet
sources but still misses5 of15 controls (minimum0.240641; quiet maximum
0.300059). Reject candidate17 without export, flashing or threshold change.
Longer training alone is insufficient; M4 remains active/unaccepted.

Default-off TEN_PITCH_GUARDS may replace only six comparison predicates in
the existing direct-LPC pitch tracker. Preserve all arithmetic, assertions,
pruning and ascending-index ties. IEEE binary32 gt/eq/le Boolean results must
match for signed zeros, subnormals, infinities and NaNs; floating exception flags
are outside the comparison contract. Both host modes and44 complete feature/
float/fixed8 traces must match before silent C3 timing. No changed inference
cadence, thresholds, model, normal firmware or context budget is permitted.


The exact pitch-comparison experiment preserves all44 host feature/float/
fixed8 state traces and all1410 C3 predictions. Each host mode passes517225
pairs/2586125 comparisons and all previous primitive checks. C3 maximum
falls24491 to23368us (4.59%), still above16000us. Keep the option outside
the normal Agent. Allocation40692 and closed heap327108 are unchanged;
stack3888 and inference8203us. Full4-MiB restoration is byte-identical.
M4 remains active/unaccepted; no acoustic acceptance or context reduction.

The paired native-depth experiment starts both variants from the validation-
selected single-layer epoch99. The depth variant adds LSTM24 and a zero24-weight
additive output, preserving initial logits across all2354 streams/543174 frames.
Parameters10865 and static10464 MAC/frame exclude frontend, activation and C
quantization. Both variants receive the same seed9225 complete-clip batches,
fresh Adam0.0003, gradient norm1 and100x100 steps. Select each by validation BCE
only; log batch-index hashes for pairing. Keep15 known controls/two unfitted
quiet tests at0.4 and all physical/full-Agent/cue/cancel gates unchanged.


The paired extra100-epoch comparison reproduces initial logits exactly on
2354 streams/543174 frames and uses identical per-epoch batch indices.
Validation selects control epoch96 (BCE0.51888637) and depth epoch49
(0.51913223). Each still misses6 of15 known controls, while rejecting both
unfitted quiet cases at0.4. Reject candidates18/19 without C export or device
installation. Added recurrence does not resolve these errors. M4 unaccepted.


The faithful full TEN Torch mirror passes44 archived C traces/10668 frames.
Maximum probability error5.96046e-7 and state error3.05176e-5 are below the
frozen1e-5/1e-4 tolerances. Explicit1/3/17/80/full chunks, prefixes, reset
and masked gradients pass. The initial check only compared single-step
probabilities; a separate complete rerun also checks single-step logits.
Freeze candidate20: adapt the full pretrained74986-parameter backbone to
zero-pitch features for20x100 steps at3e-5, selecting validation BCE over
epoch0 through20. No hardware or runtime-saving claim follows yet.


Candidate20 completes20x100 steps and selects epoch20 solely by validation
BCE0.51212123, improved from0.51396811. It rejects both unfitted quiet
sources (maximum0.388211) but misses the retained cue20-short control
(0.398226; original full model0.436332). Reject it at the unchanged0.4
cutoff. No adapted C tables, pitch-estimator bypass, flash or new capture.


Candidate21 completes the paired20x100 anchored run, with exact initial
validation and all20 batch-index hashes matching candidate20. Validation
selects epoch20 (BCE0.51223682); the same cue20-short control still fails
(0.395949), while both unfitted quiet sources are rejected (max0.384183).
Reject21 without export or deployment. The0.001 summed weight anchor does
not recover that weak short word. Preserve all21 checkpoints and failures.


A host-only finite-queue study preserves the original full fixed8 model
and native pitch. All32 cached complete input streams/7800 frames match
archived C tensors exactly;15 controls pass (minimum0.4420105) and both
unfitted quiet sources are rejected (maximum0.3730713) at0.4. This does
not change the recorded16ms real-time failure or prove a working pipeline.



M4 background confirmation is experimental and default off. Its source-clock
endpoint and failure cleanup pass host checks; an8s wall confirmation guard
is reported separately from the original4s input window. This is not a
16ms real-time, acoustic or resource acceptance pass. The integration contract
and evidence remain in docs/WAKE_VAD_SPEC.md and docs/WAKE_VAD_REPORT.md.


M4 background-verifier pilots now have full-Agent acoustic/resource evidence.
Whole transient-workspace reuse achieves zero additional TEN model heap and
passes the8-case pilot minimum heap requirement. The pipeline still fails
quiet computation deadlines and completion latency, so it remains default off
and unaccepted. Preserve the initial v3 missing-tail failure and corrected
producer/reader regression. See docs/WAKE_VAD_REPORT.md for measured results.


The optional no-pitch background verifier passes isolated C3 timing but still
fails full-Agent quiet computation and some completion latency requirements.
The validation-selected0.395 cutoff is not deployed; original0.4 and all source
deadlines remain. ADC status batching adds no memory and changes no PCM/math.
The default-off lossless format3 now passes host corruption/power-cut checks and
all eight full-Agent boundary cases. Its unchanged100-round mixed run passes98
runtime cases: both failures are near-word false wakes, while all20 no-command
timeouts complete. The47636B lifetime heap minimum fails the48KiB requirement.
The versioned storage contract is in docs/AUDIO_CLIP_FORMAT.md. M4 stays active
and unaccepted; do not count the basic pass or steady heap as full acceptance.

The startup-only settings copy has now been removed by reusing the idle engine
buffer before subsystems start. Linked BSS falls2,888B without reducing stacks,
network buffers or context. The new image passes8 boundary and40 fixed mixed
rounds, minimum heap52,452B and no sustained drop. This supersedes the heap
failure only for these new runs; the earlier100-round failures remain evidence.
Keyword mistakes remain unresolved. Default-off heap/feature diagnostics and
their measured budgets are specified in docs/WAKE_DIAGNOSTICS.md. Wider full-
resolution windows and a fixed13-template gallery both regress retained cases
and are not deployed. M4 remains active/unaccepted.


### M4 local diagnostic checkpoint (2026-09-13T12:38:09.917105+08:00)

Optional getter metadata is1732B total trace state, disabled in normal builds.
Nine measured getter values are constant; do not use them as word boundaries.
Release the idle ADC before recreating the keyword model, then reopen normally;
active recording and128KiB history budget stay unchanged. The new eight-case
local concurrency run passes with55360B minimum heap; preserve earlier busy
admission, raw misses, near-word errors and uncertain initial-phoneme evidence.
M4 remains unaccepted. See docs/WAKE_DIAGNOSTICS.md and WAKE_VAD_REPORT.md.


### M4-06 direct-action completion refinement (2026-09-13T13:19:38.860510+08:00)

A successful direct action preserves success if post-effect cleanup is Busy;
retain ownership and reap through the existing poll without repeating effects.
Admission Busy, driver failure and non-Busy cleanup errors remain visible.
The guarded-interleaving regression must fail on old source and pass with audio
on/off after correction. Default-off Busy diagnostics have52B counter storage
and no disabled runtime cost. Local24+8 playback checks and33 host tests pass;
M4 keyword and immediate-first-phoneme acceptance remains open. Current identity
and evidence are summarized in docs/M4_CURRENT_STATE.md.


### M4-02 onset evidence checkpoint (2026-09-13T13:40:39.178463+08:00)

Keep negative lag available and hold the initial80ms out of alignment fitting.
Validate1ms measurement against known delay/cropped-prefix controls; retain old
10ms evidence and acoustic timing uncertainty. On unchanged firmware,12 fixed
cycles complete with all cues and no observed DMA loss. Four familiar strong
onsets25..72ms after the cue retain strong head evidence; weak onsets and two
pre-cue overlaps remain separate outcomes. This is not a general first-phoneme
or keyword acceptance pass. Current details: docs/M4_CURRENT_STATE.md.


### M4 keyword replacement gate (2026-09-13T14:15:06.165921+08:00)

Pin a candidate model, phrase, true/near/partial negatives, voice resources and
original decision before inspecting scores. File/graph size does not prove
C3 suitability. Preserve exact feature cadence and upstream probability
conversion; independent chunk and decision checks must precede attributing
failures to the model. Two English alternatives fail54 combined digital cases
and remain outside firmware. No automatic phrase change, relaxed cutoff or
general accuracy pass; existing Chinese failures remain open. Details:
docs/MICRO_KEYWORD_STUDY.md and docs/M4_CURRENT_STATE.md.


### M4 gate policy and input provenance (2026-09-13T14:44:04.043288+08:00)

Freeze actual source-family identities before fitting; related rates, pauses,
trims and captured versions must not cross a held-out positive-family boundary.
Frozen templates containing that voice mean conditional policy validation,
not unseen-speaker accuracy. Retain raw misses with no invented features.
The fixed all8-distance ridge policy fails both grouped98 and retained24 cases
and stays outside firmware. C3 compile-only shared scratch measurement is
60556B, distinct from39808B VAD usage; any future PCM diagnostic must bound
storage/export and preserve exclusive ownership. No new diagnostic acceptance
is implied. See docs/KEYWORD_GATE_STUDY.md.


### M4 complete input evidence refinement (2026-09-13T15:40:13.830480+08:00)

Default-off observation may borrow the idle engine workspace only while
exclusive turn/work ownership and producer lifetime are preserved. Copy before
model mutation; publish immutable bounded frames with sequence/CRC. Never
silently overwrite unread data or treat incomplete transport as a model miss.
Cancellation, queue full, timeout and output error must remain distinguishable,
and producer quiescence must precede scratch scrubbing/release. Observation
suppresses normal cue/capture and is not its acceptance test. Complete raw
input replay must preserve cold state, exact samples and original boundaries.
12 local observations and2400 exact replay blocks verify the implementation;
five positive recognition failures remain. Do not lower context/resource
requirements or relabel those failures. See docs/KEYWORD_INPUT_STUDY.md.


### M4-01 causal-window evidence refinement (2026-09-13T16:31:49.100178+08:00)

Window selection must use only data available at the original model hit, with
the same selection procedure for reference sources. Preserve no-hit positives,
near-word negatives, source grouping and every original condition. The three
frozen exploratory selection candidates fail their promotion gate and stay out
of firmware; improved results on the12 familiar actual inputs cannot override
regressions in the98 retained cases. Numerical parity and model-availability
checks are distinct from recognition acceptance. No resource, context, phrase
or existing M0/M3 requirement changes. See docs/KEYWORD_ALIGNMENT_STUDY.md.


### M4 cue/first-sound evidence refinement (2026-09-13T17:21:45.185231+08:00)

Cue amplitude changes require separate measured continuity, audibility-proxy,
raw onset and resource evidence; lower residual power alone is insufficient.
The fixed half-cue pilot fails its frozen criteria and is reverted. Preserve
unknown cue gaps separately from known post-cue and pre-cue cases. PCM envelope
correlation and within-cue phase fitting do not establish subjective clarity or
the physical fault location. ADC overrun counters cannot stand in for TX DMA
continuity evidence. Continue independent input/output diagnosis without
relaxing keyword criteria, recording timing, context size or M0/M3 requirements.
See docs/WAKE_CUE_ONSET_STUDY.md for fixed sources, thresholds and retained failures.


### M4 acquisition-versus-output evidence refinement (2026-09-13T17:56:26.988093+08:00)

Timing verification must distinguish capture packet integrity, per-sample
phase continuity, cue frequency/amplitude envelope and actual output failure.
Keep unknown/low-SNR windows and original strict cue failures. Nine controlled
headset-only timing events are now supported by two independent simultaneous
references; neither capture-mode candidate fixes them. Do not require another
blind firmware amplitude change to compensate for an unlocalized measurement
artifact. A revised phase-tolerant cue measurement requires independently known
perturbation controls and a new normal-workflow trial; it must not merely lower
existing thresholds or retroactively declare M4 complete. Context, recording
boundary, keyword requirements and M0/M3 acceptance stay unchanged.


### M4 cue-presence measurement refinement (2026-09-13T18:26:02.862249+08:00)

The supplemental1320Hz/160ms RMS-envelope and quadrature-energy measurement
has known-perturbation/false-cue controls and fresh16-case normal-workflow
evidence. Preserve independent old waveform results, phase uncertainty and all
failed cases.79 known controls plus24 real negative controls pass; original
tail-crop failure and corrected tail-evidence requirement remain documented.
Normal workflow is15/16, with one83ms pre-cue short-word boundary failure.
Weak heads, keyword recognition and full M4 acceptance remain unresolved.
See docs/WAKE_CUE_MEASUREMENT.md; context/layout and M0/M3 remain unchanged.


### M4 per-record acquisition-limit evidence (2026-09-13T19:06:21.547841+08:00)

Preserve delivered-recording and start-cue ADC/decimator-limit observations
across live-meter recreation; current mic_clipped0 must not assert historical
capture quality. Audio status adds runtime-only record_input_valid,
record_adc_clipped and start_cue_adc_clipped, reset for a new job. Clipped or
cancelled observations do not imply committed recording; existing error/clip
validity remains authoritative. Start-cue counts include warm-up/drain processing,
not isolated tone timing. Separate ADC-limit flags from fullscale storedPCM.
The +8B candidate passes5 physical lifecycle cases and12 no-audio compatibility
tests. Eight no-cue recordings retain two invalid loopback controls. Weak heads
and keyword failures remain open; no M4/M0/M3 or context/layout change. See
docs/MIC_INPUT_STUDY.md for identities, warnings and complete Flash restoration.


### M4 ADC buffering budget (2026-09-13T19:59:24.285947+08:00)

Use10KiB input pool:80ms nominal at32kHz and4B/result. Existing64ms drain-work
bound, explicit overflow failure and48KiB free-heap requirement remain. A
measured64.558ms erase exposed the8KiB/64ms limit;72ms controlled hold fails
with8KiB and completes4/4 with10KiB. Plain10KiB has2 speech+2 no-command passes,
minimum53264B. This does not cover arbitrary flash stalls or full100-cycle/
keyword/weak-speech acceptance. Added2KiB open-mic heap; production BSS117672,
recording/context budgets unchanged. Temporary phase/hold diagnostics removed.
Reference docs/CAPTURE_BUFFER_STUDY.md for original failures and full restoration.


### M4 continuous capture resource result

The80ms-pool100-cycle run stops at53 with48732B minimum heap. The49152B
floor remains required; partial stable rearm/cue/timing results do not pass
the100-cycle gate.47 rounds and4 cancellation checks remain unattempted. See
docs/CAPTURE_SOAK_REPORT.md before any changed candidate or new acceptance.


### M4 provisioning workspace and pending main budget

Use same-size input/settings union; main-task admission and work_lock keep
roles exclusive, initialized settings staging is wiped on every exit. Preserve
all configuration checks and NVS transaction order. Main5120 remains a candidate
after a24/100 run stopped on invalid host capture; root default6144 and all
48KiB/1024B/100-cycle/RAW requirements remain. See docs/MAIN_STACK_STUDY.md.


### M4 host capture read-stall budget

Use500ms default host RAW/loopback buffers; record actual capacity and retain
strict discontinuity/warning/hash rules. Fixed300ms hold faults100ms but passes
three500ms pairs; two normal pairs also pass. No device buffer/gain/context
change. This does not replace fresh complete100-cycle device validation. See
docs/HOST_CAPTURE_BUFFER_STUDY.md.


### M4 audio workspace ownership and serviced replay verification

M4-BUF-01: Use one2320B typed workspace for input PCM, temporary checked-clip,
and replay state; initialize each role and join confirmation before reuse.
Keep speaker DMA, ADC parsing, meters and retained songs separate. Root main
default remains6144B until the5120B candidate completes original acceptance.
M4-IO-01: Replay validation must service the ADC between bounded Flash reads,
yield for cancellation, and publish only a fully CRC-verified clip. Do not reset
overflow counters or pause ADC to hide missed samples. Cancellation before
playback retains the original valid clip. USB clip export returns busy during
playback because packed-clip reader state has one owner. Context unchanged.


M4采集证据补充：等待音频包期间不得按主机时间生成替代零样本；
记录实际包位置、时间戳及错误标志。无警告不自动证明采样时钟完整。
第6次回环异常及原正常流程漏检保留，详见docs/KEYWORD_CURRENT_INPUT_STUDY.md。


M4当前反例：packet-capture-smoke-v1第1轮无追加指令却完成录音，完整输入
已保存；真实包采集与资源通过不代表VAD通过。早期低频活动来源未定，
不得仅按1320Hz提示音解释，也不延后PCM开始来遮蔽问题。


M4独立声学验收现与运行状态分别记录。raw-summary的passed须同时满足
运行、提示数量、已测普通语音结束0～2秒及无采集满幅；不能只复制运行成功。
缺失/不确定测量不通过，取消开始提示允许预期片段，输入哈希必须匹配。
本阶段新增3.207秒结束延迟，详情见docs/EARLY_CONFIRMATION_REPORT.md；
没有改变固件边界、模型门槛、用户数据或此前验收状态。

M4-MEAS-02：可选电脑端测试前筛选须使用完整原始PCM窗口，空轮询不补零，
进程退出/过期/十秒超时均拒绝放行。保留完整录音后重新核对哈希、音频包和
每个窗口，实际已匹配的测试声音须在窗口结束后500毫秒内开始，时间基准为
原生QPC。两秒低音量只描述测试前条件，不代表整次安静或VAD验收通过。
筛选不进入固件，不更改音频、上下文或原有检测门槛。

M4-VAD-HISTORY：模型的连续输入及内部状态属于判断契约。窗口重置、跳帧
或LPC隔帧更新须作为不同算法验证，不能用保留15个旧短词来宣称等价。
本阶段35份原样输入显示上述三种变体均失去最新空录反例的完整模型拒绝。
完整模型自身仍未通过正常流程8秒运算期限：172帧/2740毫秒输入后超时，
不得计为成功的无语音结束。临时采集阶段计时已移除；原有4秒源窗口、
8秒运算期限、48KiB堆、上下文和提示音后连续采集要求保持不变。
见docs/PITCH_HISTORY_STUDY.md；当前结果不改变M4、M0或M3验收状态。

M4-VAD-PERF-02：数值等价与目标芯片速度分别验收。四行共用输入和非零
索引两种实现虽通过每种35份/8500帧主机原样对照、芯片36组/9282帧逐位
对照，平均完整帧却分别慢4.74%和6.53%，不接入正常固件。100次隔离模型
启停无泄漏不等于正常100轮唤醒录音通过。保持原模型历史、权重、上下文、
时限和采集设置；本轮没有新增声学验收。详见docs/RECURRENT_ROW_STUDY.md。


M4-VAD-PERF-03: A RAM copy of original8-bit recurrent weights is not assumed
faster. Same-chip1/8-row variants increased total time8.52/8.89% despite exact
outputs, and are excluded. Model-lifecycle checks are separate from normal
100-cycle capture acceptance. See docs/WEIGHT_STAGING_STUDY.md.

M4-VAD-CADENCE: Internal hop changes require separate recognition acceptance.
Hold only already-completed probabilities on the original16ms decision grid;
do not backdate a32ms result or change the80ms/.4 gate. The512-hop experiment
loses3 short controls and1 historical quiet rejection and is excluded. Keep
all original16k PCM, source/wall limits, memory/context and event labels.
Equal-hop FIFO reduction alone has no normal speed/acceptance claim. See
docs/VAD_CADENCE_STUDY.md for preserved allocation failure and quality evidence.


M4-VAD-PERF-04: Fused binary32 conversion requires exact intermediate rounding,
an unchanged original-expression control, host/target bit tests and same-image
forward/reverse timing. The v3 diagnostic passes105699 numeric cases and6188
complete C3 frames;1.55% full-frame saving still leaves22.984ms>16ms. It remains
isolated, with no normal latency/resource or recognition acceptance claim.
Keep the retained wrong-baseline/printf build history and original time/memory/
context gates. See docs/FUSED_CONVERSION_STUDY.md.


M4-VAD-PERF-05: Recurrent input-width staging may reuse576B dead CNN workspace
but requires exact conversion/state sentinels and whole-implementation timing.
The tested variant has only0.00939% full-block difference and remains isolated;
6188 exact chip frames and100 model lifecycles do not pass normal100-cycle
capture acceptance. Do not assume a both-operands-width microbenchmark proves
single-input-width benefit. See docs/WIDE_INPUT_STUDY.md.

M4-CAPTURE-BOUND: Stopping acquisition while original inference catches up
requires a source-time proof covering every possible first confirmation,
including inclusive4000ms, unconfirmed resets and state-dependent activity.
Neither an always-positive shadow nor worker lag proves the input is complete.
Retain every required raw16ms block, unchanged4s/8s limits and actual model
decision; publish the final compressed page before closing ADC. The host-only
all-branch implementation uses8096B and passes118 cases. A smaller100B sufficient
guard counts potential energy frames across complete4000ms and gives up on the
sixth. It is an isolated candidate until real CPU/ADC/heap/cancel and acoustic
checks pass.120 host cases do not replace normal100-cycle acceptance. Original
uncommitted failure partitions and unknown tails remain diagnostic, with no
committed-CRC or human quiet claim. See docs/CAPTURE_BOUND_STUDY.md.


M4-CAPTURE-BOUND-02: The initial100B total-energy sufficient guard did not solve
the first normal timeout and remains isolated. A24B potential4-vote bound is
proved only as an acquisition ceiling: actual accepted/onset bits are subsets,
so confirmation/quiet-reset imply a potential event. Include current frame,
keep full4s waiting and1000ms end condition, ceil raw target to256samples, and
never generate a result/cue from the bound.120 host comparisons do not prove
producer/worker publication, ADC, CPU or cancellation behavior. Verify those
before integration; keep original8s/48KiB/context limits and failed pilot.


M4-CAPTURE-PIPELINE: Classic preprocessing may move to the audio producer only with immutable source-ordered metadata published before its raw sample count. Preserve classifier-before-level order, first two skipped classifier frames, original hysteresis/16ms score ordering and every required raw model input. Reserve at most2000B from already borrowed engine tail outside TEN allocations; no new large resident buffers/context reduction. Actual confirmation may switch to metadata-only endpoint drain. Cancel/join must precede full workspace release; a conservative source bound never commits a result or cue. Host exactness and sanitizer/thread tests precede finite normal hardware latency/ADC/resource/cancel checks. M4 remains unaccepted.


M4-CONFIRMATION-TAIL (explicit experimental execution-contract refinement):
Preserve full original16ms model input/history through every possible first-confirmation event. Only after immutable first4000ms metadata is fully published and the actual unconfirmed model/endpoint has passed the last conservative eligible event may an exact terminal-tail transition omit numerically irrelevant future model scores. It executes original classical endpoint feed/verify to the unchanged4s result; it never supplies fabricated probabilities, forces an early result, skips a required history prefix or changes recognition thresholds. Real NN frame/history telemetry remains unchanged while source endpoint time advances. If observations are incomplete, candidate timing includes4000ms or proof/admission fails, continue the full original path. Consumer-only proof and tail borrow existing metadata until joined; cancellation and original8s/48KiB/raw-cue/clip/context limits remain. This refinement is justified by original-C state equivalence, not by a passing reduced workload:118 case streams,62 valid pulse sweeps,110316 schedules,22211934 per-frame/cancel comparisons, plus560 packed-storage schedules pass. Normal C sources remain untouched; isolated hardware/lifecycle/acoustic acceptance still required. Earlier full-model timeout failures stay failed.


M4-CAPTURE-PREPARATION: A bounded preparation candidate may move at most four original4096B clip-sector erases into the already paused ADC phase after model admission and before ding. Keep the same clip format, CRC, erase cursor and header-last commit; do not pre-erase during ordinary listening. Record earlier replacement-slot invalidation, added acceptance-to-ding time and cancellation at sector boundaries. All post-ding raw samples and original model/source/wall/context limits remain; no success cue until CRC commit. Frozen precomposed fixtures must retain their timings, with cue-to-speech boundary measured independently; an earlier end cue alone does not prove controlled CPU speedup. Host flash identity/fault tests and real start/cancel/ADC/heap checks precede adoption.


M4-HOST-WAV: Real-time desktop loopback appends exact native PCM with writeframesraw and finalizes the WAV header on owned close. Do not rewrite the header per packet. Preserve full packet flags/positions/QPC,500ms buffer, exact gain and strict incomplete-capture failure. Sequential writing removes one measured-by-injection blocking surface; it does not prove the cause of prior spontaneous host stalls. Normal/exception WAV byte identity, paired actual packet/source checks and normal wrapper tests are required before reuse.


M4-ENDPOINT-OBSERVATION: Isolated diagnostic may preserve40B of the ACTUAL first-confirmation endpoint and NN-frame count, plus existing immutable20ms records, after ADC/worker completion and before borrowed arena release. Synchronously store only in verified unused clip last4KiB sector, body first/header last with version, cycle and CRC; no new buffer, per-frame logging, model/threshold/window or context changes. Cancel skips observation. Extra post-capture write delays cue and contributes clip-I/O counters; this build cannot substitute normal timing/continuous-soak acceptance. Host35 original score/input pipelines and exact post-confirmation replay, storage corruption/cuts, resource/cancel checks and full original Flash restoration required. Capture/trace export may explicitly interrupt listening and must be recorded as such. Never infer earlier overwritten raw/metadata.

M4-POST-TONAL-GATE (experimental post-confirmation contract): Only after an actual original neural confirmation and model close, the sole reader may reread all raw samples from0 in bounded steps of at most256 using the existing worker buffer. Rebuild complete filter history, never apply pre-confirmation frames again, and retain every original raw sample/model history through first confirmation. A140B state may add narrow250/2000Hz notches, nominal8Hz bandwidth, and veto an otherwise accepted classical/energy frame only when cleaned mean fails the SAME max(240,noise*3/2) threshold. No new accepted bits, amplitude floor adaptation, altered first confirmation,4s/8s/48KiB/context limits or fake model scores. Verify original mean against immutable metadata, cancellation between steps, full packed-reader/CRC ownership and per-frame endpoint ordering. Measure CPU and worst wall time separately. Known pause/short protections,980 fixed host schedules and actual EVT2 policy1 raw-to-terminal equality precede normal continuous tests. Diagnostic trace writes and per-round exports remain excluded from normal acceptance; do not replace prior failures or reduce the two-second cue criterion. Feature-off integration and100 real cycles are still required before marking stable.


M4-VAD-PERF-05: Exact LPC mirrored history and conv0 monotone affine/ReLU pooling
are isolated candidates. Preserve all raw inputs, full model history and16ms
cadence; never equate Q15-only checks with binary32 state equality. LPC's actual
stack increase is80B (array64B); pool may reuse only dead temp39..76, no new model
state or duplicate weights. Target paired24/6188 checks passed, but complete
frames remain above16ms. No normal/100-cycle acceptance or root adoption follows.

M4-PRODUCER-FACTOR: Symmetric Q30 numerator factoring may be investigated only
under pinned b0==b2 and bounded state/input magnitudes<=2^25. Five notches also
have b1==a1. Preserve truncation toward zero, clamps, sample quantization, raw
capture, all metadata and first-confirmation policy. All intermediate widths
must be proved, exact states tested with boundary/random and original full raw
clips; whole producer/SPSC/lifecycle/cancel and measured C3 timing precede
integration. A host helper or operation-count reduction is not a speed result.
No model/history/context reduction, larger preerase, unsupported Flash suspend,
two-second limit relaxation or rewriting old failures. M4 remains unaccepted.

M4-PRODUCER-FACTOR-MEASUREMENT: Compare actual original/candidate functions at
the same normal Os setting,160MHz and1000Hz tick, preserving calls and112B state.
Use full retained raw inputs, fixed0/1/1/0 ordering and an unpadded final block;
verify every output and state byte, not only a checksum. Timing includes possible
interrupts and excludes ADC/model/Flash capture. The measured10.9914% filter-only
gain is9.05ms per second of input and does not accept normal latency. Host980
pipeline schedules and22ON/12OFF compatibility pass, but first normal keyword
miss/remaining7unrun, earlier2s failures and100-cycle gaps remain failures/gaps.

M4-KEYWORD-CURRENT-PARITY: New complete-input diagnostic/replay may locate an
actual template veto without changing threshold550/gain1 or labelling it passed.
Retain all512-sample frames, CRC/order/generation and native recording clocks;
verify model/template identity and all decisions from cold unaltered input.
Observation suppresses cues/recording and changes scheduling; four current
observations with one positive veto cannot reconstruct prior missing normal
PCM or establish normal/quiet/speaker-generalization acceptance. Keep ADC rail
counters separate from PCM full-scale checks. No user questions or audio upload.


M4-CAPTURE-PHASE-PROFILE: Isolated cycle diagnostics preserve every original
operation and publish producer-owned counters only after completion/cancel.
Use odd/even frozen atomic snapshots, explicit clock/overflow/count validation,
and exclude the model thread's Flash reader from plain counters. Inclusive
phases overlap; observer overhead/interrupt time cannot be subtracted as exact
CPU. Full original inputs/model/history/pitch/threshold, source/wall/48KiB limits,
and current context remain. The348B object/352B layout increase is diagnostic.
Four new cost cases do not replace failedH/8/20/100 or quiet/subjective acceptance.

M4-PACKED-PREFIX-CHECK: An isolated single-pass trimmed-commit candidate may
save prefix CRC while decoding ALL written samples; it must still verify full
raw and encoded CRC, exact byte endpoint and no partial record before the same
header-last commit. Retain discarded-suffix corruption detection, version2/3,
raw/full-length paths, bytes, erase policy and resource limits. Private reader
cursor may end at full scan; public seek/decode/retry must remain correct, without
promising identical cache hits or read-call fault indices. Independent original
codec/Flash equality, prefix boundaries, all actual read-cancel sites, commit
cuts and ON/OFF compatibility precede hardware. Same stimuli at different times
are not identical ADC input; faster commit does not accept2s acoustic latency.


M4-PRECONFIRM-TONAL-HYPOTHESIS: Separate host-only signal-path experiment, not
bit-identical optimization. Apply the existing fixed250/2000Hz8Hz notches to
every model-input sample from source0, keeping raw storage and measured classic
frames unchanged. Compare original full and explicitly pitch-bypassed backends
with/without filtering at unchanged weights/.4/16ms, no resets, windows, gain,
padding or sample removal. Baseline hashes must reproduce all35 original files.
Evaluate both causal16/20ms alignments, all15 short controls,4 historicalquiet
references and the latest observed no-command failure; never relabel unknown
ambient or replace prior rejected skip-pitch results. Any altered numerical
model input is explicit, not reported as original-model equivalence. Host-only
feasibility never accepts2s/4s/8s/48KiB, immediate speech, hardware or M4 gates.


M4-GRADED-ONSET (isolated fusion hypothesis, rejected): Ordinary five-score
mean .4 plus seven classical votes; relaxed four-vote fragmented support only
with mean .5. Existing120ms/320ms/4s/1s/10s source accounting unchanged. Compare
all35 actual-score cases and both causal alignments; no grid or retuning. The
frozen rule loses supported-short-rejected and must not enter device builds.

M4-RAW-PITCH (isolated frontend hypothesis): Use upstream raw-correlation pitch
mode by setting only useLPCPreFiltering=0 before allocation. Retain raw PCM,
4kHz pitch processing, complete16ms recurrent/pitch histories, allweights and
original .4 joint decision/endpoint. This explicitly changes the frontend,
not an exact optimization; do not mix it with tonal filtering or graded onset.
A2kHz configuration change alone is invalid for the existing specialized
32x64 correlation kernel and is excluded. Require all retained controls/quiet
references, original source/endpoint/cancel guards and later failure checks
before hardware. Measure actual C3 timing and RAM separately if admitted.
Scoped allocator definitions must apply to the actual derivative translation
unit; sanitizers and100 lifecycles are mandatory before acoustic replay.


M4-LINEAR-PITCH-BANDS (isolated numerical optimization): Transform the existing
18band log10/max/pow whitening floor to linear max/multiply with .01 initial
energy,1e-8 global floor and10^-2.5 neighbour decay. This is equivalent in real
arithmetic, not binary32 bit-exact. Preserve every LPC/pitch/recurrent16ms
update, original PCM and endpoint rules. Freeze primitive bounds3e-5 relative
to original float/4e-7 to double, Q15 delta64, control event delta20ms and all
quiet/latest failure rejections before hardware. Both runtime branches must
match separately compiled host outputs, including unscored original tails.
Device compares identical full blocks in order0/1/1/0, all123 feature values
per block against corresponding host (1.1e-5 absolute), repeated same-mode
features/probabilities bit-exact, and100 admission/releases. Measure LPC and
complete frame costs, stack and memory. No acceptance from fewer operations
alone; freshfull4MiB preflight/wholeapp rollback/fullbyte equality required.


M4-LINEAR-PITCH-DEVICE-02: Preserve failed initial host-Q15 identity protocol.
An original-mode cross-platform quantization discrepancy must first be explained
by feeding actual C3 feature bytes into the independent host model. A separately
frozen diagnostic may then require exact scores at that actual feature/model
boundary, all original full joint timelines unchanged, unchanged1.1e-5 feature
bound, preexisting64-Q15 approximation bound and repeated same-mode bit identity.
Report canonical-host byte identity separately; do not relabel the first failure
or tune detection thresholds. Same firmware, full inputs,0/1/1/0 order and100
release checks, freshbackup and fullrestore remain. Timing is measured inside
C3 blocks, excluding host replay. This is numerical diagnostic, not M4 approval.


M4-FFT-Q15 (isolated precision hypothesis, rejected): Freeze one Q15 sample and
twiddle scheme with32-bit butterflies and64-bit real unpacking; no bit-width
grid. Preserve all1024points, original16ms inputs/histories/model and endpoint.
FFT peak-relative bound.002, model score delta328, old control event tolerance
20ms and allquiet/latest rejection required before hardware. Scalar and old
behavior pass but maximum1568Q15 difference fails; keep sourceprecision original.

M4-FFT-MULHI (separate bounded arithmetic hypothesis): Keep originalQ29 sample
scaling/Q30 twiddles and everyFFT stage. Only butterflyrotations may approximate
Q30 product combinations using signed upper32bits times4; real unpacking remains
original64bit. This is NOT bit-exact. Difference rotation error at most4 Q29
integer units, sum at most8, must be proven against original64-bit arithmetic
including signed boundaries. Require original FFT error bound4e-6, full35source
score delta<=64, allcontrol/quiet/latest and completeendpoint protection before
C3. No newtables/buffers, no othercandidate combination or threshold retuning.
Inspect actual compiler output for intended multiply-high instructions before
assuming performance; continue original resource/timing/acoustic acceptance.


M4-DSP-COMPOSITION: Test original full model, the composition of exact FFT cardinal
rotations/LPC mirror/fused conversion/monotone first pool, and that same composition
plus previously bounded linear pitch energy as separate modes0/1/2. All35 complete
old recordings, all samples/tails retained, original histories and thresholds.
Mode0/1 host features and scores must equal independent original; mode2 equal
independent previous linear path. Same-chip mode1 features/probabilities also
bit-exact to mode0. Retain1.1e-5 feature/64Q15 device boundaries for mode2, full
original endpoints, repeated mode identity, stacks/lifecycle. Measure all48 same
inputs in0/1/2/2/1/0 order and100 releases. Isolated16ms and later2s/4s/8s/48KiB
limits remain. No failed Q15/mulhi candidate included; no additive timing claim.


M4-DSP-PIPELINE: Integrate only the independently checked single-path DSP trio
into the previous measured packed-prefix capture pipeline. Preserve every raw
input/history/threshold/cue/timeout, 3000B metadata,60688B workspace, codec, phase
instrumentation, config and the original four finite fixtures/gain. Component-local
RVfplib renaming must remain local; copy per-source options/allocator definitions
in their actual target scope. Audit linked sources and C11 before flash. This pilot
is for actual latency/contention evidence despite the retained failed16ms isolation
gate; it neither waives that failure nor acceptsM4/100rounds. Reuse byte-identical
host proofs, then measure real cue timing/cancel/ADC/heap and retain all failures.
Fresh4MiB99fb before mutationtry;app-only;wholeoriginalapp plus changedclip restored
and entireFlash byte equality/off. No user questions, uploads or newquietlabels.


M4-DSP-PIPELINE-RESULT: Four runtime cases completed, but independently measured
short end cue2.368666667s fails original2s; pause1.070708333s. Board ADC clipping55
in pause differs from external fullscale0; report both. Minimum heap55168B/cancel94ms
and fullFlash restoration do not acceptM4. Earlier16ms/H/20/100 failures remain.

M4-COARSE-PROFILE: A separate observer-cost candidate may compile out ONLY the
three per-sample phase spans (decimator, meter, source). Keep all DSP/metadata,
source samples, model probabilities, codec and task/Flash timing behavior unchanged.
Retain coarse capture/read/parse/spectral/flush/write/erase/commit/RMS/calibration
measurements and identify absent rows explicitly as unmeasured, never infer their
values. Freeze structural source comparison and actual build options before a
fresh finite four-case acoustic run. Do not subtract empty-span calibration as an
exact correction or attribute different ADC recordings to controlled CPU speedup.
All original2s/4s/8s/48KiB and data recovery/cancel requirements remain unchanged.


M4-COARSE-PROFILE-RESULT: Removing exactly six observer lines leaves28 checked
DSP/capture/codec/config/fixture files unchanged; absent phase3/4/5 are explicitly
unmeasured. New publication tests1000lifecycles/10000concurrent epochs pass with
ASan/UBSan. Actual49C11/local RVfplib/uniqueweights/config checks pass. Four real K
cases pass finite runtime and acoustic checks:1.3069375/.9888125s endpoints,78ms
cancel,4s no-command. Minheap53392B,DMAlost0,externalfullscale0,board pauseclipped62.
Different actual ADC and confirm660vs1140ms prevent causal attribution of all
improvement. No original H/20/100/16ms or subjective failure waived. M4 NOT accepted.
User asked duration after two days; finish this bounded handoff within one hour
from2026-09-14T15:54:50+08:00 without expanding further optimization hypotheses.
Retain candidate/rollback evidence and original full4MiB restoration/off; current
goal remains unachieved, not relabeled complete because of this delivery cutoff.

M4-TEST-EXECUTION-COST: At the user's explicit request, routine test execution and
report checking use an Astra low-effort helper with a minimal task brief, rather
than inheriting the full development conversation. Fixed scripts perform the
repetitions; return a compact summary and actual failures. Keep high-effort work
for design, code changes and unresolved failures. Do not repeat completed tests
merely to demonstrate the new mode; this changes the assistant workflow only,
not the device's DeepSeek configuration or acceptance criteria.

M4-REMAINING-REGRESSION: After the bounded handoff, continue acceptance of the
same coarse-profile app without another algorithm/parameter experiment. First
reuse the original eight H/K response cases byte-for-byte and in original order;
its old first H case missed raw keyword detection. A low-effort helper prepares
and runs the fixed scripts; high-effort review handles actual failures. Stop at
the first runtime failure; analyze retained independent cue/end timing afterward
and do not advance to the original20 precomposed/negative cases unless both
runtime and acoustic checks pass. Eight USB-triggered responses do not establish
immediate post-ding capture or100-round stability. Preserve original source,
gain.6, thresholds and2s/4s/8s/48KiB gates; fresh fullFlash preflight and full restore.

M4-COARSE-REGRESSION-RESULT: Original eight response fixtures on unchanged d9bd6975
app pass runtime checks8/8, but original independent acoustic checks fail at K
short2.253583333s and H pause2.509645833s. Minheap53116B,DMAlost0; full4MiB99fb
restored and audio/wake off. Preserve failures and do not run20/100 unchanged.
Offline diagnosis may compare retained raw clips with the exact compiled C
filters and sampled telemetry. Energy eligibility alone is not an actual VAD
decision; missing spectral/model histories must not be reconstructed as fact.
The lower-effort test helper runs fixed measurements and prepares concise
evidence. Main development effort handles failure interpretation; neither the
root reasoning setting nor device DeepSeek settings are claimed to change.

M4-CLIP-DEFER (isolated storage scheduling candidate): Reserve16384B from the
already borrowed engine region outside actual TEN allocations and3000B source
metadata. Model admission must retain full original allocations with zero heap
fallback. Overlay clip offsets16384..32767 in that RAM, initially copied from
Flash. Only the ordinary recording producer may erase forward once/append;
the original release/acquire raw publication bounds gate immutable reader bytes.
No ring eviction, extra source/model buffering, new codec, extra preerase or
unsupported XMC suspend. Join the reader before flushing/restoring backing ops
and releasing the borrow. Flush physical sectors before existing CRC/header-last
commit; cancellation or flush failure never emits success. Keep all raw samples,
model/history/thresholds,4s/8s/2s/48KiB/context limits. Host boundary, NOR, packed
read/commit/reopen, fault/cancel and publication checks precede any hardware;
timing gain and acceptance remain unproven until actual controlled measurements.

M4-SPEEX-KEYWORD-SCREEN: Isolated SpeexDSP1.2.1 fixed-point/KissFFT candidate,
commit1b28a0f61bc31162979e1f26f3981fc3637095c8,160samples/16kHz,-6dB only;
AGC/VAD/echo/dereverb off. Host allocator/lifecycle/latency/boundary checks first.
Preserve compiler/sanitizer failures; no silent arithmetic or diagnostic bypass.
Freeze complete24 actual inputs from keyword-pcm-v1 and keyword-input-v4, all
original labels/traces, every padding/flush sample and delay/disabled controls.
Require all prior positive accepts retained, no negative accepts, and improvement
beyond controls before C3 timing/memory integration. Fixed WakeNet/gate/gain1/550;
no parameter sweep. Routine testing uses Astra Low; root reviews actual findings.
No host-only result counts as real-time, acoustic or M4 stability acceptance.

M4-SPEEX-KEYWORD-RESULT: First12/48 trials complete with all original raw feature,
decision and CRC parity; fixed -6dB loses original positive7 and rescues no case
beyond raw/delay/disabled controls. Accepted positives out of8:3/5/5/2; all4
negative inputs rejected in every arm. Stage2/48 trials explicitly unrun. Reject
candidate without C3 DSP integration/benchmark or parameter retry. Whole4MiB99fb
restored with wake/audio/mic/request off. M4 remains incomplete. Test execution
was Astra Low; root reviewed source, parity, stage decision and complete restore.

M4-KEYWORD-HISTORY64: Isolated causal history candidate based on observed raw
trigger movement57->42 and42->39 after160-sample input phase changes. Use latest
min(64,actual received) rows, minimum32, full original row resolution and same
eight template sources/original hit times. No priming/averaging/interpolation,
window search or lookahead. Integer normalization uses actual count; DTW angular
cost and205 warp penalty retained, scaled band abs(i*M-j*N)<=8*max(N,M), cost
divided bymax(N,M). Both lengths32 must exactly reproduce prior C. Fixed158-case
host screen retains original98, actual24 and derivative36 with raw misses/labels;
reject any group regression of a formerly correct case, require an actual-input
correction before chip work. No parameter sweep, new template or threshold. C3
stack/time/>=48KiB resource admission remains separate and unproven.

M4-KEYWORD-HISTORY64-RESULT: Fixed host screen rejected: examined98 correct78->60
(19 regressions), actual24 correct19->10 (9 regressions, zero rescues, one new
false accept), derivative36 correct24->12 (12 regressions). Original raw misses
retained. All5445 numeric pairs pass, original32 templates and121 eight-score
outputs reproduce exactly, but this is not recognition acceptance. Astra Low ran
the fixed tests; root verified234 source hashes and full group/score results.
No device build/access, timing claim, parameter sweep or adoption. Preserve mixed
WSL warning/stdout logs and their limitation; future runners must capture separate
streams safely. Normal firmware/data unchanged by this host-only work; M4 incomplete.

M4-KEYWORD-SCORE-OBSERVATION: Default-off isolated probe wrapper forwards the
pinned SDK dl_softmax_step call unchanged, then copies bounded binary32 results.
No opaque-model reads, threshold/model edits or replacement math. Up to8 rows
and8 classes per512-sample block, exact bits, original queue metadata, explicit
invalid/overflow, and no fabricated scores in blocks without a call. One probe
task owns lifecycle. Host forwarding/bounds/strict sanitizer checks and one C3
build precede separately reviewed device access. Fixed24 original-input replay
must reproduce all old decisions/features/gate distances/CRC before scores can
inform diagnosis. This is observation, not detector acceptance or timing proof.

M4-KEYWORD-SCORE-RESULT: One Astra Low device session completed24 original inputs
and4800 blocks; all old raw hits, MFCC, gate distances/flags and CRC reproduce.
There are4752 post-softmax rows,198 per input with134 empty observation blocks.
Original positive misses03/09 peak at0.484142900/0.495130718 and never outrank
background. Near-word outputs can exceed these, so no peak-threshold fix or new
recognition acceptance follows. Root independently checked full results and
fresh/restored4MiB99fb equality with wake/audio/mic/request off. No new acoustic
capture, model/threshold/template change or retry; normal M4 remains unaccepted.

M4-KEYWORD-TRAINING-DATA: Host-only source extension uses verified distinct local
speech resources, preserves first outputs and fixed phrase/label definitions,
and does not play, capture or upload audio. Merge only disjoint training IDs
with identical frontend contracts and unchanged quantized samples. Keep the
validation/test identities separate and disclose training-family overlap in
older regression data. Failed candidates do not change the normal firmware.
The fixed 50-voice mixed-source candidate failed (validation misses24→38/72;
retained misses23→22/43 with6 regressions). No deployment or M4 acceptance.
See docs/KEYWORD_TRAINING_STUDY.md; all prior M4 timing/resource gates remain.

M4-KEYWORD-SEQUENCE-PROTOTYPE: An isolated host CTC experiment may learn the
fixed transcripts' character order using the same frozen C features. Only
training text defines the vocabulary, blank is never a target, and true input
lengths mask batch padding. Keep causal inference, bounded keyword span and
explicit unfinished-token behavior. Preserve strict timing separately from
presence. No firmware or M4 acceptance follows from training/data legality;
the old binary replacement and OR failures remain recorded.

M4-KEYWORD-ALIGNMENT-PROTOTYPE: A separate host experiment may restrict CTC
training alignment to known speech start minus60ms through end plus300ms,
with unit-weight blank loss on the remaining true frames. Preserve every input
feature and exclude only batch padding from the loss. Reject invalid intervals
or too few alignment rows for repeated targets; do not relax per sample.
Inference must not use speech labels, offsets, thresholds or a different decoder.
Keep original strict timing and all failed candidates. One frozen training and
cached development evaluation precede any further deployment consideration.

M4-KEYWORD-ALIGNMENT-RESULT: The fixed alignment experiment completed one40-epoch
training and both cached evaluations. No epoch passed the joint validation gate.
The unchanged selection chose epoch1, missing72/72 validation,43/43 retained
and16/16 complete-input positives. Final-epoch diagnostic timing improved but
still had27/72 strict misses and8/384 false accepts. Reject the candidate; do
not reinterpret zero false accepts with zero detections as successful wakeup.
Preflight's independent blank mean passed floating-point tolerance, not bitwise
equality; preserve the initial assertion failure and explicit report correction.

M4-KEYWORD-RESIDUAL-PROTOTYPE: A separate host-only candidate adds each causal
block's current input to its signed normalized temporal transform before ReLU6.
Keep the original default path and9814 parameters, fixed data/alignment/decoder
and development gates. Prove default compatibility, residual identity and signed
inhibition, causality and finite CTC gradients before one training. Parameter
counts are not measured C3 resources; failed screens do not enter firmware.

M4-KEYWORD-RESIDUAL-RESULT: One residual training completed; selected epoch33
has12/72 strict misses and5/384 false accepts. Retained12/43 misses and3/29
false, complete8/16 misses and1/8 false. All standalone gates failed.

M4-KEYWORD-TRIGGER-COMPOSITION: A fixed host-only composition uses each cached
CTC event's exact800+480*r available samples and the latest completed512-sample
SDK block. Original raw-hit scores must match the unchanged C gate exactly;
retain full prefix rows and original templates. Never use a future block,
favorable neighboring window or changed threshold. One24-case screen verified
18 original score vectors, rescued3 original misses, but changed acceptance
from11/16 with0/8 false to14/16 with1/8 false. Reject the composition; no C3
resource, wall-clock timing or M4 acceptance follows from these cached results.

M4-TEST-EFFORT: Reuse the authorized gpt-6-astra / low helper for fixed batch
tests and data audits. The parent keeps its existing effort for design and
meaningful failures. Scripts save detailed evidence locally and return compact
summaries; do not repeat unchanged long regressions. Cost savings are unmeasured.

M4-PHONETIC-PROVENANCE: Any phonetic-label experiment must identify the actual
source frontend and preserve raw data. Lexicon membership is not evidence of
multiword segmentation; AISHELL3, LL and SAPI cannot be assumed equivalent.
The current audit creates no training labels and changes no device behavior.

M4-PHONETIC-CTC: One host candidate projects source-specific pronunciation to
initial/final units without tones, preserving full original pronunciation and
all waveform/feature bytes. SAPI evidence must reproduce every original source
SHA and preserve its recorded IPA through phonetic conversion. The inverse may
be non-unique: normalize both source families with the same frozen canonical
mapping, preserving original IPA and all aliases. Never claim inverse IDs are
uniquely original engine IDs. The fixed h ai l e x in sequence, confidence0.5, causal clock,
no EOF flush, existing data/splits/alignment/optimizer and three development gates
remain explicit. Preflight default compatibility, projection, provenance failure
and every new CTC row budget before one training. No firmware adoption follows
from source reproduction or a successful test-process exit.

M4-PHONETIC-CTC-RESULT: Corrected source normalization passed its checks, but the
single complete40-epoch candidate failed every quality gate. Selected epoch23:
validation23/72 strict misses and16/384 false; retained35/43 misses and3/29false;
complete16/16 misses and0/8false. Reject it, preserve all artifacts and keep the
normal firmware. The earlier31-epoch run was stopped for a label defect and is
not a quality comparison. No change to M4 timing, heap, accuracy or scope follows.

M4-FFT-PAIR: The isolated static-mode2 candidate may share exact Q30 real FFT
unpack rotations between k and512-k after verifying the entire table symmetry.
Keep all1024 output slots, signed truncation, wide products/sums and original
conversion; handle k256 with real ar/2 and imaginary -ai/2. Compare all FFT
output/work bytes and full retained feature/score streams exactly under C11
ASan/UBSan. Static operation savings are not chip timing. No inference history,
input samples, pitch, thresholds, context, heap or end-to-end gate may be reduced.

M4-FFT-PAIR-RESULT: Host checks and16 C3 groups/4224 frames retain all outputs,
but same-input full-frame mean changes only21.300851 to21.290180ms (0.0501%).
Do not adopt this implementation or repeat it unchanged. The16ms requirement
still fails; preserve original app/context/clip, raw evidence and pending M4 gates.

M4-CLASSIC-OBSERVE: Isolated C11 wrappers may record the pinned WebRTC filterbank,
Gaussian calls and original16kHz VAD return. Preserve all arguments, outputs and
opaque state. Verify actual archive ABI and linked hooks; never substitute current
upstream constants for vendor values. Fixed buffers, closed-state enable control,
35 original complete inputs plus four observation-off controls, exact published
frame comparison and full Flash restoration precede interpretation. Observation
does not change classifier rules or establish normal acoustic acceptance.

M4-CLASSIC-OBSERVE-RESULT: One39-group/7671-frame device run preserves all prior
published decisions and four full observe-off/on controls. Actual vendor Gaussian
calls reconstruct every instantaneous decision on6809 original frames:1761 raw1,
1138 hangover,3910 zero. A single cached-score C endpoint counterfactual using
raw==1 loses supported-short-control and cuts clock-pause-control at2600ms,
before its verified matched last voice at4442.875ms. Reject it. Full4MiB restore
matches99fb93e1…, normal public state remains off, and M4 gates remain open.

M4-PREERASE-WINDOW12: A single isolated candidate may prepare12 sectors before
the ding instead of4, preserving paused ADC, complete model admission, per-sector
cancel/yield and the original post-ding sample clock. No heap, classifier, PCM,
codec, context or partition change. Verify committed data identity, cancellation
and erase/program failures; unused obsolete tail erasure may differ for short
clips. Measure extra start delay and finish delay together on the original eight
stimuli. Never infer a wall-time gain by subtracting cumulative blocked erase time.

M4-PREERASE-WINDOW12-RESULT: The only eight-case device run completes8/8 runtime
checks but fails independent acoustic acceptance: round2 has no accepted finish
template match, round6 has2.125729s voice-to-finish. Accepted-wake-to-record median
increases605 to1089ms; this includes initialization and ding, not an acoustic
keyword-end measurement. Different captured PCM prevents a pure causal estimate.
Do not adopt or rerun unchanged. Minimum heap53360B, all8 rearmed heaps58716B,
DMA loss0 and exact fresh/restored4MiB support only this bounded run. Existing
immediate-speech, keyword accuracy,100-round and M0/M3 gaps remain open.

M4-CONFIRMED-EVIDENCE: One offline candidate keeps the entire original onset and
neural confirmation prefix. Only after confirmation, combine instantaneous
WebRTC raw1 with both unchanged energy gates and the original1000ms silence timer,
without a second four-vote continuation stage. Compare original/current/candidate
for both score leads on35 complete inputs, including exact legacy70 streams and
all first-confirmation prefixes. No model inference, padding or device writes.

M4-CONFIRMED-EVIDENCE-RESULT: The210 C11/sanitizer replays on6809 source frames
preserve legacy70 and all29 first confirmations, but16 formerly terminated inputs,
including9 positive controls, no longer terminate within their original input.
Do not advance this candidate. EOF is not an infinite hang or an observed future
endpoint. For onset600-0 the earliest possible source-time bound2420ms minus
matched last voice432.625ms leaves12.625ms before2s, with future input/commit/cue
unmeasured; this is not a proven wall-time violation. All original gates stay open.

M4-CONTINUATION-BAND0: One offline candidate may exclude only instantaneous
decisions with band0 as the sole local vote and no original global vote, after
neural confirmation. Preserve the full confirmation prefix, vendor constants,
PCM and energy limits. Reuse the verified C11 binary on35 complete inputs with
two score leads; do not rerun references, add padding or infer future endpoints.

M4-CONTINUATION-BAND0-RESULT: All70 fixed replays exit0 and preserve confirmation
prefixes and score-lead semantics. Three positive controls remain unterminated
at original EOF. Reused source/capture hashes and old alignments show five
terminated onset controls retain known voice, while pause-control still ends
at7120ms after matched last voice4392.875ms, leaving2727.125ms in source time.
Do not advance this candidate to a long physical test. This is offline evidence,
not a measurement of the audible cue or a subjective listening approval.

M4-CONTINUATION-CONSENSUS: An isolated candidate may require the unchanged
global decision or two local votes excluding band0 after original confirmation.
Use original complete inputs, energy gates and quiet timer; validate every
adopted earlier endpoint against known voice. A transparent pinned-ABI C11
observer must retain call arguments/results and reject invalid observation
shapes. Observer correctness does not establish classifier quality or C3 timing.

M4-CONTINUATION-CONSENSUS-RESULT: The70 new replays preserve all confirmation
prefixes and eliminate EOF positives, but edge-current ends2440ms before its
full-reference-matched last voice3944.875ms (correlation0.8963), losing1504.875ms.
Reject this policy without device integration or additional band/count sweeps.
The observer passes6809 original frames and161664 recorded Gaussian calls under
C11 ASan/UBSan. Existing full-neural tail scores overlap speech-window scores;
they do not justify a new threshold or presumed live solution. Inspect actual
label provenance before any further model training. All original gates remain.

M4-SOURCE-SUPERVISION-AUDIT: Existing native targets are teacher predictions,
not speech truth. Independent source-activity weak supervision may be prepared
from the frozen generated TTS component and noise recipe, with explicit masked
uncertain boundaries and unchanged train/validation/retained separation. Treat
near-word KWS negatives as spoken audio, not VAD negatives. Do not label unknown
physical background quiet. Preserve original teacher arrays, waveforms and
failed cases. An acoustic source alignment or energy proxy is not human frame
annotation, and a new training experiment requires its own fixed plan and checks.

M4-SOURCE-SUPERVISION-FIT: One frozen weak-source experiment reuses all native41
causal features and the6041-parameter student. Preserve unknown frames in the
input/recurrent history; mask only their direct loss and exclude padded future
frames. Start from prior validation-selected epoch99 with seed9221,20x100 steps,
Adam lr0.0001, gradient norm1, and batch16 synthetic/8 aligned-positive physical/
4 declared development quiet. Select the minimum equal-two-domain mean clip BCE
on original validation identities; earliest tie. No retained-case selection or
parameter sweeps. All52 original retained sources stay present; unchanged15
control and two unfitted quiet gates are prerequisites, not device acceptance.

M4-SOURCE-SUPERVISION-FIT-RESULT: All three fixed check/train/evaluate processes
exit0, with exact source hashes and masked-gradient/causal checks passing.
Epoch20 is the frozen validation minimum (BCE0.0253734); retained52/12451frames
still miss11 of15 controls, while both unfitted quiet are rejected. Reject
deployment; do not extend epochs or select another threshold/checkpoint from
these failures. Low proxy loss and quiet rejection do not establish voice
preservation. Original firmware, data and all prior acceptance limits remain.

M4-SOURCE-START-DIAGNOSTIC: Compare59 fixed known-source inputs using original
history, only recurrent reset, and a real PCM/frontend restart on a256-sample
boundary. Preserve all original positive source blocks. Cold features must be
recomputed from the actual suffix; warm features with reset state are explicitly
counterfactual. The single batch retains40/40 synthetic and19/19 physical support
in all paths; it does not reproduce the retained short-control failure. Do not
start a new early-onset training run solely from the uncovered onset timestamps.
Keep original endpoint, cue, keyword, timing and resource acceptance gates.

M4-SHORT-SOURCE-ACQUISITION: Freeze four previously selected short-source voice
IDs (train1/5, validation3/11), original PCM gain1 at0/2/4/6seconds per stream,
playback gain0.6, and10seconds of manual capture. Freeze image identity and
observe actual ADC32k/output16k settings. Preserve the fresh complete Flash;
restore only its app slot and clip, then verify the entire4MiB and context.
Manual preparation has its own10second firmware allowance plus1second warmup;
the host acquisition wait is13seconds with35second capture-stream guards.
This does not relax immediate wake recording or2/4/8second endpoint limits.
Admit source-positive labels only after independent digital/headset/ADC matching;
leave unknown background unlabelled. Score each repeated word separately using
the frozen models and old0.4 diagnostic support rule, without retraining or
calling these manual source captures full wake/VAD acceptance.

M4-SHORT-SOURCE-RESULT: Corrected acquisition completes4/4 and restores the
fresh4MiB byte-for-byte. Independent matching admits3 streams; word-level audit
confirms11 words,10 supported by the unchanged weak-supervised model. One first
word is present at comparable amplitude but not detected. A single causal
startup-history initialization candidate still misses it (max5=0.0654), so it
is rejected before broader evaluation or deployment. Retain all original gates.

M4-ONSET-SOURCE-COVERAGE: Extend the original2301 source-supervised streams with
59 saved true-cold frontend streams and11 independently matched new physical
words. Keep unknown recorded background masked, original data intact, and the
original16/4 voice identity split. Reuse the6041-parameter causal model and masked
loss; start from source-supervised epoch20 and freeze one20x100-step seed9221
run. Select minimum equal-five-domain development-validation clip BCE, earliest
tie. These inspected development sources are not blind holdouts. Evaluate only
the selected checkpoint on52 original streams and3 complete new streams, keeping
original alignment and short-word scoring masks. Require all15 original controls,
zero accepts on the two unfitted quiet streams, and all11 matched new words at
the original0.4 support rule. Any failure rejects this candidate before deployment
or expansion. Preserve all endpoint, cue, keyword, timing and resource gates.

M4-ONSET-SOURCE-RESULT: The single check/train/evaluate sequence exits0 throughout;
all353 frozen source hashes remain unchanged. Selected epoch20 passes11/11 new
matched words and rejects both unfitted quiet inputs, but still misses5/15 original
controls (previously11/15). Reject deployment and expansion of this candidate;
retain the checkpoint and all failures without extending epochs or sweeping rules.

M4-RESIDUAL-SOURCE-EVIDENCE: Preserve the existing classic-aligned support gate,
but do not count a peak outside independently located source speech as retained
speech. Cached onset-550-1 passes that gate0.415413 yet its known speech-window
maximum is0.183416. The five remaining gate failures have full-clip max5 below0.4;
their planned source identity and actual device speech windows must be distinguished.
Freeze one five-positive/four-quiet-template correlation check with unchanged
400-3500Hz/10ms envelopes and0.75 rule. Keep uncertain recordings and original gates;
high template correlations on quiet controls invalidate automatic speech labelling.

M4-RESIDUAL-MATCH-RESULT: One nine-pair local waveform process exits0 with35
source hashes unchanged. All five complete planned-source references fit and
reach0.842-0.924 correlation; all four original quiet/template pairs stay below
0.75. Cached candidate support in temporary source-positive windows remains
below0.4. Preserve historical-identity and source-proxy limitations; no automatic
training labels, firmware deployment, threshold changes or control removal.

M4-RESIDUAL-CLEAN-SOURCE-RESULT: A single two-source diagnostic, with exactly two
native frontend streams and two current-checkpoint forwards, exits0 and preserves
all19 frozen source hashes. Clean source-window max5 is0.999621 for hao and0.999540
for dakai-deng, versus0.024923-0.074741 in the five stored recording windows.
This rules out lack of support for these exact clean inputs, not ADC faults or
processing-history effects. Do not alter the rejected candidate or original gates.

M4-RESIDUAL-HISTORY-RESULT: One fixed five-recording diagnostic exits0 with five
new frontend streams, ten model forwards and all33 source hashes unchanged.
Resetting only recurrent state while retaining the exact original stacked feature
inputs restores all five temporary source-window max5 scores to0.9831-0.9990;
fresh PCM-suffix frontend runs also support all five. Known positive frames remain
intact, warm scores are unchanged and none has a first-four-frame boundary issue.
The cuts use independently matched source positions unavailable during operation.
This identifies history-dependent suppression but is not a deployable reset policy,
a new accepted checkpoint or M4 acceptance. Preserve the preparation error and
original scores; no firmware, thresholds or endpoint/resource gates change.

M4-HISTORY-PREFIX-COVERAGE: Add140 continuous native-frontend inputs by placing
the final128 complete frames of each of the two declared training quiet recordings
before each of the70 existing cold speech sources. Reconstruct and verify actual
PCM; never concatenate feature arrays. Mark only the known prefix negative and
shift the original suffix target/mask unchanged. Preserve the16/4 voice split;
declare shared noise across train/validation and do not call it a blind holdout.
Retain2371 original streams. Freeze one6041-parameter fit from onset-source epoch20,
20x100 steps, seed9221, Adam1e-4, original batch28 plus2 clips from each of three
prefix domains. Select minimum equal-eight-domain development validation BCE,
earliest tie. Evaluate only that checkpoint on the original52 and three complete
short recordings:55 forwards, without resetting, cutting or recomputing features.
Require the original15 controls, zero accepts on two unfitted quiet streams,
all11 matched short words and all11 frozen independent source-positive windows.
Failure rejects deployment/expansion; no duration, threshold, epoch or gain sweeps.

M4-HISTORY-PREFIX-RESULT: The unique check/train/evaluate processes exit0 and
preserve371 source hashes. Eight-domain selection chooses epoch15. The55 forwards
support11/11 new words,13/15 old controls and8/11 independent source windows,
but falsely accept both unfitted quiet recordings. Reject this candidate before
deployment or expansion. Retain these regressions; do not tune thresholds,
increase epochs or remove controls to obtain a pass.

M4-FINITE-HISTORY-STRUCTURE: One isolated host model may replace unbounded LSTM
state with two causal residual temporal blocks. Keep the native41 frontend at
16ms and its original three-frame stacking. Project123 to24 channels; each block
uses Linear48-to24 on current/prior input, at delays1 and2, followed by residual
ReLU; use Linear24-to1 output. State stores the last1/2 inputs of each block,
not recurrent outputs. Expect5353 parameters,5280 MAC/output and72 state elements
per stream; these are structural counts, not measured C3 time or total RAM.
Each output depends on at most six native frames (96ms); frontend history is
separate. First prove chunk equivalence, causal gradients, fixed state size,
and independence from older native features using generated inputs only.
This stage does not authorize a new training sweep, deployment or relaxed gates.
