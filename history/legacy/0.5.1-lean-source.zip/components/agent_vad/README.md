# Experimental background confirmation

`AGENT_BACKGROUND_VERIFY` defaults to off. It is not the accepted M4 wake/VAD
implementation: current full-Agent pilots still miss quiet computation deadlines
and some acoustic keyword trials. See `docs/WAKE_VAD_REPORT.md`.

The default backend uses the original native-pitch TEN frontend and fixed8 model. Its
40 numerical/vendor/assembly inputs are hash-checked in `sources.lock.cmake`;
they come from the separately prepared, ignored TEN pitch-guards experiment.
The licenses in `licenses/` accompany those dependencies. No model tables or
third-party arithmetic are patched by this component. The separate, default-off
`AGENT_TEN_SKIP_PITCH` experiment removes only the pitch-estimator call from a
hash-checked build copy of AED; it supplies zero Hz while retaining original
weights, other features, allocations and the joint 0.4 endpoint cutoff. The
build watches pinned inputs so an incremental change forces revalidation.

True bypass matches masked original tensors/states on44 sources and passes
isolated C3 timing (maximum14.255ms), but both full-Agent no-pitch pilots still
miss quiet processing deadlines. It is not an accepted replacement. The separate
validation-selected0.395 threshold is research evidence and is not deployed.

All constructor allocations belong to one bounded group. An optional arena can
borrow the engine's disposable workspace while the audio owner holds both the
turn reservation and work mutex. Failed partial constructors are fully released;
inference cannot allocate. The worker must stop before its owner clears and
releases that workspace. Context capacities and persistent indexes are unchanged.

Only this archive's float helper references use the pinned RISC-V implementation.
Normal Agent/SDK helpers continue resolving to ROM; there is no executable-wide
link wrapping. The adapter's GCC aliasing option is confined to this component.

The ESP32-C3 integration requires audio, 1-kHz scheduling, and no other post-wake
verifier. It uses a 6144-byte task at priority4 and the idle keyword PCM buffers.
Source time, wall time and task CPU statistics are distinct. Flash PCM is read
only after successful publication; join precedes truncation/commit or reuse.

`hardware_tests/ten_background` tests lifecycle, all allocation failures, arena
boundaries and numerical replay with ASan/UBSan. Portable confirmation and clip
tests live in `host_tests`. Exact commands/configs, RAW recordings and automatic
app/clip restoration evidence are retained under the ignored
`artifacts/wake/ten-background-v*/` pilot directories. The optional host-only
window study in `tools/replay_ten_windows.py` is not integrated here.
