# ESP-Hi Agent

ESP32-C3 上的纯 C11 Agent：USB、Wi-Fi、DeepSeek 流式/非流式、灯控、Flash 历史、音乐合成、限时录音回放和有界动作链。出厂默认 DIRECT、HYBRID、thinking 关闭；设备保存用户选择的上下文模式。音频可在构建时关闭。

固件在 COM5 上运行。M0 基线通过了 100 轮真实 DeepSeek 调用、四灯实测及 Flash 压缩/软件重启恢复；实机 Gateway 联调和真实 USB 断电测试仍受外部条件限制，**M0 尚未标记完整验收通过**。后续音频扩展已通过主机 9 组 C 测试、5 组 mock HTTPS 测试、实机并发与 20 次音频启停，用户确认旋律正常、音量合适。分阶段证据各自保留。

M2 已完成实现与独立验收，首次验收版本为 **0.3.0-dev**。支持 128 轮历史候选、64/128 KiB 历史预算、检索/摘要、GPIO 所有权、动作链与 10 秒内录音回放；13 组主机测试和 100/100 轮真实 DeepSeek 并发测试通过。用户确认新 PDM 输出下人声清楚、沙沙声减轻，旋律和音量正常。需求、操作与证据见 [SPEC.md](SPEC.md)、[ACTIONLOG.md](ACTIONLOG.md)、[M2 规格](docs/CONTROL_CONTEXT_SPEC.md) 和 [测试报告](docs/TEST_REPORT.md)。

M3 **0.4.0-dev** 增加一分钟四声部器乐：电钢主旋律、低音、拨弦和轻鼓，支持力度、休止、衰减与段落编排。操作协议见 [音乐规格](docs/MUSIC_SPEC.md)，候选、原版/新版实录和独立验收状态见 [音乐测试报告](docs/MUSIC_REPORT.md)。此前的 M1/M2 听感反馈不等于 M3 已经主观验收。

当前为 **0.5.1-lean Agent 精简版**：GPIO4/5/10/20/21 支持输入、持续输出和 PWM，动作链可组合 GPIO、灯光和音频。删除重复乐谱解析与 SSE 缓冲，默认关闭实验校验器，保留官方 WakeNet9s / WebRTC VAD。按用户要求，语音阶段作为实验功能收尾，开机监听关闭。测量、边界和回滚见 [精简版报告](docs/AGENT_LEAN_REPORT.md)。

## 构建和烧录

Windows PowerShell，在项目目录执行：

```powershell
.\tools\bootstrap.ps1
.\tools\build_agent.ps1
# 已有本工程分区布局时，仅更新应用；首次迁移先按文档备份和核对布局。
.\tools\idf.ps1 -B build-agent-lean -p COM5 app-flash
.\tools\test_host.ps1
.\.toolchains\tools\python_env\idf6.1_py3.11_env\Scripts\python.exe tools/detect_port.py
```

SDK 固定 ESP-IDF v6.1，安装于项目 `.toolchains/`。主机测试使用已有 WSL Ubuntu GCC/CMake；自有 C 代码在 C11、ASan/UBSan 下验证。原固件完整备份和构建日志在忽略目录 `artifacts/`。工程不会执行整片擦除或 eFuse 写入。

上面的普通烧录命令适用于已完成 M2 分区迁移的设备。旧 M0/M1 设备必须先按 [迁移记录](docs/M2_MIGRATION.md) 备份、暂存和验证数据；新旧 ctx 区域重叠，直接覆盖分区表会失去旧布局入口。

## USB 使用

在项目目录打开交互串口，每次输入一句并按回车，看到 `@done` 后继续。`Ctrl + ]` 退出。

```powershell
.\.toolchains\tools\python_env\idf6.1_py3.11_env\Scripts\python.exe -X utf8 -m serial.tools.miniterm COM5 115200 --encoding UTF-8 --eol LF --echo --dtr 0 --rts 0
```

运行 `tools/provision_secret.ps1`，或直接运行项目 Python 下的 `tools/provision_secret.py --port COM5`。脚本优先读取 `WIFI_SSID`、`WIFI_PASSWORD`、`DEEPSEEK_API_KEY`；缺失时本机交互输入。按用户要求，密码和 Key **默认回显**；`--hidden` 可隐藏输入。空输入保留设备现有配置。设备确认消息不包含凭据。

```text
agent status
agent wifi status
agent chat 你好
agent chat --no-stream 请报告设备状态
把四颗灯调成红色
agent cancel
agent light get
agent light set 0 0 0
agent context stats
agent context budget 64
agent context budget 128
agent context search {"query":"之前约定的颜色","limit":3}
agent context summary
agent context mode LOCAL
agent context mode HYBRID
agent context remember color warm
agent context memory
agent context forget color
agent context sync
agent context compact
agent route GATEWAY
agent route DIRECT
agent reboot
```

普通文本默认为对话；`@done` 表示轮次结束，`@error <agent_err_t>` 表示失败。`agent context init` 仅用于第一次迁移，在备份后初始化专用分区；已初始化的存储拒绝重复初始化。损坏日志不会触发自动格式化。

## 音乐和麦克风

可以直接输入：`创作并播放一分钟明快器乐，128 BPM、32小节，带主旋律、低音、琶音和轻鼓，先有前奏，中段发展，最后回到主音。请复用乐句，每个伴奏乐句写满32个十六分音符时值。` LLM 用 `device.audio.play_song` 传入完整乐谱，设备异步合成播放。复杂构思可先用文字讨论，再要求播放；无效或超限的乐谱不会执行。

旧的 `play_score` 仍支持单声部正弦/三角短旋律，最多 64 音、30 秒。默认音量 80。下面的电脑命令不经网络即可重播保存的乐谱（先退出 miniterm，释放串口）：

```powershell
.\.toolchains\tools\python_env\idf6.1_py3.11_env\Scripts\python.exe -X utf8 tools/music_link.py examples/music/sunny_walk.json --port COM5
```

```text
agent audio status
agent audio song get
agent audio volume 80
agent audio play {"bpm":120,"wave":"sine","notes":[[60,4],[64,4],[67,4],[72,4]]}
agent audio stop
agent mic on
agent mic status
agent mic off
agent audio capture 5000
agent audio replay
```

音符对是 `[MIDI音高, 时长]`，时长以十六分音符为单位，4 表示一拍，音高 0 表示休止。`agent audio stop` 直接停止声音；`agent cancel` 同时取消当前对话和音乐。播放期间仍可使用 USB 和灯控。

麦克风默认关闭。`mic on` 只测音量；`audio capture` 另外录制 0.1–10 秒单声道 PCM 到独立 Flash 区，成功提交后可回放。新的录音替换上一段；中途取消或断电不会把半段录音当成有效文件。回放进行本地语音滤波与频谱降噪，可能改变音色，原始 PCM 不被修改。没有语音识别，也不上传录音。`mic_valid` 和 `mic_age_ms` 区分当前声音与旧读数。开着扬声器时，麦克风会受到播放声音影响。

## 动作链与长历史

可以在 USB 终端输入“先亮黄灯三秒，再录音五秒，最后亮蓝灯回放”。LLM 可调用 `device.control.run` 提交整份计划；设备先校验引脚、资源和时间，再异步执行。`accepted` 是已接单，`done` 才是执行结束。

```text
agent control capabilities
agent control validate {"steps":[{"op":"light","r":20,"g":12,"b":0},{"op":"wait","ms":3000},{"op":"capture","ms":5000},{"op":"light","r":0,"g":0,"b":20},{"op":"replay"}]}
agent control run {"steps":[{"op":"light","r":20,"g":12,"b":0},{"op":"wait","ms":3000},{"op":"capture","ms":5000},{"op":"light","r":0,"g":0,"b":20},{"op":"replay"}]}
agent control status
agent control cancel
```

最多 32 步、8 次重复、60 秒。结束/取消时恢复计划拥有的灯、输出和麦克风状态。资源冲突返回 `busy`。GPIO0/1/9 为只读按钮；GPIO4/5/10（原 LCD）及20/21（原身体接口）开放读写和两路 PWM。这些脚可能连着板上外设。LED8、麦克风2、功放3、PDM6/7 通过专用驱动控制，USB18/19、Flash12–17、未确认的11保持保护。完整语法见 [计划 schema](protocol/device-plan.schema.json)。

直接 GPIO 设置会保持到下次设置或重启；计划中的设置会在结束或取消时恢复：

```text
agent control capabilities
agent gpio get {"pin":10}
agent gpio set {"pin":10,"mode":"output","value":1}
agent gpio set {"pin":10,"mode":"pwm","hz":1000,"duty":500}
agent gpio set {"pin":10,"mode":"input"}
```

PWM 为10–5000Hz，占空比0–1000，500表示50%。直接调用在任何计划活动期间返回busy。
也可以直接对话：“查询GPIO能力，让GPIO10拉高200毫秒，再恢复，灯光同步闪一下。”
新工具及参数见 [GPIO 协议](protocol/device-gpio.schema.json)。

上下文分区为 2 MiB，双区轮换后活动区为 1 MiB，正文容量还需扣除元数据。模型可见历史按 64/128 KiB **字节预算**选择最近最多 128 个完整轮次，并从 Flash 分块发送；不会一次申请同样大小的 RAM，也不是 DeepSeek 的 token 上限。`context stats` 显示 `prompt_turns`、`prompt_bytes`、`trimmed_turns` 和完整请求的 `request_bytes`。更早的保留事件可按关键词/事件 ID 检索；摘要带原始来源序号，可追溯。

详细音频接口和 M1 历史证据见 [音频规格](docs/AUDIO_SPEC.md)，M2 验收见 [控制与上下文规格](docs/CONTROL_CONTEXT_SPEC.md)。

## 本机 Gateway

```powershell
.\.toolchains\tools\python_env\idf6.1_py3.11_env\Scripts\python.exe tools/mock_gateway.py --san <电脑局域网IP>
```

测试 CA、服务器证书、随机 token 和 SQLite 数据库生成到 `.local/mock/`，不进入 Git。让电脑和设备处于互通网络，然后用配置脚本的 `--gateway-url https://<电脑IP>:8443 --gateway-ca .local/mock/ca.pem` 写入公共 CA；`AGENT_GATEWAY_TOKEN` 从本机 token 文件读取。不要把 Key、token 或私钥粘贴到日志或聊天中。

mock 的确定性响应支持四工具交错 SSE 与 `turn_id` 续轮。完整接口、限制和故障注入见 [Gateway 协议](docs/GATEWAY_PROTOCOL.md)。此服务器用于开发验证。

尚未配置 Gateway 时继续本地保存，`sync_error: config` 表示同步配置缺失，不影响 DIRECT 对话。Flash 容量有限，未同步事件不会被压缩丢弃，空间耗尽时返回 `full`。音频占用期间上下文整区擦除返回 `busy`，应停止音频后再压缩；普通追加日志仍可并发。

## 项目结构

| 路径 | 内容 |
|---|---|
| `core/` | ABI、注册表、事件/资源/工具轮次策略、通用 JSON 辅助 |
| `plugins/llm/` | 可移植对话执行、请求、消息、SSE、传输契约 |
| `plugins/context/` | NOR 日志、上下文事件、去重/LWW、HTTPS 同步 |
| `plugins/tool/` | 19 个工具的固定表与参数校验；关闭音频后 12 个 |
| `plugins/audio/` | 乐谱合成、音量计算、提交式 PCM、滤波与降噪 |
| `plugins/control/` | 资源所有权、直接操作仲裁、动作链解析与执行 |
| `platform/espidf/` | FreeRTOS、USB、NVS、Wi-Fi、验证 TLS、Flash 适配 |
| `platform/posix/` | 带 fsync 的 NOR 文件模拟 |
| `boards/esp_hi/` | WS2812、可选 PDM/ADC 音频；GPIO18/19 留给 USB |
| `host_tests/`、`tools/` | 主机/实机验证、bootstrap、mock、配置脚本 |
| `protocol/`、`docs/` | 协议 schema、移植/安全/硬件/构建/验收资料 |

音频是 M0 之后增加的扩展。自由语音转文字、语音合成、完整云端音乐生成、LCD、舵机、EDA 扩展和生产云服务未包含在当前实现中。OpenWrt、杰里与本地模型运行时保留契约，未声明可运行移植。

## 唤醒后录音（M4 调试中）

USB 输入 `agent wake on`，对设备说“嗨乐鑫”。听到“叮”后说话，设备在判断说话结束并成功保存录音后发出下降音调的“咻”。结束提示目标为说完后 2 秒内，部分已测场景仍有延迟或漏唤醒，暂不承诺稳定触发。一次最长录音 10 秒；唤醒后 4 秒没有检测到说话应退出本轮，不发完成音。每轮会替换设备上的单个录音槽。

`agent audio replay` 回放录音，`agent wake status` 查看状态，`agent wake off` 关闭监听。`agent cancel` 也会停止本轮并关闭监听。对话和播放期间会暂停唤醒检测，正常结束后自动恢复。开机默认不监听，需要再次启用。

此版本仍在验证近音词误唤醒、噪声下漏识别和长时间运行；尚未标记 M4 稳定验收通过。这个功能只生成录音，不识别人声内容，也不会把录音发送给 DeepSeek。实录与完整限制见 [本轮交付说明](docs/M4_HANDOFF.md)及 [M4 测试记录](docs/WAKE_VAD_REPORT.md)。
