param([string]$BuildDir = 'build-agent-lean')
$ErrorActionPreference = 'Stop'
$taskProject = Split-Path -Parent $PSScriptRoot
Push-Location $taskProject
try {
    # Separate configuration; force research-only features off even in a reused cache.
    & "$PSScriptRoot/idf.ps1" -B $BuildDir -D "SDKCONFIG=$BuildDir/sdkconfig" `
        -D 'SDKCONFIG_DEFAULTS=sdkconfig.defaults;sdkconfig.lean.defaults' `
        -D AGENT_MIC_OVERSAMPLE=ON -D AGENT_MIC_ATTEN_DB=12 -D AGENT_WAKE_MODEL=wn9s_hilexin `
        -D AGENT_KEYWORD_VERIFY=OFF -D AGENT_VOICE_VERIFY=OFF -D AGENT_BACKGROUND_VERIFY=OFF `
        -D AGENT_KEYWORD_ACTIVITY=OFF -D AGENT_KEYWORD_TRACE=OFF -D AGENT_KEYWORD_PCM=OFF `
        -D AGENT_CAPTURE_WARM_PDM=OFF -D AGENT_PACKED_CLIP=OFF -D AGENT_HEAP_WATCH=OFF `
        -D AGENT_BUSY_TRACE=OFF -D AGENT_WIFI_AUDIO_DIAGNOSTICS=OFF -D AGENT_TEN_SKIP_PITCH=OFF build
    $taskResult = $LASTEXITCODE
} finally { Pop-Location }
exit $taskResult
