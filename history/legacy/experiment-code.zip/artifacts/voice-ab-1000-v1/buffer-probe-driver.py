import subprocess,time,json,hashlib
from pathlib import Path
b=Path('artifacts/voice-ab-1000-v1');rig=b/'rig-v1.json';assert hashlib.sha256(rig.read_bytes()).hexdigest()=='5a09ebb955549e5d7abebb36ca5b8fb25042169ab74754d9d6066ba0d85f6787'
sources=json.loads(rig.read_text())['source_sha256'];assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in sources.items())
out=b/'buffer-probe-v1';out.mkdir(exist_ok=False);records=[]
def save(): (out/'driver.json').write_text(json.dumps(dict(source_sha256=sources,processes=records),indent=2))
for buf in [500,8000]:
 jobs=[];start=time.monotonic()
 for backend in ['raw','loopback']:
  name=f'{backend}-{buf}';wav=out/(name+'.wav')
  args=['.local/loopback-python/Scripts/python.exe','-X','utf8','hardware_tests/voice_ab/buffered_capture.py','--backend',backend,'--actual-buffer-ms',str(buf),'--inject-stall-s','4.5']
  args+=['--output',str(wav),'--seconds','10','--mode','raw','--mono'] if backend=='raw' else [str(wav),'--seconds','10']
  stdout=(out/(name+'.stdout')).open('xb');stderr=(out/(name+'.stderr')).open('xb');r=dict(argv=args,start=time.time());p=subprocess.Popen(args,stdout=stdout,stderr=stderr);r['pid']=p.pid;records.append(r);jobs.append((p,r,stdout,stderr));save()
 for p,r,stdout,stderr in jobs:
  try:r['exit_code']=p.wait(timeout=max(.1,30-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:
   r['timeout']=True;p.terminate();r['exit_code']=p.wait();r['end']=time.time();save();raise
  r['end']=time.time();stdout.close();stderr.close();save()
 print('buffer',buf,'exits',[r['exit_code'] for p,r,o,e in jobs],flush=True)
