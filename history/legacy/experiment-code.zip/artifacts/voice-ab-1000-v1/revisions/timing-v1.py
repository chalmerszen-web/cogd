"""One frozen acoustic software block; external supervisor owns flash/restore.
Never runs on import. A trial directory is a permanent attempt, never retried.
"""
import argparse,json,hashlib,time,wave,math,array
from pathlib import Path
from contextlib import ExitStack
from serial_link import connect
from hardware_m2 import Device
from record_speaker import Recorder
from record_loopback import LoopbackRecorder
from wake_trial import output,export
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def seconds(p):
    with wave.open(str(p),'rb') as w:return w.getnframes()/w.getframerate()
def native_window(meta,start,end):
    """Map a QPC-seconds interval to contiguous saved native samples."""
    assert meta['complete'] and meta['rate']==48000
    spans=[]
    for block in meta['blocks']:
        count=block.get('written',block['frames'])
        t=block['qpc_100ns']/1e7
        lo=max(start,t);hi=min(end,t+count/meta['rate'])
        if hi>lo:
            spans.append((block['at']+round((lo-t)*meta['rate']),block['at']+round((hi-t)*meta['rate']),lo,hi))
    assert spans and abs(spans[0][2]-start)<1/meta['rate'] and abs(spans[-1][3]-end)<1/meta['rate']
    assert all(abs(a[3]-b[2])<1/meta['rate'] and a[1]==b[0] for a,b in zip(spans,spans[1:]))
    return spans[0][0],spans[-1][1]

def quality(case,before,states,playback):
    final=states[-1];negative=case['category']=='negative'
    transitions=[(a['request_start'],b['response_end']) for a,b in zip(states,states[1:]) if a['state']=='recording' and b['state']!='recording']
    delay=None
    if playback and transitions:
        delay=[v-playback['finished_relative'] for v in transitions[-1]]
    return dict(wake_miss=not negative and final['wakes']==before['wakes'],
        false_accept=negative and final['wakes']>before['wakes'],
        completed_delta=final['completed']-before['completed'],empty_delta=final['empty']-before['empty'],
        dma_delta=final['dma_lost']-before['dma_lost'],device_error=final['error'],
        source_played=bool(playback),no_command_published=case['category']=='no_command' and final['completed']>before['completed'],
        speech_not_played=case['category'] in ('short','pause','speech') and not playback,
        speech_source_failed=False,
        speech_played_but_no_clip=case['category'] in ('short','pause','speech') and bool(playback) and final['completed']==before['completed'],
        endpoint_after_source_file_seconds_interval=delay,
        premature_before_source_file_finished=bool(delay and delay[1]<0),
        endpoint_note='USB poll interval vs actual playback completion, not last voiced sample or cue',
        forced_or_timeout=final['error']=='timeout' or final.get('reason') in (3,4),
        failed_state=final['state']=='failed',cancelled=None,cancel_scope='not_in_design')

def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--manifest',type=Path,required=True);a.add_argument('--output',type=Path,required=True)
    a.add_argument('--block',type=int,required=True);a.add_argument('--port',default='COM5')
    args=a.parse_args();plan=read(args.manifest)
    for f,h in plan['source_sha256'].items():assert sha(f)==h,f
    block=plan['blocks'][args.block];assert block['index']==args.block
    args.output.mkdir(parents=True,exist_ok=True)
    events=(args.output/'events.jsonl').open('a',encoding='utf8')
    def event(kind,**data):
        events.write(json.dumps(dict(at=time.time(),kind=kind,**data),ensure_ascii=False)+'\n');events.flush()
    with connect(args.port) as link:
        d=Device(link,args.output/'device.json')
        event('block_start',block=block,manifest_sha256=sha(args.manifest))
        try:
            for pair in block['pairs']:
                case=plan['pairs'][pair];folder=args.output/('%s-%03d'%(block['version'],pair))
                if folder.exists():
                    prior=read(folder/'result.json') if (folder/'result.json').exists() else {}
                    if prior.get('complete') and prior.get('manifest_sha256')==sha(args.manifest):continue
                    raise RuntimeError('Unfinished attempt requires review, cannot replay')
                folder.mkdir()
                r=dict(pair=pair,version=block['version'],case=case,complete=False,manifest_sha256=sha(args.manifest),states=[],resources=[],processes=[],acoustic=dict(premature_end=None,endpoint_delay_s=None,reason='Requires independent source/cue alignment of retained RAW; never inferred from host polling'))
                def save():(folder/'result.json').write_text(json.dumps(r,indent=2)+'\n')
                save();event('trial_start',pair=pair)
                processes=[]
                try:
                    if not d.get('wake status')['enabled']:d.run('agent wake on')
                    before=d.wait('wake status',lambda x:x['state']=='listening',10);r['before']=before;r['status_before']=d.get('status');r['audio_before']=d.get('audio status')
                    with ExitStack() as stack:
                        stack.enter_context(LoopbackRecorder(folder/'computer-output.wav',45))
                        stack.enter_context(Recorder(folder/'external.wav',45,raw=True))
                        r['pre_silence_host_start']=time.monotonic();r['pre_silence_qpc_start']=time.perf_counter();time.sleep(1)
                        start=time.monotonic();r['host_start']=start
                        current=output(Path(case['keyword']),.6,folder/'keyword-output.json');processes.append(current)
                        deadline=start+(seconds(case['keyword'])+2 if case['category']=='negative' else 18)
                        spoken=False
                        while time.monotonic()<deadline:
                            request_start=time.monotonic()-start
                            state=d.get('wake status');response_end=time.monotonic()-start
                            r['states'].append(dict(t=response_end,request_start=request_start,response_end=response_end,**state))
                            if len(r['states'])%5==0:r['resources'].append(dict(t=time.monotonic()-start,status=d.get('status'),audio=d.get('audio status')))
                            if state['state']=='recording' and not spoken and current.poll() is not None:
                                spoken=True
                                if case['utterance']:
                                    current=output(Path(case['utterance']),.6,folder/'speech-output.json');processes.append(current)
                                    r['speech_request_s']=time.monotonic()-start
                            save()
                            if state['wakes']>before['wakes'] and state['state'] in ('listening','cooldown','off','failed'):break
                            time.sleep(.15)
                        request_start=time.monotonic()-start
                        r['final']=d.get('wake status');response_end=time.monotonic()-start
                        r['states'].append(dict(t=response_end,request_start=request_start,response_end=response_end,**r['final']))
                        r['audio']=d.get('audio status');r['status_after']=d.get('status');r['heap_scope']='min_heap is cumulative within current boot, not per-trial'
                        for process in processes:
                            code=process.wait(timeout=20);r['processes'].append(code)
                            if code:
                                r['source_failed']=True;save();raise RuntimeError('Playback failed')
                        time.sleep(.6)
                    for meta in ['external.wasapi.json','computer-output.loopback.json']:
                        value=read(folder/meta)
                        assert value['complete'] and value.get('rate',value.get('native_rate'))==48000
                    with wave.open(str(folder/'external.wav'),'rb') as w:
                        assert w.getsampwidth()==2 and w.getnchannels()==1
                        lo,hi=native_window(read(folder/'external.wasapi.json'),r['pre_silence_qpc_start'],r['pre_silence_qpc_start']+1)
                        w.setpos(lo);pcm=array.array('h',w.readframes(hi-lo))
                        assert len(pcm)==hi-lo
                        r['pre_silence_samples']=[lo,hi]
                    mean=sum(pcm)/len(pcm);r['pre_silence_rms']=math.sqrt(sum((x-mean)**2 for x in pcm)/len(pcm))
                    r['background_flag']=r['pre_silence_rms']>72
                    f=r['final'];playback=None
                    if (folder/'speech-output.json').exists():
                        playback=read(folder/'speech-output.json')
                        playback['finished_relative']=playback['finished']-r['host_start']
                        r['actual_speech_playback']=playback
                    r['outcome']=quality(case,before,r['states'],playback)
                    if playback:
                        from analyze_wake_timing import envelope,align
                        reference,last=envelope(case['utterance']);external,_=envelope(folder/'external.wav')
                        found=align(reference,external,0,seconds(folder/'external.wav')-seconds(case['utterance']))
                        r['acoustic']=dict(source_match=found,source_last_abs40_s=last,
                            matched=bool(found and found['correlation']>=.75),
                            limit='External envelope source match; cue delay needs independent cue match, not USB end')
                    # Observe auto-rearm before any export/off/on intervention.
                    try:r['automatic_rearm']=d.wait('wake status',lambda x:x['state']=='listening',3);r['automatic_rearm_ok']=True
                    except Exception:r['automatic_rearm_ok']=None;r['automatic_rearm_status']='late_or_unknown_3s'

                    observed=d.get('wake status');r['before_export_state']=dict(observed_at=time.monotonic(),**observed)
                    if observed['state']=='listening':r['automatic_rearm_listening_observed_at']=time.monotonic()
                    r['dma_before_recovery']=observed.get('dma_lost')
                    if f['completed']>before['completed'] and r['audio']['clip_ready']:
                        d.run('agent wake off');d.wait('wake status',lambda x:x['state']=='off',3)
                        export(d,folder/'device.wav');r['export_interrupted_listening']=True
                    if d.get('wake status')['state'] not in ('listening','cooldown'):
                        d.run('agent wake off');d.run('agent wake on')
                    try:r['rearm']=d.wait('wake status',lambda x:x['state']=='listening',10);r['rearm_ok']=True;r['dma_after_recovery']=r['rearm'].get('dma_lost');r['dma_counter_zero_after_recovery']=r['dma_after_recovery']==0
                    except Exception as e:r['rearm_ok']=False;r['rearm_error']=repr(e)
                    r['complete']=True;save();event('trial_end',pair=pair,outcome=r['outcome'])
                    if not r['rearm_ok']:raise RuntimeError('Rearm unavailable; block paused')
                except BaseException as e:
                    r['infrastructure_error']=repr(e);save();event('paused',pair=pair,error=repr(e));raise
        finally:
            for command in ['agent wake off','agent audio stop','agent mic off']:
                try:d.run(command)
                except Exception as e:event('cleanup_error',command=command,error=repr(e))
            event('block_closed');events.close()
if __name__=='__main__':main()
