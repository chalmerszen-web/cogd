import hashlib,json,subprocess,time,shutil
from pathlib import Path
root=Path.cwd();b=root/'artifacts/voice-ab-1000-v1';p=b/'frozen-v3.json'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='ebbcdcf88a2945e89e5a6306033b5b30f38664d997d5f18f11e76d5c5270a09b'
plan=json.loads(p.read_text());checks={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in plan['source_sha256']}
assert checks==plan['source_sha256']
argv=[str(root/'.toolchains/tools/python_env/idf6.1_py3.11_env/Scripts/python.exe'),'-X','utf8','hardware_tests/voice_ab/run_study.py','--manifest','artifacts/voice-ab-1000-v1/frozen-v3.json','--session','formal-v1']
p=b/'formal-v1-driver.json';assert not p.exists();assert not (b/'formal-v1').exists()
r=dict(argv=argv,start=time.time(),source_sha256=checks,free_bytes_start=shutil.disk_usage(root).free)
def save():p.write_text(json.dumps(r,indent=2))
with (b/'formal-v1-stdout.txt').open('xb') as out,(b/'formal-v1-stderr.txt').open('xb') as err:
 proc=subprocess.Popen(argv,stdout=out,stderr=err);r['pid']=proc.pid;save();print('supervisor PID',proc.pid,flush=True)
 r['exit_code']=proc.wait()
r['end']=time.time();r['free_bytes_end']=shutil.disk_usage(root).free;save();print('exit',r['exit_code'],flush=True)
