/* Application bounds around the unmodified ESP-SR VAD trigger. The Boolean
 * already includes upstream onset and 1000-ms silence hysteresis; adding the
 * Agent's voting/energy/end-delay a second time would bias this comparison. */
#include "endpoint.h"
#include <string.h>

agent_err_t agent_endpoint_init(agent_endpoint_t *e,unsigned end,unsigned wait,unsigned maximum)
{
    if(!e || !end || !wait || maximum<wait) return AGENT_ERR_ARGUMENT;
    *e=(agent_endpoint_t){.end_ms=end,.wait_ms=wait,.maximum_ms=maximum};
    return AGENT_OK;
}

agent_endpoint_state_t agent_endpoint_feed(agent_endpoint_t *e,bool speech)
{
    if(e->state>=AGENT_EP_DONE) return e->state;
    e->elapsed_ms+=AGENT_VAD_FRAME_MS;
    if(speech) { e->state=AGENT_EP_SPEECH; e->speech_ms+=AGENT_VAD_FRAME_MS; }
    else if(e->state==AGENT_EP_SPEECH) e->state=AGENT_EP_DONE;
    if(e->state==AGENT_EP_WAIT && e->elapsed_ms>=e->wait_ms) e->state=AGENT_EP_NO_SPEECH;
    if(e->state<AGENT_EP_DONE && e->elapsed_ms>=e->maximum_ms) e->state=AGENT_EP_LIMIT;
    return e->state;
}

/* Meter only. This does not gate the baseline VAD or keyword decisions. */
bool agent_activity_feed(agent_activity_t *a,const int16_t *pcm,size_t n,bool learn,bool voice,bool speaking)
{
    (void)learn; (void)speaking;
    uint64_t sum=0;
    for(size_t i=0;i<n;++i) sum+=pcm[i]<0?-(int32_t)pcm[i]:pcm[i];
    a->level=n?(unsigned)(sum/n):0;
    return voice;
}
void agent_endpoint_verify(agent_endpoint_t *e,bool confirmed) { (void)e; (void)confirmed; }
bool agent_endpoint_support(agent_endpoint_t *e,bool strong) { (void)e; (void)strong; return false; }
void agent_endpoint_cancel(agent_endpoint_t *e) { if(e->state<AGENT_EP_DONE) e->state=AGENT_EP_CANCELLED; }
