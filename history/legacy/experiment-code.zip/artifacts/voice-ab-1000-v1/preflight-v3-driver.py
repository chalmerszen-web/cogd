import sys,json,time,subprocess,hashlib
from pathlib import Path
ROOT=Path.cwd(); B=ROOT/'artifacts/voice-ab-1000-v1'
sys.path.insert(0,str(ROOT/'tools'))
from serial_link import connect
from hardware_m2 import Device
assert hashlib.sha256((B/'frozen-v3.json').read_bytes()).hexdigest()=='ebbcdcf88a2945e89e5a6306033b5b30f38664d997d5f18f11e76d5c5270a09b'
def save(p,d):p.write_text(json.dumps(d,indent=2))
def config(label):
 p=B/(label+'-config.json');assert not p.exists()
 with connect('COM5') as link:
  link.timeout=.015;d=Device(link,p)
  for cmd in ['wake off','audio stop','mic off','audio volume 80','wifi modem 0','wake threshold 550','wake gain 1']:d.run('agent '+cmd)
  d.report['status']=d.wait('status',lambda s:s['wifi'],60)
  d.report['wake']=d.get('wake status');d.report['audio']=d.get('audio status');d.report['passed']=True;d.save()
def run(label,argv):
 p=B/(label+'-driver.json');assert not p.exists()
 r=dict(argv=argv,start=time.time());save(p,r)
 with (B/(label+'-stdout.txt')).open('xb') as out,(B/(label+'-stderr.txt')).open('xb') as err:
  proc=subprocess.Popen(argv,stdout=out,stderr=err);r['pid']=proc.pid;save(p,r)
  r['exit_code']=proc.wait()
 r['end']=time.time();save(p,r);print(label,r['exit_code'],flush=True)
 assert r['exit_code']==0,r
py=str(ROOT/'.local/loopback-python/Scripts/python.exe')
for version,block,count in [('a',0,1),('b',1,5)]:
 label='preflight-'+version+'-v3'
 assert not (B/label).exists()
 if version=='b':
  assert not (B/'preflight-b-flash.log').exists()
  run('preflight-b-v3-switch',[str(ROOT/'.toolchains/tools/python_env/idf6.1_py3.11_env/Scripts/python.exe'),'-X','utf8','hardware_tests/voice_ab/flash_manager.py','switch','--image','build-coarse-profile-v1-device/esp_hi_agent.bin','--sha256','d9bd6975088b733d7c2f2976a4698f9c744de34a354a5b5929599df0ff68c953','--label','preflight-b-flash'])
  time.sleep(3)
 config(label)
 run(label,[py,'-X','utf8','tools/voice_ab_1000.py','--manifest',str(B/'frozen-v3-preflight.json'),'--output',str(B/label),'--block',str(block)])
 results=list((B/label).glob('*-*/result.json'));assert len(results)==count
 for p in results:
  r=json.loads(p.read_text());assert r['complete']
  for name in ['external.wasapi.json','computer-output.loopback.json']:assert json.loads((p.parent/name).read_text())['complete']
 print(label,'capture complete',flush=True)
