import hashlib,json,subprocess,time,shutil
from pathlib import Path
root=Path.cwd();b=root/'artifacts/voice-ab-1000-v1';rig=b/'rig-v1.json'
assert hashlib.sha256(rig.read_bytes()).hexdigest()=='5a09ebb955549e5d7abebb36ca5b8fb25042169ab74754d9d6066ba0d85f6787'
sources=json.loads(rig.read_text())['source_sha256'];assert all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in sources.items())
i=json.loads((b/'interruption-02.json').read_text());assert all(hashlib.sha256((b/i['preserved']/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in i['records'])
assert not (b/'formal/block-12/A-340').exists()
argv=[str(root/'.toolchains/tools/python_env/idf6.1_py3.11_env/Scripts/python.exe'),'-X','utf8','hardware_tests/voice_ab/run_buffered_study.py','--manifest','artifacts/voice-ab-1000-v1/frozen-v3.json','--session','formal-v1-resume2','--start-block','12']
p=b/'formal-v1-resume2-driver.json';assert not p.exists();assert not (b/'formal-v1-resume2').exists()
r=dict(argv=argv,start=time.time(),source_sha256=sources,free_bytes_start=shutil.disk_usage(root).free)
def save():p.write_text(json.dumps(r,indent=2))
with (b/'formal-v1-resume2-stdout.txt').open('xb') as out,(b/'formal-v1-resume2-stderr.txt').open('xb') as err:
 proc=subprocess.Popen(argv,stdout=out,stderr=err);r['pid']=proc.pid;save();print('supervisor PID',proc.pid,flush=True);r['exit_code']=proc.wait()
r['end']=time.time();r['free_bytes_end']=shutil.disk_usage(root).free;save();print('exit',r['exit_code'],flush=True)
