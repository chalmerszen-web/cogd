"""Private bounded on-device regression; run immediately after app-flash."""
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'tools'))
from serial_link import connect, receive_until

out = Path(__file__).parent / 'boot-clock.json'
report = {'passed': False, 'polls': [], 'visual_verified': False}
def save():
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')

link = None
deadline = time.monotonic()+30
try:
    while link is None and time.monotonic()<deadline:
        try:
            link = connect('COM5')
        except OSError:
            time.sleep(.1)
    assert link is not None
    link.timeout=.05
    def command(text, query=False, timeout=8):
        link.reset_input_buffer()
        link.write((text+'\n').encode('utf8'))
        raw = receive_until(link, b'}\r\n' if query else (b'@done',b'@error',b'@ok'), timeout).decode('utf8','replace')
        if query:
            return next(json.loads(v) for v in raw.splitlines() if v.startswith('{'))
        return raw
    while time.monotonic()<deadline:
        status = command('agent status',True)
        report['polls'].append(status)
        if status['wifi'] and status['nvs']:
            break
        time.sleep(.1)
    assert status['version']=='0.6.2-repair' and status['wifi']
    report['before_display'] = command('agent display status',True)
    assert report['before_display']['mode']=='off'
    report['prompt']='agent chat --no-stream 请在屏幕显示北京时间，每秒刷新并持续显示，使用白底黑字。'
    report['response']=command(report['prompt'],timeout=150)
    save()
    assert '@done' in report['response'] and '@error' not in report['response'], report['response']
    assert '@tool device_display_set' in report['response']
    report['clock_wait_exercised']='@wait clock' in report['response']
    time.sleep(2)
    report['after_display']=command('agent display status',True)
    report['after_status']=command('agent status',True)
    report['context']=command('agent context stats',True)
    state=report['after_display']
    assert state['mode']=='clock' and state['ready'] and state['frames'] and state['error']=='ok'
    assert state['foreground']==0 and state['background']==65535
    assert report['after_status']['min_heap']>=48*1024
    report['passed']=True
finally:
    if link is not None:
        link.close()
    save()
print(json.dumps({k:v for k,v in report.items() if k!='polls'},ensure_ascii=False,indent=2))
