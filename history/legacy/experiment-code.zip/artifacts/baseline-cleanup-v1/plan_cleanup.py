"""Create a literal, workspace-only deletion manifest after baseline verification."""
from pathlib import Path
import ast
import hashlib
import json
import os
import shutil

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).parent


def main():
    assert (WORK/'promotion.json').is_file()
    for path in ('build-agent/esp_hi_agent.bin','build-agent-noaudio/esp_hi_agent.bin'):
        assert (ROOT/path).is_file()
    assert '100% tests passed' in (WORK/'host.log').read_text(encoding='utf-8-sig')
    assert '100% tests passed' in (WORK/'host-noaudio.log').read_text(encoding='utf-8-sig')
    for name in ('compile_commands.json','build.ninja'):
        text=(ROOT/'build-agent'/name).read_text().replace('\\','/')
        assert not any(s in text for s in ('/hardware_tests/','/artifacts/wake/','/_ref/','/build-ten-'))
    current=ROOT/'artifacts/baseline/current';current.mkdir(exist_ok=True,parents=True)
    for name in ('esp_hi_agent.bin','esp_hi_agent.elf','esp_hi_agent.map','sdkconfig','compile_commands.json'):
        shutil.copy2(ROOT/'build-agent'/name,current/name)
    shutil.copy2(ROOT/'build-agent/partition_table/partition-table.bin',current/'partition-table.bin')
    shutil.copy2(ROOT/'build-agent-noaudio/esp_hi_agent.bin',current/'audio-off.bin')

    keep_tools=set('''analyze_music.py audit_project.py bootstrap.ps1 bootstrap_speech.ps1 build_agent.ps1
check_nvs_preserved.py detect_port.py generate_music_tables.py hardware_m2.py idf.ps1 mock_gateway.py
music_link.py pack_wake_model.py provision_secret.ps1 provision_secret.py record_speaker.py record_wasapi.py
record_loopback.py requirements-loopback.txt requirements.txt serial_link.py test_device.py test_host.ps1
usb_command.py verify_application_identity.py verify_dependencies.py wave_play.py'''.split())
    # Preserve local imports of retained scripts, not just their visible entry points.
    pending=list(keep_tools)
    while pending:
        name=pending.pop();p=ROOT/'tools'/name
        assert p.is_file(),name
        if p.suffix!='.py':continue
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8-sig'))):
            modules=([node.module] if isinstance(node,ast.ImportFrom) and node.module else
                     [n.name for n in node.names] if isinstance(node,ast.Import) else [])
            for module in modules:
                local=module.split('.')[0]+'.py'
                if (ROOT/'tools'/local).is_file() and local not in keep_tools:
                    keep_tools.add(local);pending.append(local)
    keep_docs=set('''AGENT_LEAN_REPORT.md ARCHITECTURE.md AUDIO_CLIP_FORMAT.md AUDIO_SPEC.md BASELINE.md
BUILD_REPORT.md CLEANUP_REPORT.md conflicts.json CONTEXT_PROTOCOL.md CONTROL_CONTEXT_SPEC.md
GATEWAY_PROTOCOL.md HARDWARE_AUDIT.md hardware_facts.json HARDWARE_FACTS.md MUSIC_REPORT.md MUSIC_SPEC.md
pinmap.csv PORTING.md SECURITY.md TEST_PLAN.md TEST_REPORT.md VOICE_AB_1000_REPORT.md VOICE_AB_1000_SPEC.md
WAKE_VAD_SPEC.md'''.split())
    targets=[]
    for p in ROOT.iterdir():
        if p.is_dir() and (p.name=='build' or p.name.startswith('build-')):targets.append(p)
    targets += [ROOT/'_ref',ROOT/'hardware_tests']
    targets += [p for p in (ROOT/'.local').iterdir() if p.name not in ('loopback-python','mock')]
    targets += [p for p in (ROOT/'artifacts').iterdir() if p.name not in ('baseline','baseline-cleanup-v1','voice-ab-1000-v1')]
    targets += [p for p in (ROOT/'tools').iterdir() if p.is_file() and p.name not in keep_tools]
    targets += [p for p in (ROOT/'docs').iterdir() if p.is_file() and p.name not in keep_docs]
    targets += [ROOT/n for n in ('sdkconfig','sdkconfig.old','sdkconfig.lean.defaults') if (ROOT/n).exists()]
    for folder in ('core','plugins','platform','boards','components','host_tests','tools'):
        targets += list((ROOT/folder).rglob('__pycache__'))
    unique=sorted(set(p.resolve() for p in targets),key=lambda p:(len(p.parts),str(p)))
    unique=[p for p in unique if not any(q in p.parents for q in unique)]
    entries=[];total=0;files=0
    with (WORK/'deletion-files.jsonl').open('x',encoding='utf8') as log:
        for p in unique:
            assert p!=ROOT and p.is_relative_to(ROOT) and p.exists()
            assert not p.is_symlink() and not (p.stat().st_file_attributes&0x400),p
            count=size=0
            items=p.rglob('*') if p.is_dir() else [p]
            for f in items:
                st=f.lstat()
                assert not (st.st_file_attributes&0x400),f
                if not f.is_file():continue
                count+=1;size+=st.st_size
                log.write(json.dumps(dict(path=f.relative_to(ROOT).as_posix(),bytes=st.st_size))+'\n')
            entries.append(dict(path=str(p),relative=p.relative_to(ROOT).as_posix(),files=count,bytes=size,directory=p.is_dir()))
            files+=count;total+=size
    payload=dict(root=str(ROOT),authorized_by='User requested removal of obsolete debug materials after adopting the tuned baseline',
        targets=entries,files=files,bytes=total,keep_tools=sorted(keep_tools),keep_docs=sorted(keep_docs),
        free_bytes_before=shutil.disk_usage(ROOT).free)
    (WORK/'deletion-plan.json').write_text(json.dumps(payload,indent=2),encoding='utf8')
    print(json.dumps(dict(targets=len(entries),files=files,bytes=total,keep_tools=len(keep_tools),keep_docs=len(keep_docs))))


if __name__=='__main__':main()
