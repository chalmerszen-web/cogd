"""Assemble the accepted baseline and report the completed, literal cleanup."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).parent
CURRENT=ROOT/'artifacts/baseline/current'

def read(name):return json.loads((WORK/name).read_text(encoding='utf-8-sig'))
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def package():
    for name in ('esp_hi_agent.bin','esp_hi_agent.elf','esp_hi_agent.map','sdkconfig','compile_commands.json'):
        shutil.copy2(ROOT/'build-agent'/name,CURRENT/name)
    shutil.copy2(ROOT/'build-agent/partition_table/partition-table.bin',CURRENT/'partition-table.bin')
    files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
    # Only current project material; ignored backups, recordings and credentials cannot enter.
    assert not any(p.startswith(('.local/','.toolchains/','artifacts/','build-','build/')) for p in files)
    with zipfile.ZipFile(CURRENT/'source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name in sorted(set(files)):
            p=ROOT/name
            if p.is_file():z.write(p,name)
    with zipfile.ZipFile(CURRENT/'source.zip') as z:assert z.testzip() is None
    manifest={p.name:dict(bytes=p.stat().st_size,sha256=digest(p)) for p in CURRENT.iterdir() if p.is_file() and p.name!='manifest.json'}
    write(CURRENT/'manifest.json',dict(version='0.6.0-upgrade',files=manifest))

def inventory():
    plan=read('deletion-plan.json'); deleted=read('deletion-result.json')
    assert deleted['complete'] and deleted['targets']==len(plan['targets'])
    rows=[json.loads(line) for line in (WORK/'deleted.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    assert len(rows)==len(plan['targets']) and all(x['deleted'] for x in rows)
    assert {x['path'] for x in rows}=={x['path'] for x in plan['targets']}
    supplement=read('deletion-supplement.json')
    assert supplement['deleted'] and not Path(supplement['path']).exists()
    regenerated={'build-agent','build-host','tools/__pycache__','host_tests/__pycache__'}
    for x in plan['targets']:
        assert x['relative'] in regenerated or not Path(x['path']).exists(),x['relative']
    result=[]
    for p in ROOT.iterdir():
        count=size=0
        if p.is_dir():
            for folder,dirs,files in os.walk(p):
                for name in files:
                    f=Path(folder)/name
                    count+=1;size+=f.stat().st_size
        else:count=1;size=p.stat().st_size
        result.append(dict(path=p.name,files=count,bytes=size,directory=p.is_dir()))
    value=dict(at=datetime.now().astimezone().isoformat(),root=str(ROOT),
        files=sum(x['files'] for x in result),bytes=sum(x['bytes'] for x in result),
        free_bytes=shutil.disk_usage(ROOT).free,rows=sorted(result,key=lambda x:x['bytes'],reverse=True),
        deletion_verified=True,regenerated_builds=['build-agent','build-host'],
        regenerated_python_caches=[x for x in sorted(regenerated) if x.endswith('__pycache__') and (ROOT/x).exists()])
    write(WORK/'inventory-after.json',value)
    return value

def baseline():
    flash=read('flash-validation.json');nv=read('nvs-validation.json');smoke=read('device-smoke/report.json');size=read('size.json')
    assert flash['passed'] and nv['passed'] and smoke['complete'] and not smoke['cleanup_errors']
    final={x['command']:json.loads(x['response']) for x in read('device-final.json')}
    status=final['agent status'];ctx=final['agent context stats'];audio=final['agent audio status'];wake=final['agent wake status']
    assert status['version']=='0.6.0-upgrade' and not status['busy']
    assert not audio['playing'] and not audio['mic_requested'] and not wake['enabled']
    assert ctx['events']==smoke['context_before']['events'] and ctx['used']==smoke['context_before']['used']
    app=(ROOT/'build-agent/esp_hi_agent.bin').stat().st_size
    dram=next(x['used'] for x in size['layout'] if x['name']=='DRAM')
    text=f'''# 当前升级基线：0.6.0-upgrade

2026-09-15 已安装到 COM5 的 ESP-HI / ESP32-C3 revision v0.4。用户接受同板1000次对比后，采用调优B的语音链路并保留精简Agent的GPIO和内存改进。本项目称为升级版，不代表Espressif官方发布或认证。

## 来源与合并内容

语音来源为冻结的 coarse-profile-v1 B，应用SHA256：
`d9bd6975088b733d7c2f2976a4698f9c744de34a354a5b5929599df0ff68c953`。
板级采集、TEN worker、关键词门、音频源/端点、packed clip、阶段时钟，以及B实际使用的fixed/model/pitch优化均按哈希迁入正式源码。模型、库和许可证位于 `third_party/`，自有内核位于 `components/agent_vad/kernel/`；131个迁入文件有来源清单。

保留0.5.1-lean的GPIO4/5/10/20/21输入输出/PWM、计划资源仲裁、取消恢复、SSE复用请求缓冲和直接解析乐谱。主任务栈保留6144B，B原镜像为5120B；版本/入口和构建路径也改变。因此本次集成镜像与B不是同一个二进制，1000次数据只归属原B。

固定ESP-IDF v6.1；ESP-SR `efa8d907c6d457cd0f99dae6c6b493412d3078d4`，TEN-VAD `22a3bcd4509d0faaa8eef4881e8af5f39c178950`。TEN包含已接受的C3优化，不能称为未经改动的上游。`tools/build_agent.ps1`选择完整语音配置；音频关闭单独构建。

## 本次集成验证

| 检查 | 结果与证据 |
|---|---|
| 音频开启IDF构建 | 通过；清理后从空目录重新构建，`build-after-cleanup.log` |
| 音频关闭IDF构建 | 通过，969,360B，`build-noaudio.log`；此次清理后未重复关闭配置 |
| 主机音频开启 | 24/24，ASan/UBSan；清理后24/24复核，`host-after-cleanup-02.log` |
| 主机音频关闭 | 12/12，ASan/UBSan，`host-noaudio.log` |
| 当前固定依赖 | 89个文件SHA校验；编译输入不再引用旧实验目录 |
| 有界实机检查 | {len(smoke['commands'])}条USB命令通过：GPIO/PWM、禁止引脚、计划冲突/取消恢复、麦克风音量、短音播放、监听启停 |
| 应用更新 | 仅app-flash；完整4MiB读回中的应用与构建逐字节一致 |
| 持久化数据 | 启动区/分区表、NVS、PHY、上下文、原录音全部逐字节不变；68个NVS活动记录通过CRC校验，序号预留7040不变 |

本次没有再跑声学1000次或云端长循环；实机检查只覆盖集成和基本行为，没有录下新的完整唤醒指令，TEN完整录音链路的声学结果仍引用原B。首次IDF尝试暴露早期依赖扫描中默认ON的问题，已改为选项默认OFF、构建入口显式ON；失败保留在build.log。清理后主机首次启动使用旧PowerShell被策略拒绝，未进入测试；随后以正常入口运行24组通过，没有更改系统策略。

## 当前空间和状态

| 项目 | 当前值 |
|---|---:|
| 物理Flash | 4,194,304B / 4MiB |
| 应用二进制 | {app:,}B / {app/1048576:.3f}MiB |
| 1.5MiB应用槽剩余 | {1572864-app:,}B / {(1572864-app)/1024:.2f}KiB |
| 链接静态DRAM已用 | {dram:,}B |
| 有界检查后的空闲堆 / 最低堆 | {smoke['after']['free_heap']:,}B / {smoke['after']['min_heap']:,}B |
| 最终重启后空闲堆 | {status['free_heap']:,}B |
| 上下文分区 / 活动区 | {ctx['partition_bytes']:,}B / {ctx['bank_size']:,}B |
| 活动区已用 / 剩余 | {ctx['used']:,}B / {ctx['bank_size']-ctx['used']:,}B |
| 事件 / 待同步 / 最近轮次候选 | {ctx['events']} / {ctx['pending']} / {ctx['recent_turns']} |
| 历史请求字节预算 | {ctx['history_budget']:,}B |
| 录音区 / 原录音时长 | 458,752B / {audio['clip_ms']}ms |

分区内空间不能直接当成可分配RAM。应用比原B增加3,456B，链接静态DRAM比B减少6,114B；不同测试负载的最低堆不作等条件性能比较。2MiB上下文和128KiB历史预算未缩减，也没有删除设备中的任何历史。

设备最终为DIRECT / {ctx['mode']}，Wi-Fi连接，音量{audio['volume']}，灯熄灭；监听、麦克风、播放和计划关闭，GPIO10恢复输入，串口已释放。

## 验收边界

原1000次实验A/B各500。在已知样本中误唤醒8/100→0/100，无指令误录22/100→2/100，触及10秒上限19→0。唤醒成功率98.25%→98.75%未证明明显改善；录音启动中位数增加251ms。完整限制见 [对比报告](VOICE_AB_1000_REPORT.md)。采纳此实验基线不改写原M0外网Gateway/真实断电未完成，或原M3主观音乐、M4历史未达目标。

## 交付、清理与恢复

当前源代码是仓库正常目录；构建入口为 `tools/build_agent.ps1`。当前产物在 `artifacts/baseline/current/`，其中manifest.json列出应用、ELF、map、配置、分区和源码包哈希。原A/B、B来源归档和原lean完整恢复备份在 `artifacts/baseline/reference/`；备份包含本机私有状态，继续排除Git。恢复时从完整备份提取所需应用区域，按当前布局只更新应用；不要整片覆盖用户数据。

当前应用SHA256：`{flash['app_sha256']}`。
更新前完整Flash：`{flash['full_before_sha256']}`。
更新后完整Flash：`{flash['full_after_sha256']}`。

[清理报告](CLEANUP_REPORT.md)列出实际删除和剩余目录。本次日志根目录为 `artifacts/baseline-cleanup-v1/`，包括promotion.json、删除明细、主机/构建日志、device-smoke/report.json、flash-validation.json、nvs-validation.json及device-final.json。完整1000次正式证据仍位于 `artifacts/voice-ab-1000-v1/`。
'''
    (ROOT/'docs/BASELINE.md').write_text(text,encoding='utf8')

def cleanup_report(inv):
    plan=read('deletion-plan.json');d=read('deletion-result.json')
    supplement=read('deletion-supplement.json')
    d['targets']+=1;d['files']+=supplement['files'];d['logicalBytes']+=supplement['bytes']
    sizes={x['path']:x for x in inv['rows']}
    descriptions={'.toolchains':'ESP-IDF 6.1、RISC-V编译器和项目Python，继续构建所需',
        'artifacts':'当前基线/回滚材料、1000次完整证据、本次清理与验证记录',
        'build-agent':'清理后新建的唯一完整固件构建', 'build-host':'清理后新建的主机测试构建',
        'third_party':'当前语音模型、C3库、TEN/RVfplib/cJSON源及许可证',
        'managed_components':'当前ESP-IDF固定依赖', '.local':'仅loopback-python录音/分析环境和mock证书/数据库',
        'components':'当前关键词和TEN确认组件', 'plugins':'LLM、上下文、工具、控制、音频',
        'boards':'ESP-HI板级驱动', 'platform':'ESP-IDF与POSIX适配', 'core':'C11插件/消息/策略内核',
        'main':'固件入口', 'host_tests':'24/12组主机测试及当前音频渲染辅助',
        'tools':'30个必要工具文件，其中22个Python脚本', 'docs':'24份当前规格、协议、硬件事实和必要历史报告',
        'protocol':'JSON协议schema', 'examples':'一份一分钟乐曲示例', '.git':'本地Git元数据，未提交或推送'}
    rows=[]
    for name in descriptions:
        x=sizes.get(name)
        if x:rows.append(f"| `{name}/` | {x['files']:,} | {x['bytes']/1e6:.2f} MB | {descriptions[name]} |")
    old_builds=sum(x['relative'].startswith('build') for x in plan['targets'])
    free_delta=inv['free_bytes']-plan['free_bytes_before']
    text=f'''# 基线清理完成记录

2026-09-15，按用户“只保留当前基线相关材料”要求实际删除，并完成清理后的全新构建、主机测试及设备应用更新。当前为0.6.0-upgrade，详情见 [BASELINE](BASELINE.md)。

## 已删除

共 **{d['targets']}个文件/目录目标、{d['files']:,}个文件、{d['logicalBytes']:,}B（{d['logicalBytes']/1e9:.2f}GB / {d['logicalBytes']/1073741824:.2f}GiB）**。包括：

- {old_builds}个构建目录（含清理前的验证构建），现在仅重新生成build-agent与build-host。
- 原参考仓库 `_ref/`、研究硬件工程 `hardware_tests/`；当前所需源码、模型和许可证已先迁出并校验。
- 废弃唤醒/VAD候选、训练数据和训练/诊断环境、旧音乐采集与调优中间件、旧日志和重复备份。
- 过时研究报告、一次性训练/声学搜索脚本和Python缓存。当前依赖闭包保留，原对比源码也有归档。

先校验当前来源、两个固件构建、24/12组主机测试、A/B镜像和回滚备份，再执行删除。所有目标是本工作区内已核对的绝对路径；使用PowerShell原生逐项删除，先排除重解析链接。每个目标删除后验证不存在并记录时间。清理后重新生成的两个构建目录和当前工具运行缓存单独标明，不冒充未删除。

删除前可用磁盘空间{plan['free_bytes_before']/1e9:.2f}GB；清理及重新构建后的观测为{inv['free_bytes']/1e9:.2f}GB，净增加{free_delta/1e9:.2f}GB。这是全盘瞬时值，会受压缩、系统及其他任务写入影响；删除逻辑字节数与实际磁盘增量分开记录。

## 还剩什么

本次目录快照为 **{inv['bytes']/1e9:.2f}GB（{inv['bytes']/1073741824:.2f}GiB）**，包含工具链和证据；正常业务源码只是其中一小部分。目录大小是文件逻辑长度，不是NTFS分配占用；快照后的报告更新有少量差异。

| 目录 | 文件数 | 逻辑大小 | 保留原因 |
|---|---:|---:|---|
'''+ '\n'.join(rows)+'''

根目录还保留README、SPEC、ACTIONLOG、原始需求报告、CMake/依赖锁、当前分区表和配置。ACTIONLOG按时间保留历史，不把过去失败改写为通过；其旧中间产物路径已不保证存在。正式历史报告已加此说明。

`artifacts/`现在仅有三个目录：

- `baseline/`：当前固件/ELF/map/config/source及manifest；原A/B、接受B来源、基准源文件归档和一份lean完整回滚镜像。
- `voice-ab-1000-v1/`：1000个正式结果、500配对、录音无损归档、两次无效采集及完整审计。直接支持所选基线，完整保留。
- `baseline-cleanup-v1/`：本次来源迁移、删除计划/逐文件清单/执行记录、清理前源码、更新前后Flash、构建和设备验证。

原始录音、备份、构建和凭据继续排除Git；未提交或推送。未删除设备上下文或凭据，未更改分区布局。

## 验证和审计入口

- `artifacts/baseline-cleanup-v1/deletion-plan.json`、`deletion-files.jsonl`：批准范围内的完整计划和逐文件尺寸。
- `deletion-supplement-plan.json`、`deletion-supplement.json`：收尾发现的单份旧M4状态快照及其删除记录，已计入总数。
- `deleted.jsonl`、`deletion-result.json`：实际完成记录；`inventory-after.json`：剩余目录快照。
- `promotion.json`、`third_party/manifest.json`：迁入来源及固定依赖；89个哈希校验通过。
- `build-after-cleanup.log`、`host-after-cleanup-02.log`：不存在旧目录时重新构建及24/24测试通过。音频关闭构建和12/12测试也有保留结果。
- `source-audit.json`：C11及边界/私有产物检查；`flash-validation.json`与`nvs-validation.json`：应用正确、原数据不变。
- `device-smoke/report.json`、`device-final.json`：56条有界USB检查与最终设备状态。

本次清理和基线整理已收尾；没有重新展开训练、长时间声学调优或新一轮1000次测试。
'''
    (ROOT/'docs/CLEANUP_REPORT.md').write_text(text,encoding='utf8')

if __name__=='__main__':
    baseline()
    # First inventory for the report, then package the final docs and take a final snapshot.
    inv=inventory();cleanup_report(inv);package()
    inv=inventory();cleanup_report(inv)
    # Repackage once with the final inventory numbers; snapshot precision is documented.
    package()
    print(json.dumps(dict(total_bytes=inv['bytes'],files=inv['files'],free_bytes=inv['free_bytes'],app_sha256=digest(CURRENT/'esp_hi_agent.bin'))))
