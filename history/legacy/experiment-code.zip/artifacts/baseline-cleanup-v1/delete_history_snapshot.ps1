$ErrorActionPreference = 'Stop'
$snapshotFile = 'C:\Users\PC\Documents\ChatGPT\cogd\docs\history\M4_STATE_BEFORE_MIXED_SOURCE_20260914.md'
$snapshotDirectory = 'C:\Users\PC\Documents\ChatGPT\cogd\docs\history'
$snapshotEvidence = 'C:\Users\PC\Documents\ChatGPT\cogd\artifacts\baseline-cleanup-v1'
# Narrow cleanup: one known file, then its empty directory, no recursive deletion.
$snapshotInfo = Get-Item -LiteralPath $snapshotFile -Force
if ($snapshotInfo.PSIsContainer -or ($snapshotInfo.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected snapshot type' }
if ((Get-Item -LiteralPath $snapshotDirectory -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse directory' }
$snapshotChildren = @(Get-ChildItem -LiteralPath $snapshotDirectory -Force)
if ($snapshotChildren.Count -ne 1 -or $snapshotChildren[0].FullName -ne $snapshotFile) { throw 'Unexpected history contents' }
$snapshotRecord = @{path=$snapshotDirectory; relative='docs/history'; files=1; bytes=$snapshotInfo.Length; file=$snapshotFile; reason='Obsolete pre-mixed-source M4 state snapshot'; at=(Get-Date -Format o)}
$snapshotRecord | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $snapshotEvidence 'deletion-supplement-plan.json') -Encoding utf8
Remove-Item -LiteralPath 'C:\Users\PC\Documents\ChatGPT\cogd\docs\history\M4_STATE_BEFORE_MIXED_SOURCE_20260914.md' -Force
Remove-Item -LiteralPath 'C:\Users\PC\Documents\ChatGPT\cogd\docs\history'
if (Test-Path -LiteralPath $snapshotDirectory) { throw 'Cleanup incomplete' }
$snapshotRecord.deleted=$true
$snapshotRecord | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $snapshotEvidence 'deletion-supplement.json') -Encoding utf8
