"""Write the supported baseline entry points; historic action log stays append-only."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
DOCS={
'README.md':'''# ESP-HI Agent 0.6.0-upgrade

ESP32-C3 上的纯 C11 Agent。当前项目基线合并了 1000 次同板实验中的 B 版语音链路，以及精简版的 GPIO、流式缓冲和内存改进。“升级版”是本项目名称，不是 Espressif 官方发布的整机固件。

支持 USB 文本对话、Wi-Fi、DeepSeek 流式/非流式、灯光、GPIO/PWM、有界动作链、Flash 上下文、四声部音乐、录音回放和本地唤醒。语音只负责唤醒后保存录音，没有转写或语音上传。监听默认关闭。

正式入口：[项目规格](SPEC.md)、[基线说明](docs/BASELINE.md)、[1000 次对比](docs/VOICE_AB_1000_REPORT.md)、[清理与剩余文件](docs/CLEANUP_REPORT.md)、[行动日志](ACTIONLOG.md)。对比结果属于冻结的 B 镜像；合并后的 0.6.0 单独记录构建及有界回归，不冒充再次完成 1000 次实验。原 M0 实机 Gateway/真实断电项目仍未完成。

## 构建

在项目目录的 PowerShell 中执行：

```powershell
.\\tools\\bootstrap.ps1
.\\tools\\build_agent.ps1
.\\tools\\test_host.ps1
```

ESP-IDF v6.1 位于项目私有 `.toolchains/`。必要语音库、模型和许可证位于 `third_party/`；构建不依赖旧实验目录。`tools/verify_dependencies.py` 校验固定依赖。主机测试使用已有 WSL Ubuntu GCC/CMake，启用 C11、ASan/UBSan。

已经采用本工程当前分区布局的设备，只更新应用：

```powershell
.\\tools\\idf.ps1 -B build-agent -p COM5 app-flash
```

此命令不用于旧 M0/M1 布局迁移。当前布局为 1.5 MiB 应用、2 MiB 上下文、448 KiB 录音。更新前保存完整 Flash；不用整片擦除。音频关闭构建：`tools/build_agent.ps1 -BuildDir build-agent-noaudio -NoAudio`。

## 对话

```powershell
.\\.toolchains\\tools\\python_env\\idf6.1_py3.11_env\\Scripts\\python.exe -X utf8 -m serial.tools.miniterm COM5 115200 --encoding UTF-8 --eol LF --echo --dtr 0 --rts 0
```

输入一句话并回车，看到 `@done` 后继续。`Ctrl + ]` 退出并释放串口。普通文字就是对话，例如“把四颗灯调成红色”。

```text
agent status
agent wifi status
agent chat 你好
agent chat --no-stream 请查询设备状态
agent cancel
agent light set 0 0 0
agent context stats
agent context budget 128
agent context mode LOCAL
```

`tools/provision_secret.ps1` 优先读取本机 `WIFI_SSID`、`WIFI_PASSWORD`、`DEEPSEEK_API_KEY`，缺少时交互输入。按用户要求密码和 Key 默认回显；空输入保留已有配置。不要用诊断日志脚本传凭据。

## GPIO 和动作链

LLM 可查询能力，再读写 GPIO4/5/10/20/21，或设置两路 10–5000 Hz PWM。GPIO0/1/9 为只读按钮；灯、音频、USB 和 Flash 引脚由对应驱动管理。开放引脚有原板用途，接外设前核对 [硬件表](docs/HARDWARE_FACTS.md)。

```text
agent control capabilities
agent gpio get {"pin":10}
agent gpio set {"pin":10,"mode":"output","value":1}
agent gpio set {"pin":10,"mode":"pwm","hz":1000,"duty":500}
agent gpio set {"pin":10,"mode":"input"}
```

占空比 0–1000，500 为 50%。直接设置持续到更改或重启。动作链支持最多 32 步、8 次重复、60 秒，结束/取消恢复之前状态；冲突返回 `busy`。例：“GPIO10 拉高 200 毫秒，再恢复，同时闪一下灯。”完整参数见 [GPIO schema](protocol/device-gpio.schema.json) 和 [动作链 schema](protocol/device-plan.schema.json)。

## 音乐和本地录音

可对话：“创作并播放一分钟明快器乐，128 BPM、32 小节，有主旋律、低音、琶音和轻鼓。复用乐句，中段变化，最后落稳。”设备校验乐谱后异步合成，USB、灯光和取消继续可用。固定曲谱在 `examples/music/sunny_walk.json`，可用 `tools/music_link.py` 上传。

```text
agent audio status
agent audio volume 80
agent audio stop
agent mic on
agent mic status
agent mic off
agent audio capture 5000
agent audio replay
agent wake on
agent wake status
agent wake off
```

启用监听后说“嗨乐鑫”，听到“叮”再说话。结束并成功保存后发出下降提示音。单段最长 10 秒；唤醒后无指令有 4 秒等待边界。监听可由 `wake off` 或 `cancel` 关闭。播放/对话期间暂停检测。`mic on` 只测音量，手动录音及唤醒录音会替换单个本地录音槽；半段数据不会被当成有效录音，旧录音不保证保留。

调优版在本次已知样本中减少了误触发、误录和长等待，同时启动录音更慢。不是普适识别率承诺。操作与边界见 [唤醒说明](docs/WAKE_VAD_SPEC.md)、[音乐协议](docs/MUSIC_SPEC.md)、[录音格式](docs/AUDIO_CLIP_FORMAT.md)。

## 上下文和 Gateway

2 MiB 上下文分区采用双区轮换，每个活动区 1 MiB，正文还要扣除元数据。最近最多 128 个完整轮次，历史请求默认 64 KiB、可设 128 KiB，从 Flash 分块发送，不占同等大小 RAM。更早的保留事件可检索、摘要；这不是模型 token 数量。出厂默认 DIRECT/HYBRID，已配置设备保留其模式和预算。

```text
agent context search {"query":"之前约定的颜色","limit":3}
agent context summary
agent context remember color warm
agent context memory
agent context sync
```

开发 Gateway 使用 `tools/mock_gateway.py --san <电脑局域网IP>`，证书和数据库保存在 `.local/mock/`。详见 [协议](docs/GATEWAY_PROTOCOL.md)。没有 Gateway 时继续保留未同步事件；空间耗尽会明确返回 `full`，不会自动丢弃待同步历史。

## 目录

| 路径 | 用途 |
|---|---|
| `core/`、`plugins/` | 可移植 Agent、LLM、上下文、工具、控制、音频 |
| `platform/`、`boards/`、`main/` | ESP-IDF / POSIX 适配和板级入口 |
| `components/`、`third_party/` | 当前语音链路、固定模型和第三方许可证 |
| `host_tests/`、`tools/` | 主机检查、构建、USB、配置、录音与 mock |
| `protocol/`、`examples/`、`docs/` | 协议、示例、当前说明和必要历史报告 |
| `artifacts/baseline/` | 当前固件、参考固件、源码归档和回滚材料，不进 Git |
| `artifacts/voice-ab-1000-v1/` | 完整 1000 次实验及两次设施中断证据，不进 Git |
| `artifacts/baseline-cleanup-v1/` | 本次迁移、删除清单、构建和设备验证，不进 Git |

OpenWrt、杰里和本地模型运行时仅有移植契约。LCD、舵机、完整 ASR/TTS、生产云服务不在当前基线内。
''',
'SPEC.md':'''# ESP-HI Agent 当前项目规格

基线：**0.6.0-upgrade**，2026-09-15。用户接受 1000 次同板对比后，选用调优 B 的语音链路作为项目升级基线，并要求删除无用调试材料、保留当前代码和必要证据。本规格取代此前继续训练、候选探索和重复声学验收的安排。历史过程保留在 ACTIONLOG；本项目版本不代表 Espressif 官方发布。

## 要求和边界

| ID | 当前要求 | 验证方式 |
|---|---|---|
| BASE-01 | 自有固件 C11，静态版本插件，ABI major 4；ESP-IDF 位于适配层 | 实际编译命令和主机测试 |
| BASE-02 | 保留 B 的 WakeNet9s、关键词筛选、TEN 后台确认、采集/端点和紧凑录音 | 来源哈希、同板对比证据、移植回归 |
| BASE-03 | 保留 lean 的 GPIO/PWM、资源仲裁、请求缓冲复用和乐谱解析简化 | GPIO/计划/SSE 主机及设备检查 |
| BASE-04 | USB 文本、Wi-Fi、DeepSeek DIRECT/GATEWAY、流式/非流式和工具续轮 | 原有实现及分阶段验收，失败如实保留 |
| BASE-05 | 上下文分区和预算不缩减，NVS/录音保留，常规更新仅应用 | 更新前后完整 Flash 比对 |
| BASE-06 | 删除旧构建、废弃候选、训练环境和中间材料；无运行源码依赖实验目录 | 逐项删除清单、依赖校验、清理后全新构建 |
| BASE-07 | 保留当前二进制、源码、第三方许可证、对比数据和回滚备份 | 哈希、归档完整性与目录清单 |
| BASE-08 | 更新当前操作入口，有限回归后收尾，不新增研究和 1000 次重复测试 | 基线/清理报告和行动日志 |

## 架构和资源预算

内核负责注册、事件、消息和资源策略。platform、transport、LLM、context、USB、tool 通过类型明确的函数表连接。主循环管理状态，单个网络 worker 处理一个对话；状态和取消可用。语音和网络复用大工作区，以资源所有权排斥冲突。

| 资源 | 上限 |
|---|---:|
| 普通 USB 输入 | 2 KiB |
| 单记录/请求工作缓冲 | 24 KiB |
| 流式发送的完整 HTTP 请求 | 160 KiB |
| 单 SSE 事件 / 回答 | 6 KiB / 8 KiB |
| 工具参数合计 | 4 KiB |
| 每个回复工具数 / 工具续轮 | 4 / 4 |
| 历史候选 / 历史预算 | 128 个完整轮次 / 默认 64 KiB、可设 128 KiB |
| 上下文 Flash | 2 MiB，双 1 MiB 区轮换 |
| 应用槽 / 录音区 | 1.5 MiB / 448 KiB |
| 控制计划 | 32 步、8 次重复、60 秒 |
| 手动/唤醒录音 | 最长 10 秒 |
| 四声部音乐 | 16 乐句、128 存储音符、32 编排段、75 秒 |

CRC 追加日志、版本/序号、提交后轮换、去重、Lamport/LWW/tombstone 和 LOCAL/CLOUD/HYBRID 保留。待同步事件不因压缩丢弃。默认 DIRECT、deepseek-flash、thinking 关闭，出厂 HYBRID；升级保留用户 NVS 设置。凭据本机输入按用户要求回显，不进入 LLM 上下文或 Git。

GPIO4/5/10/20/21 支持输入/输出、两路 10–5000 Hz PWM；按钮0/1/9只读。USB18/19、Flash12–17、未知11受保护；灯8、ADC2、功放3、PDM6/7通过板驱动管理。直接输出持续；计划结束/取消恢复原状态。不执行模型生成的机器码/C代码。

## 验收口径

1000 次实验已经完成：A/B 各500、500配对，另2次电脑采集中断单列。A 是官方算法板级适配，B 是冻结调优镜像。在已知输入中，误唤醒8/100→0/100，无指令误录22/100→2/100，10秒上限19→0；唤醒正例成功率未证明显著提高，启动中位数351→602ms。不能把这些数据当成0.6.0重新跑过1000次，也不能当作盲测或普遍识别率。

本次集成验收为：音频开启/关闭构建、24/12组主机测试、来源与许可证校验、应用更新、GPIO/取消/音乐/监听有界检查、NVS/上下文/录音保留。结果见 [BASELINE](docs/BASELINE.md)。不要求再次完成三天研究流程。

原 M0 实机 Gateway/同步和真实 USB 断电验收仍未完成；原 M3 主观音乐体验、M4 苛刻语音目标和历史失败不被本次基线采纳改写。详见 [1000次对比](docs/VOICE_AB_1000_REPORT.md)、[历史测试](docs/TEST_REPORT.md)和[音乐报告](docs/MUSIC_REPORT.md)。

## 可复现材料

入口 README、构建 tools/build_agent.ps1、依赖 third_party/manifest.json 与 components/agent_vad/sources.lock.cmake。清理后源码不依赖 `_ref`、`hardware_tests` 或实验产物。当前与参考镜像在 artifacts/baseline；删除审计和新构建在 artifacts/baseline-cleanup-v1；完整同板实验在 artifacts/voice-ab-1000-v1。上述产物和本机凭据目录不进入 Git。
''',
'docs/WAKE_VAD_SPEC.md':'''# 当前唤醒与录音基线

0.6.0-upgrade 采用 1000 次同板对比的 B 版语音链路，作为实验性 Agent 功能收尾，不继续训练。固定上游与来源见 [基线说明](BASELINE.md)。这不是完整 ASR、TTS 或语音对话。

## 操作和状态

`agent wake on` 开启监听，说“嗨乐鑫”，听到开始提示音后说指令。`agent wake status` 查询；`agent wake off` 或 `agent cancel` 停止。重启后默认关闭。对话或扬声器占用时暂停监听，资源释放后可恢复。

流程是监听 → 唤醒确认 → 准备/提示音 → 本地采集 → 端点确认/提交 → 完成提示音 → 重新监听。单轮最长录音10秒，唤醒后没有指令有4秒等待边界；校验/提交失败不发布有效录音。新录音会替换单个录音槽。没有自动转写或上传。

## 固定实现

- 原始 WakeNet9s hilexin 命中后用固定关键词特征筛选；不在运行时训练。
- ADC 32 kHz 采集，抽取至16 kHz，12 dB 衰减；Wi-Fi省电关闭。
- Flash后端的TEN确认与前台采集通过原子发布进度配合；处理落后不能假装看到了尚未处理的样本。
- 保留 B 的 source_stream/source_bound、confirmation_tail、tonal规则以及阶段观测。
- 唤醒采集写 lossless packed v3，读v1/v2/v3；手动采集保持v1。CRC和提交标记保护数据有效性，详见 [录音格式](AUDIO_CLIP_FORMAT.md)。
- 大缓冲使用现有工作区租约，不降低2 MiB上下文和128 KiB历史预算。默认开启关键词/TEN能力，但开机不监听。

## 已测结果和限制

冻结的B在500个试验中：正例395/400成功、负例0/100误唤醒、无指令2/100误录、0次触及10秒上限、无板上DMA丢帧。A对应393/400、8/100、22/100、19次、0丢帧。B启动录音中位数602ms，比A慢251ms；本轮最低堆49,804B。

这些是重复的已知/开发素材，不是盲测，也不是0.6.0合并镜像的新1000次验收。报告保留全部误判、两次电脑采集失败、声学定位不确定性和资源代价。[完整结果](VOICE_AB_1000_REPORT.md)。没有主张“零误唤醒”、普适超过官方或完全无截断。

本次只验证迁移集成及资源/取消/GPIO等基本行为；原M4未达目标不因用户采纳实验基线而改成通过。无需重新开始长循环测试。
''',
'third_party/README.md':'''# 固定运行依赖

本目录只保留当前ESP32-C3基线所需的第三方代码、模型、库与许可证。`manifest.json`记录文件SHA256；在项目Python中执行 `tools/verify_dependencies.py` 校验。

| 目录 | 来源 |
|---|---|
| cjson | 项目固定cJSON，详情见目录内README.agent.md与LICENSE |
| esp-sr | Espressif ESP-SR `efa8d907c6d457cd0f99dae6c6b493412d3078d4` 的C3头文件/库及wn9s_hilexin模型；保留LICENSE |
| ten-vad | TEN-VAD `22a3bcd4509d0faaa8eef4881e8af5f39c178950` 的选定vendor源、固定生成表；保留LICENSE与NOTICES |
| rvfplib | 接受版使用的3个单精度汇编实现；保留LICENSE.txt与LICENSE-EXCEPTION.txt |

TEN vendor/pitch_est.c及项目自有 `components/agent_vad/kernel/` 使用已接受B版的定点/融合/共享缓冲优化，不能称为未经修改的TEN上游。准确文件清单与哈希也在 `components/agent_vad/sources.lock.cmake`。唤醒筛选在 `components/agent_speech/keyword/`。

参考B应用SHA256为 `d9bd6975088b733d7c2f2976a4698f9c744de34a354a5b5929599df0ff68c953`。迁入清单、原来源和接受版源码归档保存在本机 `artifacts/baseline-cleanup-v1/promotion.json` 与 `artifacts/baseline/reference/accepted-source.zip`。不需要原 `_ref/` 或研究构建目录即可构建。
'''
}

for name,text in DOCS.items():
    (ROOT/name).write_text(text,encoding='utf8')

# Preserve historical reports verbatim below a clear current-baseline notice.
for name in ('BUILD_REPORT.md','TEST_REPORT.md','TEST_PLAN.md','AGENT_LEAN_REPORT.md','MUSIC_REPORT.md','VOICE_AB_1000_REPORT.md','VOICE_AB_1000_SPEC.md'):
    p=ROOT/'docs'/name
    old=p.read_text(encoding='utf-8-sig')
    note='> 历史阶段记录：安装状态和产物路径描述当时的结果。2026-09-15 已采纳调优语音链路并清理旧中间材料；当前入口见 [BASELINE.md](BASELINE.md) 与 [CLEANUP_REPORT.md](CLEANUP_REPORT.md)。1000次正式证据完整保留，其数据不等于合并版的新1000次测试。\n\n'
    p.write_text(note+old,encoding='utf8')
p=ROOT/'docs/AUDIO_CLIP_FORMAT.md'
old=p.read_text(encoding='utf8').replace('The option defaults off; legacy firmware rejects packed clips,','The supported 0.6.0 build enables this option; legacy firmware rejects packed clips,')
old=old[:old.index('\nEvidence:')]+'''\nCurrent validation: the baseline host suite includes packed clip fault tests.
Historical candidate datasets were removed during authorized cleanup; their
old measurements are not repeated acceptance claims. The complete accepted
same-device comparison remains in `artifacts/voice-ab-1000-v1/`.
'''
p.write_text(old,encoding='utf8')
print('Wrote current README, SPEC, wake specification, third-party provenance and historical notices')
