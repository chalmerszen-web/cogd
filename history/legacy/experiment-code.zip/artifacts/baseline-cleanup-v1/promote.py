"""Promote the tested speech path; preserve bytes and record every source move."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent
B = ROOT / 'artifacts/wake/coarse-profile-v1'
records = []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(source, target):
    src, dst = ROOT/source, ROOT/target
    assert src.is_file() and src.resolve().is_relative_to(ROOT)
    assert dst.resolve().is_relative_to(ROOT) and src != dst
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    assert digest(src) == digest(dst)
    records.append(dict(source=source, target=target, sha256=digest(dst), bytes=dst.stat().st_size))


def write(path, text):
    (ROOT/path).write_text(text, encoding='utf8')


def main():
    assert not (WORK/'promotion.json').exists()
    archive = WORK/'source-before.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for name in ('main','core','plugins','platform','boards','components','third_party'):
            for p in sorted((ROOT/name).rglob('*')):
                if p.is_file(): z.write(p,p.relative_to(ROOT).as_posix())
        for name in ('README.md','SPEC.md','ACTIONLOG.md','sdkconfig.defaults','sdkconfig.lean.defaults','tools/build_agent.ps1'):
            z.write(ROOT/name,name)
    accepted = ROOT/'build-coarse-profile-v1-device/esp_hi_agent.bin'
    assert digest(accepted)=='d9bd6975088b733d7c2f2976a4698f9c744de34a354a5b5929599df0ff68c953'
    copy(accepted.relative_to(ROOT).as_posix(),'artifacts/baseline/reference/optimized-B.bin')
    copy('artifacts/voice-ab-1000-v1/flash-before.bin','artifacts/baseline/reference/rollback-lean-full.bin')

    # Extract the already pinned small runtime dependency set, not the research checkouts.
    checks = re.findall(r'agent_ten_check\("([^"]+)" "([a-f0-9]+)"\)',
                        (ROOT/'components/agent_vad/sources.lock.cmake').read_text())
    for source, expected in checks:
        assert digest(ROOT/source)==expected, source
        if source.startswith('_ref/RVfplib/'):
            target=source.replace('_ref/RVfplib/','third_party/rvfplib/')
        elif source.startswith('build-ten-vad-pitchguards/vendor/'):
            target=source.replace('build-ten-vad-pitchguards/vendor/','third_party/ten-vad/vendor/')
        elif source.startswith('build-ten-vad/generated/'):
            target=source.replace('build-ten-vad/generated/','third_party/ten-vad/generated/')
        else:
            target=source.replace('hardware_tests/ten_vad/','components/agent_vad/kernel/')
        copy(source,target)
    # These exact kernel overrides were linked in the accepted B image.
    for p in sorted((B/'ten').iterdir()):
        if p.suffix in ('.c','.h'):
            target=('third_party/ten-vad/vendor/' if p.name=='pitch_est.c' else 'components/agent_vad/kernel/')+p.name
            copy(p.relative_to(ROOT).as_posix(),target)
    for name in ('LICENSE','NOTICES'):
        copy('_ref/ten-vad/'+name,'third_party/ten-vad/'+name)
    for name in ('LICENSE.txt','LICENSE-EXCEPTION.txt'):
        copy('_ref/RVfplib/'+name,'third_party/rvfplib/'+name)

    sr=ROOT/'_ref/esp-sr'
    for directory in ('include/esp32c3','src','model/wakenet_model/wn9s_hilexin'):
        for p in sorted((sr/directory).rglob('*')):
            if p.is_file(): copy(p.relative_to(ROOT).as_posix(),'third_party/esp-sr/'+p.relative_to(sr).as_posix())
    for name in ('wakenet','dl_lib','c_speech_features','esp_audio_processor','hufzip'):
        copy('_ref/esp-sr/lib/esp32c3/lib'+name+'.a','third_party/esp-sr/lib/esp32c3/lib'+name+'.a')
    copy('_ref/esp-sr/LICENSE','third_party/esp-sr/LICENSE')
    for name in ('gate.c','gate.h','templates.c','templates.h'):
        copy('hardware_tests/keyword_gate/'+name,'components/agent_speech/keyword/'+name)

    for name in ('audio_board.c','vad_worker.c','vad_worker.h'):
        copy('artifacts/wake/coarse-profile-v1/project/'+name,'boards/esp_hi/'+name)
    for name in ('clip.c','clip.h','clip_packed.c','clip_packed.h'):
        copy('artifacts/wake/coarse-profile-v1/candidate/'+name,'plugins/audio/'+name)
    for name in ('voice.c','source_stream.c','source_stream.h','tonal.c','tonal.h','factor_q30.h'):
        copy('artifacts/wake/coarse-profile-v1/'+name,'plugins/audio/'+name)
    for name in ('source_bound.c','source_bound.h'):
        copy('artifacts/wake/capture-pipeline-v1/'+name,'plugins/audio/'+name)
    for name in ('confirmation_tail.c','confirmation_tail.h'):
        copy('artifacts/wake/confirmation-tail-v1/'+name,'plugins/audio/'+name)
    copy('artifacts/wake/post-tonal-gate-v1/coefficients.h','plugins/audio/coefficients.h')
    for name in ('phase.c','phase.h','phase_clock.c'):
        copy('artifacts/wake/coarse-profile-v1/'+name,'boards/esp_hi/'+name)
    for name in ('test_phase.c','test_publication.c'):
        copy('artifacts/wake/coarse-profile-v1/'+name,'host_tests/'+name)

    # Keep the lean Agent/GPIO/SSE implementation; the only B runtime addition is its status command.
    runtime=ROOT/'platform/espidf/runtime.c'
    text=runtime.read_text();text=text.replace('#include "runtime.h"','#include "runtime.h"\n#if AGENT_ENABLE_AUDIO\n#include "phase.h"\n#endif',1)
    point='    if (!strcmp(line, "agent status") || !strcmp(line, "agent wifi status")) {'
    assert text.count(point)==1
    text=text.replace(point,'''#if AGENT_ENABLE_AUDIO
    if(!strcmp(line,"agent producer profile")) {
        char output[1024];agent_err_t e=phase_status(output,sizeof(output));
        if(!e) {say(output);say("\\r\\n");} else report(e);
        return;
    }
#endif
'''+point)
    runtime.write_text(text,encoding='utf8')

    write('components/agent_vad/sources.cmake','''get_filename_component(ten_root "${CMAKE_CURRENT_LIST_DIR}/../.." ABSOLUTE)
set(ten_vendor "${ten_root}/third_party/ten-vad/vendor")
set(ten_kernel "${CMAKE_CURRENT_LIST_DIR}/kernel")
set(ten_tables "${ten_root}/third_party/ten-vad/generated")
include("${CMAKE_CURRENT_LIST_DIR}/sources.lock.cmake")
set(ten_vendor_sources)
foreach(name aed ten_vad biquad pitch_est stft fftw)
  list(APPEND ten_vendor_sources "${ten_vendor}/${name}.c")
endforeach()
set(ten_owned_sources "${CMAKE_CURRENT_LIST_DIR}/vad_backend.c" "${CMAKE_CURRENT_LIST_DIR}/ten_memory.c"
  "${ten_kernel}/model.c" "${ten_kernel}/fixed.c")
set(ten_definitions TEN_DEVICE TEN_CACHE_ROWS=0 TEN_FIXED_DSP TEN_FIXED8 TEN_BINARY_SCALE
  TEN_NARROW_DSP TEN_BINARY_GUARDS TEN_NARROW_CONVERT TEN_PITCH_GUARDS)
foreach(source IN LISTS ten_vendor_sources)
  set_source_files_properties("${source}" PROPERTIES COMPILE_DEFINITIONS
    "malloc=agent_ten_malloc;calloc=agent_ten_calloc;free=agent_ten_free")
endforeach()
''')
    cm=ROOT/'components/agent_vad/CMakeLists.txt'
    text=cm.read_text().replace('${ten_root}/_ref/RVfplib/','${ten_root}/third_party/rvfplib/')
    text=text.replace('option(AGENT_BACKGROUND_VERIFY "Experimental bounded Flash-backed original TEN confirmation" OFF)',
                      'option(AGENT_BACKGROUND_VERIFY "Bounded Flash-backed TEN speech confirmation" ON)')
    text=text.replace('Prepare the pinned TEN pitch-guards sources and fixed8 tables before this experimental build','Pinned TEN runtime sources are missing')
    text=text.replace('if(AGENT_TEN_SKIP_PITCH)\n  target_compile_definitions(${COMPONENT_LIB} PUBLIC AGENT_TEN_SKIP_PITCH=1)\nendif()\n','')
    # The accepted pitch source includes the shared kernel helpers.
    cm.write_text(text,encoding='utf8')
    lock='''# Hashes of the accepted B speech runtime, after path-only relocation.
function(agent_ten_check relative expected)
  set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${ten_root}/${relative}")
  file(SHA256 "${ten_root}/${relative}" actual)
  if(NOT actual STREQUAL expected)
    message(FATAL_ERROR "Pinned TEN source changed: ${relative}")
  endif()
endfunction()
'''
    for directory in ('third_party/ten-vad/vendor','third_party/ten-vad/generated','third_party/rvfplib/src','components/agent_vad/kernel'):
        for p in sorted((ROOT/directory).rglob('*')):
            if p.is_file():lock+=f'agent_ten_check("{p.relative_to(ROOT).as_posix()}" "{digest(p)}")\n'
    write('components/agent_vad/sources.lock.cmake',lock)
    (WORK/'promotion.json').write_text(json.dumps(dict(complete=True,accepted_B_sha256=digest(accepted),
        source_before_zip_sha256=digest(archive),copies=records),indent=2),encoding='utf8')
    print(json.dumps(dict(copied=len(records),bytes=sum(r['bytes'] for r in records),complete=True)))


if __name__=='__main__':main()
