$ErrorActionPreference = 'Stop'
$cleanupRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..')).TrimEnd('\')
$cleanupPlan = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'deletion-plan.json') -Raw | ConvertFrom-Json
if ($cleanupRoot -ne 'C:\Users\PC\Documents\ChatGPT\cogd' -or $cleanupPlan.root -ne $cleanupRoot) {
    throw 'Workspace does not match the reviewed cleanup plan'
}
$cleanupPrefix = $cleanupRoot + '\'
# Validate every resolved absolute path before performing any recursive deletion.
foreach ($entry in $cleanupPlan.targets) {
    $target = [IO.Path]::GetFullPath($entry.path)
    if (-not $target.StartsWith($cleanupPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes workspace' }
    if (-not (Test-Path -LiteralPath $target)) { throw "Planned target missing: $target" }
    $item = Get-Item -LiteralPath $target -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse target: $target" }
    if ($item.PSIsContainer) {
        $links = @(Get-ChildItem -LiteralPath $target -Force -Recurse -Attributes ReparsePoint)
        if ($links.Count) { throw "Reparse point under target: $target" }
    }
}
$cleanupLog = Join-Path $PSScriptRoot 'deleted.jsonl'
if (Test-Path -LiteralPath $cleanupLog) { throw 'Do not overwrite a previous deletion record' }
foreach ($entry in $cleanupPlan.targets) {
    $target = [IO.Path]::GetFullPath($entry.path)
    if ($entry.directory) { Remove-Item -LiteralPath $target -Recurse -Force }
    else { Remove-Item -LiteralPath $target -Force }
    if (Test-Path -LiteralPath $target) { throw "Deletion incomplete: $target" }
    @{ path=$target; deleted=$true; files=$entry.files; bytes=$entry.bytes; at=(Get-Date -Format o) } |
        ConvertTo-Json -Compress | Add-Content -LiteralPath $cleanupLog -Encoding utf8
}
@{ complete=$true; targets=$cleanupPlan.targets.Count; files=$cleanupPlan.files; logicalBytes=$cleanupPlan.bytes } |
    ConvertTo-Json -Compress | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'deletion-result.json') -Encoding utf8
