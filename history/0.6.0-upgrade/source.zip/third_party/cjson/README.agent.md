cJSON 1.7.19, unmodified upstream C source and MIT license.
Source: https://github.com/DaveGamble/cJSON/tree/v1.7.19

SHA-256:
- cJSON.c: 298581a04a36c0165da4b0aade235c23088cb2faa58651d720ea2f3706ed0b0d
- cJSON.h: 25b0145150d500498e4d209cec69c18c42cf818bffcc54690be3b895a2a16dee
- LICENSE: a36dda207c36db5818729c54e7ad4e8b0c6fba847491ba64f372c1a2037b6d5c

The firmware and host tests compile the same vendored source with nesting limited to 16.
